<?php return array (
  'checkout' => 'App\\Http\\Livewire\\Checkout',
  'modal-product-preview' => 'App\\Http\\Livewire\\ModalProductPreview',
  'payment' => 'App\\Http\\Livewire\\Payment',
  'product' => 'App\\Http\\Livewire\\Product',
  'product-filter' => 'App\\Http\\Livewire\\ProductFilter',
  'products' => 'App\\Http\\Livewire\\Products',
  'profile' => 'App\\Http\\Livewire\\Profile',
  'review' => 'App\\Http\\Livewire\\Review',
  'search-bar' => 'App\\Http\\Livewire\\SearchBar',
  'shopping-cart' => 'App\\Http\\Livewire\\ShoppingCart',
);