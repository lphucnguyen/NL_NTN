<form action="/admin/product/edit/<?php echo e($product->id); ?>" id="frmEditProduct" method="post" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
    <div class="mb-3">
        <label for="id" class="form-label">ID sản phẩm:</label>
        <input type="text" name="id" class="form-control" id="id" readonly value="<?php echo e($product->id); ?>">
    </div>
    <div class="mb-3">
        <label for="name" class="form-label">Tên sản phẩm :</label>
        <input type="text" class="form-control" name="name" id="name" value="<?php echo e($product->name); ?>">
    </div>
    <div class="mb-3">
        <label for="type" class="form-label">Loại sản phẩm:</label>
        <select name="type" id="type" class="form-control">
            <?php $__currentLoopData = $product_type; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($v->id); ?>" <?php if($v->id == $product->type): ?> selected <?php endif; ?>>
                    <?php echo e($v->name_type); ?>

                </option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </div>
    <div class="mb-3">
        <label for="price" class="form-label">Giá:</label>
        <input type="text" class="form-control" name="price" id="price" value="<?php echo e($product->price); ?>">
    </div>
    <div class="mb-3">
        <label for="quantity" class="form-label">Số lượng:</label>
        <input type="text" class="form-control" name="quantity" id="quantity" value="<?php echo e($product->quantity); ?>">
    </div>
    <div class="mb-3">
        <label for="description" class="form-label">Mô tả:</label>
        <textarea class="d-block" name="description" id="description" cols="30" rows="10"
            style="width: 100%"><?php echo e($product->description); ?></textarea>
    </div>

    
    <div class="mb-3">
        <label for="img1" class="form-label">Ảnh 1:</label>
        <input type="hidden" name="id_img1_old" value="<?php echo e($img[0]->id); ?>">
        <input type="file" class="form-control" name="img1" id="img1" onchange="readImg1(this);" accept="image/*">
        <div class="row d-flex mt-2">
            <div class="col">
                <div class="card text-center">
                    <img src="<?php echo e(asset('images/products')); ?>/<?php echo e($img[0]->name); ?>" class="card-img-top border rounded" alt="img1">
                    <div class="card-body ">
                        <p class="p-0 m-0 fw-bold">Ảnh 1 hiện tại</p>
                    </div>
                </div>
            </div>
            <div class="col">
                <div class="card text-center">
                    <img src="" class="card-img-top border rounded" id="new_img1" alt="Ảnh mới">
                    <div class="card-body ">
                        <p class="p-0 m-0 fw-bold">Ảnh mới 1</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="mb-3">
        <label for="img2" class="form-label">Ảnh 2:</label>
        <input type="hidden" name="id_img2_old" value="<?php echo e($img[1]->id); ?>">
        <input type="file" class="form-control" name="img2" id="img2" onchange="readImg2(this);" accept="image/*">
        <div class="row d-flex mt-2">
            <div class="col">
                <div class="card text-center">
                    <img src="<?php echo e(asset('images/products')); ?>/<?php echo e($img[1]->name); ?>" class="card-img-top border rounded" alt="img2">
                    <div class="card-body ">
                        <p class="p-0 m-0 fw-bold">Ảnh 2 hiện tại</p>
                    </div>
                </div>
            </div>
            <div class="col">
                <div class="card text-center">
                    <img src="" class="card-img-top border rounded" id="new_img2" alt="Ảnh mới">
                    <div class="card-body ">
                        <p class="p-0 m-0 fw-bold">Ảnh mới 2</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="mb-3">
        <label for="img3" class="form-label">Ảnh 3:</label>
        <input type="hidden" name="id_img3_old" value="<?php echo e($img[2]->id); ?>">
        <input type="file" class="form-control" name="img3" id="img3" onchange="readImg3(this);" accept="image/*">
        <div class="row d-flex mt-2">
            <div class="col">
                <div class="card text-center">
                    <img src="<?php echo e(asset('images/products')); ?>/<?php echo e($img[2]->name); ?>" class="card-img-top border rounded" alt="img3">
                    <div class="card-body ">
                        <p class="p-0 m-0 fw-bold">Ảnh 3 hiện tại</p>
                    </div>
                </div>
            </div>
            <div class="col">
                <div class="card text-center">
                    <img src="" class="card-img-top border rounded" id="new_img3" alt="Ảnh mới">
                    <div class="card-body ">
                        <p class="p-0 m-0 fw-bold">Ảnh mới 3</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
    

    <div class="mt-3 text-right">
        <button type="submit" class="btn btn-primary" form="frmEditProduct">Lưu</button>
        <button type="reset" onclick="resetfrm()" class="btn btn-success">Reset</button>
    </div>
</form>



<script>
    function readImg1(input) {
        if (input.files && input.files[0]) {
            var reader = new FileReader();
            reader.onload = function(e) {
                $('#new_img1').attr('src', e.target.result);
            };

            reader.readAsDataURL(input.files[0]);
        }
    }

    function readImg2(input) {
        if (input.files && input.files[0]) {
            var reader = new FileReader();
            reader.onload = function(e) {
                $('#new_img2').attr('src', e.target.result);
            };

            reader.readAsDataURL(input.files[0]);
        }
    }

    function readImg3(input) {
        if (input.files && input.files[0]) {
            var reader = new FileReader();
            reader.onload = function(e) {
                $('#new_img3').attr('src', e.target.result);
            };

            reader.readAsDataURL(input.files[0]);
        }
    }

    function resetfrm() {
        $('#new_img1').attr('src', null);
        $('#new_img2').attr('src', null);
        $('#new_img3').attr('src', null);
    }
</script>
<?php /**PATH C:\xampp\htdocs\NL_NTN\resources\views/admin/ajax/edit_product.blade.php ENDPATH**/ ?>