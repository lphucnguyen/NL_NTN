

<?php $__env->startSection('title', "Home | NTN Shop"); ?>

<?php $__env->startSection('content'); ?>


<!-- Banner -->



<!-- Product -->
<section class="bg0 p-t-23 p-b-140">
    <div class="container">
        <div class="p-b-10">
            <h3 class="ltext-103 text-center cl5">
                Sản phẩm cửa hàng
            </h3>
        </div>

        
        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('products')->html();
} elseif ($_instance->childHasBeenRendered('4l4TMMw')) {
    $componentId = $_instance->getRenderedChildComponentId('4l4TMMw');
    $componentTag = $_instance->getRenderedChildComponentTagName('4l4TMMw');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('4l4TMMw');
} else {
    $response = \Livewire\Livewire::mount('products');
    $html = $response->html();
    $_instance->logRenderedChild('4l4TMMw', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('client.template.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\NL_NTN\resources\views/client/home/home.blade.php ENDPATH**/ ?>