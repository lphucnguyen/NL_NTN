<?php $__env->startSection('title', 'Profile | Admin - NTN Shop'); ?>

<?php $__env->startSection('heading', ''); ?>

<?php $__env->startSection('des_heading', ''); ?>

<?php $__env->startSection('x_heading', 'Thông tin profile'); ?>

<?php $__env->startSection('content'); ?>
    <style>
        #content_history {
            white-space: break-spaces;
        }

    </style>
    <div class="x_content">

        <div class="col-md-3 col-sm-3  profile_left">
            <div class="profile_img">
                <div id="crop-avatar ">
                    <!-- Current avatar -->
                    <img class="img-responsive avatar-view img-fluid border-secondary border-2 rounded"
                        src="<?php echo e(asset('images/avatar/' . $info->avatar)); ?>" alt="Avatar" title="Change the avatar">
                </div>
            </div>
            <h3><?php echo e($info->fullname); ?></h3>

            <ul class="list-unstyled user_data">
                <li>
                    <i class="mr-2 fas fa-map-marker-alt"></i> <?php echo e($info->address); ?>

                </li>
                <li>
                    <?php if($info->gender == 'Nam'): ?>
                        <i class="mr-2 fas fa-mars"></i>
                    <?php else: ?>
                        <i class="mr-2 fas fa-venus"></i>
                    <?php endif; ?>

                    <?php echo e($info->gender); ?>

                </li>
                <li>
                    <i class="mr-2 fas fa-cake"></i> <?php echo e(date('d/m/Y', strtotime(Auth::user()->birthday))); ?>

                </li>
                <li>
                    <i class="mr-2 fas fa-phone"></i> <?php echo e($info->phone); ?>

                </li>
                <li>
                    <i class="mr-2 far fa-envelope"></i> <?php echo e($info->email); ?>

                </li>
            </ul>

            <?php if($info->id == Auth::id()): ?>
                <a class="btn btn-success text-light" data-bs-toggle="modal" data-bs-target="#editProfile">
                    <i class="fa fa-edit m-right-xs"></i>Edit Profile
                </a>
            <?php endif; ?>

            <br />

        </div>
        <div class="col-md-9 col-sm-9 ">
            <div class="" role="tabpanel" data-example-id="togglable-tabs">
                <ul id="myTab" class="nav nav-tabs bar_tabs" role="tablist">
                    <li role="presentation" class="active"><a href="#tab_content1" id="home-tab" role="tab"
                            data-toggle="tab" aria-expanded="true">Lịch sử làm việc</a>
                    </li>
                    <li role="presentation" class="active"><a href="#tab_content2" role="tab" id="profile-tab"
                            data-toggle="tab" aria-expanded="false">Đơn hàng đã duyệt</a>
                    </li>
                </ul>
                <div id="myTabContent" class="tab-content">
                    <div role="tabpanel" class="tab-pane active " id="tab_content1" aria-labelledby="home-tab">

                        <!-- start recent activity -->
                        <ul class="messages">
                            <?php if(count($history) < 1): ?>
                                <p class="text-center fs-5 fw-bold text-primary">Lịch sử trống</p>
                            <?php endif; ?>
                            <?php $__currentLoopData = $history->reverse(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li class="border-0 border-dark boder-bottom">
                                    <img src="<?php echo e(asset('images/avatar')); ?>/<?php echo e($info->avatar); ?>"
                                        class="avatar rounded-circle" alt="Avatar">
                                    <div class="message_date text-center">
                                        <h3 class="date text-info"><?php echo e(date('d', $v->create_at)); ?></h3>
                                        <p class="month"><?php echo e(date('M', $v->create_at)); ?></p>
                                    </div>
                                    <div class="message_wrapper" id="message_wrapper">
                                        <h4 class="heading"><?php echo e($v->title); ?></h4>
                                        <details>
                                            <summary>Xem chi tiết</summary>
                                            <p class="text-dark" id="content_history"><?php echo e($v->content); ?></p>
                                        </details>

                                        <p class="url ps-3 text-secondary">
                                            <i class="far fa-clock"></i>
                                            <?php echo e(date('h:m:s d-m-Y', $v->create_at)); ?>

                                        </p>
                                    </div>
                                </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </ul>
                        <!-- end recent activity -->

                    </div>
                    <div role="tabpanel" class="tab-pane fade" id="tab_content2" aria-labelledby="profile-tab">
                        <table class="data table table-striped no-margin">
                            <thead>
                                <tr>
                                    <th>#</th>
                                    <th>Tên Khách Hàng</th>
                                    <th>Phương Thức Thành Toán</th>
                                    <th>Tổng Tiền</th>
                                    <th>Trạng Thái</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if(count($order) < 1): ?>
                                    <tr>
                                        <td class="fw-bold fs-6 text-center" colspan="5">
                                            Chưa duyệt đơn hàng nào
                                        </td>
                                    </tr>
                                <?php endif; ?>
                                <?php $__currentLoopData = $order; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($k + 1); ?></td>
                                        <td><?php echo e($v->fullname); ?></td>
                                        <td><?php echo e($v->payment_method); ?></td>
                                        <td><?php echo e(number_format($v->total)); ?> VNĐ</td>
                                        <td class="vertical-align-mid">
                                            <?php echo e($v->status); ?>

                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script>
        $(document).ready({
            var hMessage = message_wrapper
            if (hMessage > 200) {
                message_wrapper.hMessage(200)

            }
        });
    </script>

    <!-- Modal Edit Profile-->
    <div class="modal fade " id="editProfile" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered" style="max-width: 100vh">
            <div class="modal-content">

                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel"><b> Sửa thông tin cá nhân </b></h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>

                <div class="modal-body" id="modal_editProductType">
                    <form action="<?php echo e(route('admin.profile.edit')); ?>" id="frmEditProfile" enctype="multipart/form-data"
                        method="post">
                        <?php echo csrf_field(); ?>
                        <div class="row justify-content-center">
                            <input type="hidden" name="id" value="<?php echo e(Auth::id()); ?>">
                            <div class="col-6">
                                <div class="card">
                                    <img src="<?php echo e(asset('images/avatar/' . Auth::user()->avatar)); ?>"
                                        class="card-img-top" id="avatar-img" alt="">
                                    <div class="card-body text-center">
                                        <label for="avatar" class="m-0">
                                            <a class="btn btn-light border m-0"><i class="fa fa-camera"></i> Chọn ảnh
                                                mới</a>
                                        </label>
                                        <input type="file" class="d-none" name="avatar" id="avatar"
                                            onchange="readImg(this);" accept="image/*">
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="fullname" class="form-label">Họ tên:</label>
                            <input type="text" id="fullname" name="fullname" value="<?php echo e(Auth::user()->fullname); ?>"
                                class="form-control" placeholder="Nhập họ tên" required>
                        </div>
                        <div class="form-group">
                            <label for="address" class="form-label">Địa chỉ:</label>
                            <input type="text" id="address" name="address" value="<?php echo e(Auth::user()->address); ?>"
                                class="form-control" placeholder="Nhập địa chỉ" required>
                        </div>
                        <div class="form-group">
                            <label for="gender" class="form-label">Giới tính:</label>
                            <div class="row">
                                <div class="col-2">
                                    <input type="radio" <?php if(Auth::user()->gender == 'Nam'): ?> checked <?php endif; ?> id="gender-male"
                                        name="gender" value="Nam" required>
                                    <label for="gender-male">Nam</label>
                                </div>
                                <div class="col-2">
                                    <input type="radio" <?php if(Auth::user()->gender != 'Nam'): ?> checked <?php endif; ?> id="gender-female"
                                        name="gender" value="Nữ" required>
                                    <label for="gender-female">Nữ</label>
                                </div>
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="birthday" class="form-label">Ngày sinh:</label>
                            <input type="date" id="birthday" name="birthday" value="<?php echo e(date('Y-m-d', strtotime(Auth::user()->birthday))); ?>"
                                class="form-control" required>
                        </div>
                    </form>
                </div>

                <div class="modal-footer">
                    <button class="btn btn-primary" type="submit" form="frmEditProfile">Lưu</button>
                    <button class="btn btn-success" type="reset" onclick="resetfrm('<?php echo e(Auth::user()->avatar); ?>')"
                        form="frmEditProfile">Reset</button>
                </div>
                <script>
                    function rangePercent(percent) {
                        $('#percent_input').innerHTML = percent.value + "%";
                    }

                    function percent_input(input) {
                        $('#percent').value = input.value
                    }

                    function readImg(input) {
                        if (input.files && input.files[0]) {
                            var reader = new FileReader();
                            reader.onload = function(e) {
                                $('#avatar-img').attr('src', e.target.result);
                            };

                            reader.readAsDataURL(input.files[0]);
                        }
                    }

                    function resetfrm(img) {
                        $('#avatar-img').attr('src', '/images/avatar/' + img);
                    }
                </script>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.template.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\NL_NTN\resources\views/admin/back/profile.blade.php ENDPATH**/ ?>