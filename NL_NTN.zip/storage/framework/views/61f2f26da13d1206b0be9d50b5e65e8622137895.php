

<?php $__env->startSection('title', "Shop | NTN Shop"); ?>

<?php $__env->startSection('content'); ?>

<div class="bg0 m-t-23 p-b-140">
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('product-filter')->html();
} elseif ($_instance->childHasBeenRendered('pwtP6iD')) {
    $componentId = $_instance->getRenderedChildComponentId('pwtP6iD');
    $componentTag = $_instance->getRenderedChildComponentTagName('pwtP6iD');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('pwtP6iD');
} else {
    $response = \Livewire\Livewire::mount('product-filter');
    $html = $response->html();
    $_instance->logRenderedChild('pwtP6iD', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('client.template.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\NL_NTN\resources\views/client/back/shop.blade.php ENDPATH**/ ?>