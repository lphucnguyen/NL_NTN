

<?php $__env->startSection('title', 'Order Detail | Admin - NTN Shop'); ?>

<?php $__env->startSection('heading', ''); ?>

<?php $__env->startSection('des_heading', ''); ?>

<?php $__env->startSection('x_heading', 'Chi tiết đơn hàng'); ?>

<?php $__env->startSection('content'); ?>

    <section class="content invoice w-100">
        <!-- title row -->
        <div class="row">
            <div class="invoice-header">
                <h1>
                    <i class="fa fa-globe"></i> Hóa đơn
                    <small class="pull-right fs-5 text-right">Ngày lập: <?php echo e(date('d/m/Y')); ?></small>
                </h1>
            </div>
            <!-- /.col -->
        </div>
        <br><br>
        <!-- info row -->
        <div class="row invoice-info">
            <div class="col-sm-4 invoice-col">
                <div class="col-10">
                    Nhân viên xác nhận:
                    <hr class="w-50 my-2">
                    <?php if($staff != null): ?>
                        <address>
                            <strong class="fs-6"><?php echo e($staff->fullname); ?></strong><br>
                            <strong>Địa chỉ:</strong> <i><?php echo e($staff->address); ?></i>
                            <br><strong>Số điện thoại:</strong> <?php echo e($staff->phone); ?>

                            <br><strong>Email:</strong> <?php echo e($staff->email); ?>

                        </address>
                    <?php else: ?>
                        <address>
                            <strong>Chưa có nhân viên xác nhận</strong>
                        </address>
                    <?php endif; ?>

                </div>
            </div>
            <!-- /.col -->
            <div class="col-sm-4 invoice-col">
                <div class="col-10">
                    Khách hàng:
                    <hr class="w-50 my-2">
                    <address>
                        <strong class="fs-6"><?php echo e($user->fullname); ?></strong><br>
                        <strong>Địa chỉ:</strong> <i><?php echo e($order->address); ?></i>
                        <br><strong>Số điện thoại:</strong> <?php echo e($user->phone); ?>

                        <br><strong>Email:</strong> <?php echo e($user->email); ?>

                    </address>
                </div>
            </div>
            <!-- /.col -->
            <div class="col-sm-4 invoice-col">
                <b>Đơn hàng: #<?php echo e($order->id); ?></b>
                <br>
                <b>Ngày thanh toán:</b>
                <?php if($order->payment_method == 'momo'): ?>
                    <?php echo e(date('d/m/Y', strtotime($order->created_at))); ?>

                <?php else: ?>
                    <?php if($order->delivery_date == null): ?>
                        Chưa thanh toán
                    <?php else: ?>
                        <?php echo e(date('d/m/Y', strtotime($order->delivery_date))); ?>

                    <?php endif; ?>
                <?php endif; ?>
            </div>
            <!-- /.col -->
        </div>
        <!-- /.row -->

        <!-- Table row -->
        <div class="row">
            <div class="  table">
                <table class="table table-striped">
                    <thead>
                        <tr class="text-center">
                            <th>Mã sản phẩm</th>
                            <th>Tên sản phẩm</th>
                            <th>Số lượng</th>
                            <th>Giá </th>
                            <th>Bảo hành</th>
                            <th>Thành tiền</th>
                        </tr>
                    </thead>
                    <tbody>

                        <?php ($subtotal = 0); ?>

                        <?php $__currentLoopData = $order_detail; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr class="text-center">
                                <td><?php echo e($v->product_id); ?></td>
                                <td>
                                    <a class="cursor-pointer" onclick="showPD(<?php echo e($v->product_id); ?>)"
                                        data-bs-toggle="modal" data-bs-target="#viewProductDetail">
                                        <?php echo e($v->name); ?>

                                    </a>
                                </td>
                                <td><?php echo e($v->quantity); ?></td>
                                <td><?php echo e(number_format($v->price)); ?> VNĐ</td>
                                <td>1 tháng kể từ ngày lập hóa đơn</td>
                                <td><?php echo e(number_format($subtotal += $v->price * $v->quantity)); ?> VNĐ</td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
            <!-- /.col -->
        </div>
        <!-- /.row -->

        <div class="row">
            <!-- accepted payments column -->
            <div class="col-md-6">
                <p class="lead">Phương thức thanh toán: <b><?php echo e($order->payment_method); ?></b></p>

                <p class="text-muted well well-sm no-shadow" style="margin-top: 10px;">
                    <?php if($order->payment_method == 'momo'): ?>
                        Đơn hàng đã được thanh toán qua momo.
                    <?php else: ?>
                        Đơn hàng được thanh toán bằng tiền mặt khi nhận hàng.
                    <?php endif; ?>
                    <br><br>
                    Trong thời gian bảo hành nếu có bất cứ vấn đề gì
                    xin hãy liên hệ qua email hoặc số điện thoại của cửa hàng.
                    <br><br>
                    Số điện thoại: 099 978 9889<br>
                    Email: ntnsotre@gmail.com
                </p>
            </div>
            <!-- /.col -->
            <div class="col-md-6">
                <p class="lead">Tổng thành tiền</p>
                <br>
                <div class="table-responsive">
                    <table class="table">
                        <tbody>
                            <tr>
                                <th style="width:50%">Tổng phụ:</th>
                                <td><?php echo e(number_format($subtotal)); ?> VNĐ</td>
                            </tr>
                            <tr>
                                <th>Khuyến mãi (<?php echo e($order->percent ?: 0); ?>%)</th>
                                <td>
                                    <?php echo e(number_format(($subtotal * $order->percent) / 100)); ?> VNĐ
                                </td>
                            </tr>
                            <tr>
                                <th>VAT:</th>
                                <td>Sản phẩm đã bao gồm VAT</td>
                            </tr>
                            <tr>
                                <th>Tổng:</th>
                                <td><?php echo e(number_format($subtotal - ($subtotal * $order->percent) / 100)); ?> VNĐ</td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
            <!-- /.col -->
        </div>
        <!-- /.row -->

    </section>
    <!-- this row will not appear when printing -->
    <?php if($staff != null): ?>
        <div class="row no-print">
            <div class=" ">
                <button class="btn btn-default" onclick="window.print()"><i class="fa fa-print"></i> Print</button>
            </div>
        </div>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.template.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\NL_NTN\resources\views/admin/back/order_detail.blade.php ENDPATH**/ ?>