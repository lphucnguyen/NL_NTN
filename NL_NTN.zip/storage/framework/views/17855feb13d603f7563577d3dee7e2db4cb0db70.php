

<?php $__env->startSection('title', 'Order | Admin - NTN Shop'); ?>

<?php $__env->startSection('heading', ''); ?>

<?php $__env->startSection('des_heading', ''); ?>

<?php $__env->startSection('x_heading', 'Danh sách đơn hàng'); ?>

<?php $__env->startSection('content'); ?>
<form action="<?php echo e(route('admin.order.actionlist')); ?>" id="frmActionOrder" method="post">
<?php echo csrf_field(); ?>
    <table id="datatable" class="table table-striped jambo_table bulk_action w-100">
        <thead style="border-radius: 20px">
            <tr class="headings" >
                <th>
                    <input type="checkbox" id="check-all" class="flat ">
                </th>
                <th class="column-title" style="vertical-align: middle !important;">ID </th>
                <th class="column-title" style="vertical-align: middle !important;">Người mua </th>
                <th class="column-title" style="vertical-align: middle !important;">Địa chỉ </th>
                <th class="column-title">Trạng thái đơn hàng </th>
                <th class="column-title">Ngày giao hàng </th>
                <th class="column-title">Ngày nhận hàng </th>
                <th class="column-title no-link last">
                    <span class="nobr">Thao tác</span>
                </th>
                <th class="bulk-actions" colspan="9">
                    <div class="dropdown">
                        <button class="btn btn-transparent border-0 p-0 m-0 text-light dropdown-toggle" type="button"
                            id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                            Thao tác
                        </button>
                        <div class="dropdown-menu rounded" aria-labelledby="dropdownMenuButton">
                            <button class="dropdown-item btn_submit" type="submit" form="frmActionOrder" id="submit_confirm" name="submit_confirm" value="true">Đánh dấu tất cả đã duyệt</button>
                            <button class="dropdown-item btn_submit" type="submit" form="frmActionOrder" id="submit_done" name="submit_done" value="true">Đánh dấu tất cả đã hoàn thành</button>
                            <button class="dropdown-item btn_submit" type="submit" form="frmActionOrder" id="submit_fail" name="submit_fail" value="true">Đánh dấu tất cả thất bại</button>
                        </div>
                    </div>
                </th>
            </tr>
        </thead>

        <tbody>
            <?php $__currentLoopData = $order; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr class="even pointer text-center">
                    <td class="a-center ">
                        <input type="checkbox" class="flat table_records order_records" name="order_records[]"
                            value="<?php echo e($v->id); ?>">
                    </td>
                    <td class=" "><?php echo e($v->id); ?></td>
                    <td class="text-left "><?php echo e($v->user_fullname); ?></td>
                    <td class="text-left "><?php echo e($v->address); ?></td>
                    <td class=" status_order"><?php echo e($v->status); ?></td>
                    <td class=" "><?php echo e($v->delivery_date); ?></td>
                    <td class=" "><?php echo e($v->receiving_date); ?></td>
                    <td class=" last">
                        <a href="/admin/order/detail/<?php echo e($v->id); ?>">Xem</a>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</form>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.template.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\NL_NTN\resources\views/admin/back/order.blade.php ENDPATH**/ ?>