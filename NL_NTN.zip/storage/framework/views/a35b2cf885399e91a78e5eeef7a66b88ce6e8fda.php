<?php $__env->startSection('title', "Home | Admin - NTN Shop"); ?>

<?php $__env->startSection('heading', ""); ?>

<?php $__env->startSection('des_heading', ""); ?>

<?php $__env->startSection('x_heading', "W E L C O M E"); ?>

<?php $__env->startSection('content'); ?>

<div class="row justify-content-center align-items-center ">
    <div class="col text-center">
        <img src="https://media1.giphy.com/media/ka5wTox0hgO1OP0EPF/giphy.gif" width="80%" class="img-fluid" alt="">
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.template.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\NL_NTN\resources\views/admin/home/home.blade.php ENDPATH**/ ?>