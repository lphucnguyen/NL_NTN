<div class="container">
    <div class="row">
        <div class="col d-flex justify-content-center">
            <?php $__currentLoopData = $img; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <img src="<?php echo e(asset('images/products')); ?>/<?php echo e($v->name); ?>"
                    class="m-1 img-thumbnail rounded img-product-detail" alt="<?php echo e($product->name); ?>" width="150">
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>

    <div class="row d-flex justify-content-center mt-4 text-dark">
        <div class="col">
            <div class="row ">
                <div class="col border-start border-5 border-secondary">
                    <p class="fw-bold fs-3 text-shadow m-0 ps-1">
                        <?php echo e($product->name); ?>

                    </p>
                </div>
            </div>
            <div class="row ml-1">
                <div class="col">
                    <p class="fw-bold fs-6 text-muted">
                        <?php echo e($product->name_type); ?>

                    </p>
                </div>
            </div>
            <div class="row ml-1 mb-3 fw-bold">
                <div class="col ">
                    Số lượng:
                    <?php echo e($product->quantity); ?>

                </div>
                <div class="col text-right mr-3">
                    Giá:
                    <?php echo e(number_format($product->price)); ?> VNĐ
                </div>
            </div>
            <div class="row ml-1">
                <div class="col">
                    <p class="fw-bold mb-0">
                        Mô tả
                    </p>
                    <hr class="mt-0">
                    <textarea class="textarea_des p-0" readonly><?php echo e($product->description); ?></textarea>
                </div>
            </div>
        </div>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\NL_NTN\resources\views/admin/ajax/product_detail.blade.php ENDPATH**/ ?>