

<?php $__env->startSection('title', "Hồ sơ | NTN Shop"); ?>

<?php $__env->startSection('content'); ?>
<!-- breadcrumb -->
<div class="container">
    <div class="bread-crumb flex-w p-l-25 p-r-15 p-t-30 p-lr-0-lg">
        <a href="/home" class="stext-109 cl8 hov-cl1 trans-04">
            Trang chủ
            <i class="fa fa-angle-right m-l-9 m-r-10" aria-hidden="true"></i>
        </a>

        <span class="stext-109 cl4">
            Hồ sơ
        </span>
    </div>
    
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('profile', ['id' => Auth::id()])->html();
} elseif ($_instance->childHasBeenRendered('ZYvduhP')) {
    $componentId = $_instance->getRenderedChildComponentId('ZYvduhP');
    $componentTag = $_instance->getRenderedChildComponentTagName('ZYvduhP');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('ZYvduhP');
} else {
    $response = \Livewire\Livewire::mount('profile', ['id' => Auth::id()]);
    $html = $response->html();
    $_instance->logRenderedChild('ZYvduhP', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('client.template.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\NL_NTN\resources\views/client/back/profile.blade.php ENDPATH**/ ?>