<div class="bg0 p-t-75 p-b-85">
    <div class="container">
        <div class="row">
            <div class="col-sm-10 col-lg-3 col-xl-3 m-lr-auto m-b-50">
                <ul class="nav nav-pills mb-3 flex-column" id="pills-tab" role="tablist">
                    <li class="nav-item">
                      <a class="nav-link <?php echo e($panelShow == 'profile' ? 'active' : ''); ?> flex-c-m stext-101 cl2 size-118 bg8 bor13 hov-btn3 p-lr-15 trans-04 pointer m-tb-5" wire:click="changePanel('profile')" id="pills-home-tab" data-toggle="pill" href="#pills-home" role="tab" aria-controls="pills-home" aria-selected="true">
                          Thông tin cá nhân
                        </a>
                    </li>
                    <li class="nav-item">
                      <a class="nav-link <?php echo e($panelShow == 'security' ? 'active' : ''); ?> flex-c-m stext-101 cl2 size-118 bg8 bor13 hov-btn3 p-lr-15 trans-04 pointer m-tb-5" wire:click="changePanel('security')" id="pills-profile-tab" data-toggle="pill" href="#pills-profile" role="tab" aria-controls="pills-profile" aria-selected="false">
                          Bảo mật
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link <?php echo e($panelShow == 'order' ? 'active' : ''); ?> flex-c-m stext-101 cl2 size-118 bg8 bor13 hov-btn3 p-lr-15 trans-04 pointer m-tb-5" wire:click="changePanel('order')" id="pills-profile-tab" data-toggle="pill" href="#pills-profile" role="tab" aria-controls="pills-profile" aria-selected="false">
                            Đơn hàng
                        </a>
                    </li>
                  </ul>
            </div>

            <div class="col-lg-8 col-xl-8 m-lr-auto m-b-50">
                <div class="tab-content" id="pills-tabContent">
                    <div class="tab-pane <?php echo e($panelShow == 'profile' ? 'active' : ''); ?>" id="pills-home" role="tabpanel" aria-labelledby="pills-home-tab">
                        <form method="POST" wire:submit.prevent="submitChangeInfo">
                            <?php echo csrf_field(); ?>
                            <div class="wrap-login w-100">
                                <h4 class="mtext-109 cl2 p-b-30 txt-left">Thông tin cá nhân</h4>
                                
                                

                                <div class="m-t-20">
                                    <div class="m-t-20">
                                        <label class="stext-110 cl2">Họ tên:</label>
                                        <input type="text" wire:model="fullName" class="mtext-107 clblack p-l-20 p-r-20 p-t-15 p-b-15 w-full plh2 bglight" />
                                    </div>
                                    <div class="m-t-20">
                                        <label class="stext-110 cl2">Email:</label>
                                        <input type="text" wire:model="email" disabled name="email" class="mtext-107 clblack p-l-20 p-r-20 p-t-15 p-b-15 w-full plh2 bglight" />
                                    </div>
                                    <div class="m-t-20">
                                        <label class="stext-110 cl2">Số điện thoại:</label>
                                        <input type="text" wire:model="phone" class="mtext-107 clblack p-l-20 p-r-20 p-t-15 p-b-15 w-full plh2 bglight" />
                                    </div>
                                    <div class="m-t-20">
                                        <label class="stext-110 cl2">Địa chỉ:</label>
                                        <input type="text" wire:model="address" class="mtext-107 clblack p-l-20 p-r-20 p-t-15 p-b-15 w-full plh2 bglight" />
                                    </div>
                                    <div class="m-t-20">
                                        <label class="stext-110 cl2">Giới tính:</label>
                                        <select wire:model="gender" type="text" name="gender" class="mtext-107 clblack p-l-20 p-r-20 p-t-15 p-b-15 w-full plh2 bglight">
                                            <option value="Name">Nam</option>
                                            <option value="Nữ">Nữ</option>
                                        </select>
                                    </div>
                                </div>
                                <button type="submit" class="flex-c-m stext-101 cl0 size-116 bg3 m-t-30 hov-btn3 p-lr-15 trans-04 pointer ">
                                    Lưu thay đổi
                                </button>
                            </div>      
                        </form>
                    </div>
                    <div class="tab-pane <?php echo e($panelShow == 'security' ? 'active' : ''); ?>" id="pills-profile" role="tabpanel" aria-labelledby="pills-profile-tab">
                        <form wire:submit.prevent="submitChangePassword" method="POST" action=<?php echo e(route('submitLogin')); ?>>
                            <?php echo csrf_field(); ?>
                            <div class="wrap-login w-100">
                                <h4 class="mtext-109 cl2 p-b-30 txt-left">Bảo mật</h4>
                
                                <div class="m-t-20">
                                    <div class="m-t-20">
                                        <label class="stext-110 cl2">Mật khẩu hiện tại:</label>
                                        <input type="password" wire:model="password" class="mtext-107 clblack p-l-20 p-r-20 p-t-15 p-b-15 w-full plh2 bglight" />
                                        <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                    <div class="m-t-20">
                                        <label class="stext-110 cl2">Mật khẩu mới:</label>
                                        <input type="password" wire:model="newPassword" class="mtext-107 clblack p-l-20 p-r-20 p-t-15 p-b-15 w-full plh2 bglight" />
                                        <?php $__errorArgs = ['newPassword'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                    <div class="m-t-20">
                                        <label class="stext-110 cl2">Xác nhận mật lại mật khẩu mới:</label>
                                        <input type="password" wire:model="newPassword_confirmation" class="mtext-107 clblack p-l-20 p-r-20 p-t-15 p-b-15 w-full plh2 bglight" />
                                        <?php $__errorArgs = ['newPassword_confirmation'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                                <button type="submit" class="flex-c-m stext-101 cl0 size-116 bg3 m-t-30 hov-btn3 p-lr-15 trans-04 pointer ">
                                    Lưu thay đổi
                                </button>
                            </div>      
                        </form>
                    </div>
                    <div class="tab-pane <?php echo e($panelShow == 'order' ? 'active' : ''); ?>" id="pills-profile" role="tabpanel" aria-labelledby="pills-profile-tab">
                        <div class="wrap-table-shopping-cart">

                            <table class="table-shopping-cart">
                                <tr class="table_head">
                                    <th class="column-1">Mã</th>
                                    <th class="column-2">Ngày đặt</th>
                                    <th class="column-3">Tổng</th>
                                    <th class="column-4">Trạng thái</th>
                                    <th class="column-5">Hoạt động</th>
                                </tr>
    
                                <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    
                                <tr class="table_row">
                                    <td class="column-1">
                                        <?php echo e($order->id); ?>

                                    </td>
                                    <td class="column-2">
                                        <?php echo e($order->created_at); ?>

                                    </td>
                                    <td class="column-3"><?php echo e(number_format($order->total, 0, '.', ',')); ?> VND</td>
                                    <td class="column-4">
                                        <?php echo e($order->status); ?>

                                    </td>
                                    <td class="column-5">
                                        <a href="/home/track_order/<?php echo e($order->id); ?>">Xem chi tiết</a>
                                    </td>
                                </tr>
    
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div><?php /**PATH C:\xampp\htdocs\NL_NTN\resources\views/livewire/profile.blade.php ENDPATH**/ ?>