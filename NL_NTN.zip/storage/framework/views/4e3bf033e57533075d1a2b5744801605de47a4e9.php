

<?php $__env->startSection('title', "Kiểm tra hóa đơn | NTN Shop"); ?>

<?php $__env->startSection('content'); ?>
<!-- breadcrumb -->
<div class="container">
    <div class="bread-crumb m-l-25 m-r--38 m-lr-0-xl">
        <a href="/home" class="stext-109 cl8 hov-cl1 trans-04">
            Trang chủ
            <i class="fa fa-angle-right m-l-9 m-r-10" aria-hidden="true"></i>
        </a>

        <span class="stext-109 cl4">
            Giỏ hàng
        </span>
    </div>

    <div class="row invoice">
        <!-- title row -->
        <div class="invoice-header col-12">
            <p class="ltext-103 text-center cl5">Hóa đơn</p>
            <p class='stext-103 text-center cl5'>Ngày lập: <?php echo e($created_order); ?></p>
        </div>

        <div class="col-sm-12 col-lg-4 m-t-20">
            <div class="invoice-col bor10 p-lr-40 p-t-30 p-b-40 m-r-20 m-lr-0-xl p-lr-15-sm">
                <p class="mtext-103 cl5 m-b-10">Khách hàng: </p>
                <address>
                    <strong class="stext-103 cl5">Tên: </strong> <?php echo e($order->user->fullname); ?><br>
                    <strong class="stext-103 cl5">Địa chỉ:</strong> <?php echo e($order->user->address); ?>

                    <br><strong class='stext-103 cl5'>Số điện thoại:</strong> <?php echo e($order->user->phone); ?>

                    <br><strong class="stext-103 cl5">Email:</strong> <?php echo e($order->user->email); ?>

                </address>
            </div>
        </div>


        <div class="col-sm-12 col-lg-4 m-t-20 bor10">
            <div class="invoice-col p-lr-40 p-t-30 p-b-40 m-r-40 m-lr-0-xl p-lr-15-sm">
                <p class="mtext-103 cl5 m-b-10">Hóa đơn: </p>
                <b class="stext-103 cl5">Đơn hàng: #<?php echo e($order->id); ?></b>
                <br/>
                <b class="stext-103 cl5">Ngày thanh toán:</b>
                    <?php if($order->status_payment == 0): ?>
                        Chưa thanh toán 
                        <?php if($order->payment_method == 'VNPay'): ?> (<a href="/home/process/vnpay/<?php echo e($order->id); ?>">Thanh toán ngay</a>)
                        <?php elseif($order->payment_method == 'MoMo'): ?> (<a href="/home/process/momo/<?php echo e($order->id); ?>">Thanh toán ngay</a>)
                        <?php endif; ?>   
                    <?php else: ?>
                        Đã thanh toán
                    <?php endif; ?>
                <br/>
                <b class="stext-103 cl5">Tình trạng:</b> <?php echo e($order->status); ?>

            </div>
        </div>

        <!-- info row -->
        <div class="invoice-info m-b-20 col-12 m-t-20">

            <div class="wrap-table-shopping-cart m-t-20">
                    <table class="table-shopping-cart">
                        <tr class="table_head">
                            <th class="column-1">Mã sản phẩm</th>
                            <th class="column-2">Tên sản phẩm</th>
                            <th class="column-3">Số lượng</th>
                            <th class="column-4">Giá</th>
                            <th class="column-4">Bảo hành</th>
                            <th class="column-5">Thành tiền</th>
                        </tr>
                        <?php $__currentLoopData = $order_details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order_detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr class="text-left">
                                <td class="column-1 p-t-10 p-b-10"><?php echo e($order_detail->product->id); ?></td>
                                <td class="column-2"><?php echo e($order_detail->product->name); ?></td>
                                <td class="column-3"><?php echo e($order_detail->quantity); ?></td>
                                <td class="column-4"><?php echo e(number_format($order_detail->product->price)); ?> VNĐ</td>
                                <td class="column-4">1 tháng kể từ ngày lập hóa đơn</td>
                                <td class="column-5"><?php echo e(number_format($order_detail->amount * $order_detail->quantity, 0, ',', '.')); ?> VNĐ</td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </table>
                </div>
                <!-- /.col -->
            </div>
            <div class="col-md-6">
                <p class="lead">Phương thức thanh toán: <b><?php echo e($order->payment_method); ?></b></p>

                <p class="text-muted well well-sm no-shadow" style="margin-top: 10px;">
                    <?php if($order->payment_method == 'momo'): ?>
                        Đơn hàng đã được thanh toán qua momo.
                    <?php else: ?>
                        Đơn hàng được thanh toán bằng tiền mặt khi nhận hàng.
                    <?php endif; ?>
                    <br><br>
                    Trong thời gian bảo hành nếu có bất cứ vấn đề gì
                    xin hãy liên hệ qua email hoặc số điện thoại của cửa hàng.
                    <br><br>
                    Số điện thoại: 099 978 9889<br>
                    Email: ntnsotre@gmail.com
                </p>
            </div>
            <div class="col-md-6">
                <p class="lead">Tổng thành tiền</p>
                <br>
                <div class="table-responsive">
                    <table class="table">
                        <tbody>
                            <?php if(!is_null($order->promotion)): ?>
                            <tr>
                                <th>Khuyến mãi (<?php echo e($order->promotion->percent); ?>%)</th>
                                <td>
                                    <?php echo e(number_format($order->promotion->percent * $order->total / 100, 0, ',', '.')); ?> VNĐ
                                </td>
                            </tr>
                            <?php endif; ?>
                            <tr>
                                <th>VAT:</th>
                                <td>Sản phẩm đã bao gồm VAT</td>
                            </tr>
                            <tr>
                                <th>Tổng:</th>
                                <td><?php echo e(number_format($order->total, 0, ',', '.')); ?> VNĐ</td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

        <div class="m-b-10 m-t-10 text-right">
            <div class="d-flex justify-content-end m-l-auto">
                
                <button onclick="PrintElem()" class="flex-c-m stext-101 cl0 p-t-10 p-b-10 bg3 hov-btn3 p-lr-15 trans-04 pointer" style="margin-right: 5px;">
                    <i class="fa fa-download m-r-5"></i>
                    In Hoá Đơn
                </button>
            </div>
        </div>

    </div>



</div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>

    <script>
        function PrintElem()
        {
            var mywindow = window.open('', 'PRINT', 'height=1000,width=700');

            mywindow.document.write(
                '<html><head><link href="https://colorlib.com/client_template/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet"><link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet"><link href="http://localhost:8000/client_template/css/util.css" rel="stylesheet"><link href="http://localhost:8000/client_template/css/main.css" rel="stylesheet"></head><body>'
            );
            mywindow.document.write('<div>' + document.querySelector('.invoice').innerHTML  + '</div>');
            mywindow.document.write('</body></html>');

            mywindow.document.close(); // necessary for IE >= 10
            mywindow.focus(); // necessary for IE >= 10*/

            mywindow.print();
            // mywindow.close();

            return true;
        }
    </script>

<?php $__env->stopPush(); ?>
<?php echo $__env->make('client.template.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\NL_NTN\resources\views/client/back/track_order.blade.php ENDPATH**/ ?>