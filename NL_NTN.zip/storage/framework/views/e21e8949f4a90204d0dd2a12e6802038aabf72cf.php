

<?php $__env->startSection('title', "Chi tiết sản phẩm | NTN Shop"); ?>

<?php $__env->startSection('content'); ?>

<div>
    <!-- breadcrumb -->
    <div class="container">
        <div class="bread-crumb flex-w p-l-25 p-r-15 p-t-30 p-lr-0-lg">
            <a href="/home" class="stext-109 cl8 hov-cl1 trans-04">
                Trang Chủ
                <i class="fa fa-angle-right m-l-9 m-r-10" aria-hidden="true"></i>
            </a>

            <a href="product.html" class="stext-109 cl8 hov-cl1 trans-04">
                <?php echo e($product->category->name_type); ?>

                <i class="fa fa-angle-right m-l-9 m-r-10" aria-hidden="true"></i>
            </a>

            <span class="stext-109 cl4">
                <?php echo e($product->name); ?>

            </span>
        </div>
    </div>

    <!-- Product Detail -->
    <section class="sec-product-detail bg0 p-t-65 p-b-60">
        <div class="container">
            <div class="row">
                <div class="col-md-6 col-lg-7 p-b-30">
                    <div class="p-l-25 p-r-30 p-lr-0-lg">
                        <div class="wrap-slick3 flex-sb flex-w">
                            <div class="wrap-slick3-dots"></div>
                            <div class="wrap-slick3-arrows flex-sb-m flex-w"></div>

                            <div class="slick3 gallery-lb">
                                <?php $__currentLoopData = $images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="item-slick3" data-thumb=<?php echo e(asset('/images/products/' . $image->name)); ?>>
                                    <div class="wrap-pic-w pos-relative">
                                        <img src=<?php echo e(asset('/images/products/' . $image->name)); ?> alt="IMG-PRODUCT">

                                        <a class="flex-c-m size-108 how-pos1 bor0 fs-16 cl10 bg0 hov-btn3 trans-04" href=<?php echo e(asset('/images/products/' . $image->name)); ?>>
                                            <i class="fa fa-expand"></i>
                                        </a>
                                    </div>
                                </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-md-6 col-lg-5 p-b-30">
                    <div class="p-r-50 p-t-5 p-lr-0-lg">
                        <h4 class="mtext-105 cl2 js-name-detail p-b-14">
                            <?php echo e($product->name); ?>

                        </h4>

                        <span class="mtext-106 cl2">
                            <?php echo e(number_format($product->price, 3, ',', '.')); ?> VND
                        </span>

                        <p class="stext-102 cl3 p-t-23">
                            <?php echo e(substr($product->description, 0, 200)); ?>

                        </p>

                        <!--  -->
                        <div class="p-t-33">
                            

                            <div class="flex-w flex-l-m p-b-10">
                                <div class="size-204 flex-w flex-m respon6-next">
                                    <div class="wrap-num-product flex-w m-r-20 m-tb-10">
                                        <div class="btn-num-product-down cl8 hov-btn3 trans-04 flex-c-m">
                                            <i class="fs-16 zmdi zmdi-minus"></i>
                                        </div>

                                        <input class="mtext-104 cl3 txt-center num-product num-product-detail" type="number" name="num-product" value="1">

                                        <div class="btn-num-product-up cl8 hov-btn3 trans-04 flex-c-m">
                                            <i class="fs-16 zmdi zmdi-plus"></i>
                                        </div>
                                    </div>
                                    <input type="hidden" class="id-product" value=<?php echo e($product->id); ?>>

                                    <button class="flex-c-m stext-101 cl0 size-101 bg1 bor1 hov-btn1 p-lr-15 trans-04 js-addcart-product-detail">
                                        Thêm vào giỏ hàng
                                    </button>
                                </div>
                            </div>
                        </div>

                        <!--  -->
                        
                    </div>
                </div>
            </div>

            <div class="bor10 m-t-50 p-t-43 p-b-40">
                <!-- Tab01 -->
                <div class="tab01">
                    <!-- Nav tabs -->
                    <ul class="nav nav-tabs" role="tablist">
                        <li class="nav-item p-b-10">
                            <a class="nav-link active" data-toggle="tab" href="#description" role="tab">Mô tả</a>
                        </li>

                        

                        <li class="nav-item p-b-10">
                            <a class="nav-link" data-toggle="tab" href="#reviews" role="tab">Đánh giá (<?php echo e($totalReviews); ?>)</a>
                        </li>
                    </ul>

                    <!-- Tab panes -->
                    <div class="tab-content p-t-43">
                        <!-- - -->
                        <div class="tab-pane fade show active" id="description" role="tabpanel">
                            <div class="how-pos2 p-lr-15-md">
                                <p class="stext-102 cl6">
                                    <?php echo e($product->description); ?>

                                </p>
                            </div>
                        </div>

                        <!-- - -->
                        

                        <!-- - -->
                        <div class="tab-pane fade" id="reviews" role="tabpanel">
                            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('review', ['id' => $product->id])->html();
} elseif ($_instance->childHasBeenRendered('TnL7J0z')) {
    $componentId = $_instance->getRenderedChildComponentId('TnL7J0z');
    $componentTag = $_instance->getRenderedChildComponentTagName('TnL7J0z');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('TnL7J0z');
} else {
    $response = \Livewire\Livewire::mount('review', ['id' => $product->id]);
    $html = $response->html();
    $_instance->logRenderedChild('TnL7J0z', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="bg6 flex-c-m flex-w size-302 m-t-73 p-tb-15">
            <span class="stext-107 cl6 p-lr-25">
                SKU: <?php echo e($product->id); ?>

            </span>

            <span class="stext-107 cl6 p-lr-25">
                Danh mục: <?php echo e($product->category->name_type); ?>

            </span>
        </div>
    </section>

    <!-- Related Products -->
    <section class="sec-relate-product bg0 p-t-45 p-b-105">
        <div class="container">
            <div class="p-b-45">
                <h3 class="ltext-106 cl5 txt-center">
                    Sản phẩm liên quan
                </h3>
            </div>

            <!-- Slide2 -->
            <div class="wrap-slick2">
                <div class="slick2">

                    <?php $__currentLoopData = $productsRelated; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $productRelated): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="item-slick2 p-l-15 p-r-15 p-t-15 p-b-15">
                        <!-- Block2 -->
                        <div class="block2">
                            <div class="block2-pic hov-img0">
                                <img src=<?php echo e(count($productRelated->images) > 0 ? asset('/images/products/' . $productRelated->images[0]->name) : ''); ?> alt="IMG-PRODUCT">

                                <button type="button" class="block2-btn flex-c-m stext-103 cl2 size-102 bg0 bor2 hov-btn1 p-lr-15 trans-04 js-show-modal1">
                                    Xem Nhanh
                                </button>
                                <input type="hidden" class="idProduct" value=<?php echo e($productRelated->id); ?> />
                            </div>

                            <div class="block2-txt flex-w flex-t p-t-14">
                                <div class="block2-txt-child1 flex-col-l ">
                                    <a href="/home/product_detail/<?php echo e($productRelated->id); ?>" class="stext-104 cl4 hov-cl1 trans-04 js-name-b2 p-b-6">
                                        <?php echo e($productRelated->name); ?>

                                    </a>

                                    <span class="stext-105 cl3">
                                        <?php echo e(number_format($productRelated->price, 3, ',', '.')); ?>

                                    </span>
                                </div>

                                
                            </div>
                        </div>
                    </div>
                    
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    
                </div>
            </div>
        </div>
    </section>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
    const quickViewBtn = document.querySelectorAll('.js-show-modal1');
    const idProducts = document.querySelectorAll('.idProduct');
    const numProduct = document.querySelector('.num-product-detail');
    const addToCartBtn = document.querySelector('.js-addcart-product-detail');
    const idProduct = document.querySelector('.id-product');

    quickViewBtn.forEach((btn, index) => {
        btn.addEventListener('click', () => {
            Livewire.emit('viewProduct', idProducts[index].value);
        });
    });  

    addToCartBtn.addEventListener('click', () => {
        const {value} = numProduct;

        Livewire.emit('submitAddCart', {
            idProductAdd: idProduct.value,
            qtyProductAdd: numProduct.value
        });
    });
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('client.template.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\NL_NTN\resources\views/client/back/product_detail.blade.php ENDPATH**/ ?>