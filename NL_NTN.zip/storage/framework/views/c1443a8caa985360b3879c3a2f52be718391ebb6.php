

<?php $__env->startSection('title', "Thanh Toán | NTN Shop"); ?>

<?php $__env->startSection('content'); ?>

<!-- breadcrumb -->
<div class="container">
    <div class="bread-crumb flex-w p-l-25 p-r-15 p-t-30 p-lr-0-lg">
        <a href="/home" class="stext-109 cl8 hov-cl1 trans-04">
            Trang chủ
            <i class="fa fa-angle-right m-l-9 m-r-10" aria-hidden="true"></i>
        </a>

        <a href="/home/payment" class="stext-109 cl8 hov-cl1 trans-04">
            Giỏ Hàng
            <i class="fa fa-angle-right m-l-9 m-r-10" aria-hidden="true"></i>
        </a>

        <span class="stext-109 cl4">
            Thanh toán
        </span>
    </div>
</div>

<!-- Title page -->
<?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('checkout', ['products' => $products, 'total' => $total])->html();
} elseif ($_instance->childHasBeenRendered('keBsnBW')) {
    $componentId = $_instance->getRenderedChildComponentId('keBsnBW');
    $componentTag = $_instance->getRenderedChildComponentTagName('keBsnBW');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('keBsnBW');
} else {
    $response = \Livewire\Livewire::mount('checkout', ['products' => $products, 'total' => $total]);
    $html = $response->html();
    $_instance->logRenderedChild('keBsnBW', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('client.template.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\NL_NTN\resources\views/client/back/checkout.blade.php ENDPATH**/ ?>