@extends('admin.template.master')

@section('title', "Home | Admin - NTN Shop")

@section('heading', "")

@section('des_heading', "")

@section('x_heading', "W E L C O M E")

@section('content')

<div class="row justify-content-center align-items-center ">
    <div class="col text-center">
        <img src="https://media1.giphy.com/media/ka5wTox0hgO1OP0EPF/giphy.gif" width="80%" class="img-fluid" alt="">
    </div>
</div>

@stop
