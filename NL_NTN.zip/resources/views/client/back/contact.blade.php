@extends('client.template.master')

@section('title', "Contact | NTN Shop")

@section('content')

@stop