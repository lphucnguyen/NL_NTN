@extends('home.home')

@section('title', "Login")

@section('contentt')
    <h1>Dang nhap</h1>
    <form action="">
        <input type="text" placeholder="TK">
        <input type="text" placeholder="TK">
        <input type="text" placeholder="TK">
        <input type="text" placeholder="TK">
        <input type="text" placeholder="TK">

        <button type="submit">Login</button>
    </form>
@stop