<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!--===============================================================================================-->
    <link rel="stylesheet" type="text/css"
        href="https://preview.colorlib.com/theme/cozastore/vendor/bootstrap/css/bootstrap.min.css">
    <!--===============================================================================================-->
    <link rel="stylesheet" type="text/css"
        href="{{ asset('client_template/fonts/font-awesome-4.7.0/css/font-awesome.min.css') }}">
    <!--===============================================================================================-->
    <link rel="stylesheet" type="text/css"
        href="https://cdnjs.cloudflare.com/ajax/libs/material-design-iconic-font/2.2.0/css/material-design-iconic-font.min.css">
    <!--===============================================================================================-->
    <link rel="stylesheet" type="text/css"
        href="https://preview.colorlib.com/theme/cozastore/fonts/linearicons-v1.0.0/icon-font.min.css">
    <!--===============================================================================================-->
    <link rel="stylesheet" type="text/css"
        href="https://preview.colorlib.com/theme/cozastore/vendor/animate/animate.css">
    <!--===============================================================================================-->
    <link rel="stylesheet" type="text/css"
        href="https://preview.colorlib.com/theme/cozastore/vendor/css-hamburgers/hamburgers.min.css">
    <!--===============================================================================================-->
    <link rel="stylesheet" type="text/css"
        href="https://preview.colorlib.com/theme/cozastore/vendor/animsition/css/animsition.min.css">
    <!--===============================================================================================-->
    <link rel="stylesheet" type="text/css"
        href="https://preview.colorlib.com/theme/cozastore/vendor/select2/select2.min.css">
    <!--===============================================================================================-->
    <link rel="stylesheet" type="text/css"
        href="https://preview.colorlib.com/theme/cozastore/vendor/daterangepicker/daterangepicker.css">
    <!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="https://preview.colorlib.com/theme/cozastore/vendor/slick/slick.css">
    <!--===============================================================================================-->
    <link rel="stylesheet" type="text/css"
        href="https://preview.colorlib.com/theme/cozastore/vendor/MagnificPopup/magnific-popup.css">
    <!--===============================================================================================-->
    <link rel="stylesheet" type="text/css"
        href="https://preview.colorlib.com/theme/cozastore/vendor/perfect-scrollbar/perfect-scrollbar.css">
    <!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="{{ asset('client_template/css/util.css') }}">
    <link rel="stylesheet" type="text/css" href="{{ asset('client_template/css/main.css') }}">
    <!--===============================================================================================-->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" >

    <style>
        /*!
 * Bootstrap v4.0.0-beta (https://getbootstrap.com)
 * Copyright 2011-2017 The Bootstrap Authors
 * Copyright 2011-2017 Twitter, Inc.
 * Licensed under MIT (https://github.com/twbs/bootstrap/blob/master/LICENSE)
 */@media print{*,::after,::before{text-shadow:none!important;box-shadow:none!important}a,a:visited{text-decoration:underline}abbr[title]::after{content:" (" attr(title) ")"}pre{white-space:pre-wrap!important}blockquote,pre{border:1px solid #999;page-break-inside:avoid}thead{display:table-header-group}img,tr{page-break-inside:avoid}h2,h3,p{orphans:3;widows:3}h2,h3{page-break-after:avoid}.navbar{display:none}.badge{border:1px solid #000}.table{border-collapse:collapse!important}.table td,.table th{background-color:#fff!important}.table-bordered td,.table-bordered th{border:1px solid #ddd!important}}html{box-sizing:border-box;font-family:sans-serif;line-height:1.15;-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;-ms-overflow-style:scrollbar;-webkit-tap-highlight-color:transparent}*,::after,::before{box-sizing:inherit}@-ms-viewport{width:device-width}article,aside,dialog,figcaption,figure,footer,header,hgroup,main,nav,section{display:block}body{margin:0;font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,"Helvetica Neue",Arial,sans-serif;font-size:1rem;font-weight:400;line-height:1.5;color:#212529;background-color:#fff}[tabindex="-1"]:focus{outline:0!important}hr{box-sizing:content-box;height:0;overflow:visible}h1,h2,h3,h4,h5,h6{margin-top:0;margin-bottom:.5rem}p{margin-top:0;margin-bottom:1rem}abbr[data-original-title],abbr[title]{text-decoration:underline;-webkit-text-decoration:underline dotted;text-decoration:underline dotted;cursor:help;border-bottom:0}address{margin-bottom:1rem;font-style:normal;line-height:inherit}dl,ol,ul{margin-top:0;margin-bottom:1rem}ol ol,ol ul,ul ol,ul ul{margin-bottom:0}dt{font-weight:700}dd{margin-bottom:.5rem;margin-left:0}blockquote{margin:0 0 1rem}dfn{font-style:italic}b,strong{font-weight:bolder}small{font-size:80%}sub,sup{position:relative;font-size:75%;line-height:0;vertical-align:baseline}sub{bottom:-.25em}sup{top:-.5em}a{color:#007bff;text-decoration:none;background-color:transparent;-webkit-text-decoration-skip:objects}a:hover{color:#0056b3;text-decoration:underline}a:not([href]):not([tabindex]){color:inherit;text-decoration:none}a:not([href]):not([tabindex]):focus,a:not([href]):not([tabindex]):hover{color:inherit;text-decoration:none}a:not([href]):not([tabindex]):focus{outline:0}code,kbd,pre,samp{font-family:monospace,monospace;font-size:1em}pre{margin-top:0;margin-bottom:1rem;overflow:auto}figure{margin:0 0 1rem}img{vertical-align:middle;border-style:none}svg:not(:root){overflow:hidden}[role=button],a,area,button,input,label,select,summary,textarea{-ms-touch-action:manipulation;touch-action:manipulation}table{border-collapse:collapse}caption{padding-top:.75rem;padding-bottom:.75rem;color:#868e96;text-align:left;caption-side:bottom}th{text-align:left}label{display:inline-block;margin-bottom:.5rem}button:focus{outline:1px dotted;outline:5px auto -webkit-focus-ring-color}button,input,optgroup,select,textarea{margin:0;font-family:inherit;font-size:inherit;line-height:inherit}button,input{overflow:visible}button,select{text-transform:none}[type=reset],[type=submit],button,html [type=button]{-webkit-appearance:button}[type=button]::-moz-focus-inner,[type=reset]::-moz-focus-inner,[type=submit]::-moz-focus-inner,button::-moz-focus-inner{padding:0;border-style:none}input[type=checkbox],input[type=radio]{box-sizing:border-box;padding:0}input[type=date],input[type=datetime-local],input[type=month],input[type=time]{-webkit-appearance:listbox}textarea{overflow:auto;resize:vertical}fieldset{min-width:0;padding:0;margin:0;border:0}legend{display:block;width:100%;max-width:100%;padding:0;margin-bottom:.5rem;font-size:1.5rem;line-height:inherit;color:inherit;white-space:normal}progress{vertical-align:baseline}[type=number]::-webkit-inner-spin-button,[type=number]::-webkit-outer-spin-button{height:auto}[type=search]{outline-offset:-2px;-webkit-appearance:none}[type=search]::-webkit-search-cancel-button,[type=search]::-webkit-search-decoration{-webkit-appearance:none}::-webkit-file-upload-button{font:inherit;-webkit-appearance:button}output{display:inline-block}summary{display:list-item}template{display:none}[hidden]{display:none!important}.h1,.h2,.h3,.h4,.h5,.h6,h1,h2,h3,h4,h5,h6{margin-bottom:.5rem;font-family:inherit;font-weight:500;line-height:1.1;color:inherit}.h1,h1{font-size:2.5rem}.h2,h2{font-size:2rem}.h3,h3{font-size:1.75rem}.h4,h4{font-size:1.5rem}.h5,h5{font-size:1.25rem}.h6,h6{font-size:1rem}.lead{font-size:1.25rem;font-weight:300}.display-1{font-size:6rem;font-weight:300;line-height:1.1}.display-2{font-size:5.5rem;font-weight:300;line-height:1.1}.display-3{font-size:4.5rem;font-weight:300;line-height:1.1}.display-4{font-size:3.5rem;font-weight:300;line-height:1.1}hr{margin-top:1rem;margin-bottom:1rem;border:0;border-top:1px solid rgba(0,0,0,.1)}.small,small{font-size:80%;font-weight:400}.mark,mark{padding:.2em;background-color:#fcf8e3}.list-unstyled{padding-left:0;list-style:none}.list-inline{padding-left:0;list-style:none}.list-inline-item{display:inline-block}.list-inline-item:not(:last-child){margin-right:5px}.initialism{font-size:90%;text-transform:uppercase}.blockquote{margin-bottom:1rem;font-size:1.25rem}.blockquote-footer{display:block;font-size:80%;color:#868e96}.blockquote-footer::before{content:"\2014 \00A0"}.img-fluid{max-width:100%;height:auto}.img-thumbnail{padding:.25rem;background-color:#fff;border:1px solid #ddd;border-radius:.25rem;transition:all .2s ease-in-out;max-width:100%;height:auto}.figure{display:inline-block}.figure-img{margin-bottom:.5rem;line-height:1}.figure-caption{font-size:90%;color:#868e96}code,kbd,pre,samp{font-family:Menlo,Monaco,Consolas,"Liberation Mono","Courier New",monospace}code{padding:.2rem .4rem;font-size:90%;color:#bd4147;background-color:#f8f9fa;border-radius:.25rem}a>code{padding:0;color:inherit;background-color:inherit}kbd{padding:.2rem .4rem;font-size:90%;color:#fff;background-color:#212529;border-radius:.2rem}kbd kbd{padding:0;font-size:100%;font-weight:700}pre{display:block;margin-top:0;margin-bottom:1rem;font-size:90%;color:#212529}pre code{padding:0;font-size:inherit;color:inherit;background-color:transparent;border-radius:0}.pre-scrollable{max-height:340px;overflow-y:scroll}.container{margin-right:auto;margin-left:auto;padding-right:15px;padding-left:15px;width:100%}@media (min-width:576px){.container{max-width:540px}}@media (min-width:768px){.container{max-width:720px}}@media (min-width:992px){.container{max-width:960px}}@media (min-width:1200px){.container{max-width:1140px}}.container-fluid{width:100%;margin-right:auto;margin-left:auto;padding-right:15px;padding-left:15px;width:100%}.row{display:-ms-flexbox;display:flex;-ms-flex-wrap:wrap;flex-wrap:wrap;margin-right:-15px;margin-left:-15px}.no-gutters{margin-right:0;margin-left:0}.no-gutters>.col,.no-gutters>[class*=col-]{padding-right:0;padding-left:0}.col,.col-1,.col-10,.col-11,.col-12,.col-2,.col-3,.col-4,.col-5,.col-6,.col-7,.col-8,.col-9,.col-auto,.col-lg,.col-lg-1,.col-lg-10,.col-lg-11,.col-lg-12,.col-lg-2,.col-lg-3,.col-lg-4,.col-lg-5,.col-lg-6,.col-lg-7,.col-lg-8,.col-lg-9,.col-lg-auto,.col-md,.col-md-1,.col-md-10,.col-md-11,.col-md-12,.col-md-2,.col-md-3,.col-md-4,.col-md-5,.col-md-6,.col-md-7,.col-md-8,.col-md-9,.col-md-auto,.col-sm,.col-sm-1,.col-sm-10,.col-sm-11,.col-sm-12,.col-sm-2,.col-sm-3,.col-sm-4,.col-sm-5,.col-sm-6,.col-sm-7,.col-sm-8,.col-sm-9,.col-sm-auto,.col-xl,.col-xl-1,.col-xl-10,.col-xl-11,.col-xl-12,.col-xl-2,.col-xl-3,.col-xl-4,.col-xl-5,.col-xl-6,.col-xl-7,.col-xl-8,.col-xl-9,.col-xl-auto{position:relative;width:100%;min-height:1px;padding-right:15px;padding-left:15px}.col{-ms-flex-preferred-size:0;flex-basis:0;-ms-flex-positive:1;flex-grow:1;max-width:100%}.col-auto{-ms-flex:0 0 auto;flex:0 0 auto;width:auto;max-width:none}.col-1{-ms-flex:0 0 8.333333%;flex:0 0 8.333333%;max-width:8.333333%}.col-2{-ms-flex:0 0 16.666667%;flex:0 0 16.666667%;max-width:16.666667%}.col-3{-ms-flex:0 0 25%;flex:0 0 25%;max-width:25%}.col-4{-ms-flex:0 0 33.333333%;flex:0 0 33.333333%;max-width:33.333333%}.col-5{-ms-flex:0 0 41.666667%;flex:0 0 41.666667%;max-width:41.666667%}.col-6{-ms-flex:0 0 50%;flex:0 0 50%;max-width:50%}.col-7{-ms-flex:0 0 58.333333%;flex:0 0 58.333333%;max-width:58.333333%}.col-8{-ms-flex:0 0 66.666667%;flex:0 0 66.666667%;max-width:66.666667%}.col-9{-ms-flex:0 0 75%;flex:0 0 75%;max-width:75%}.col-10{-ms-flex:0 0 83.333333%;flex:0 0 83.333333%;max-width:83.333333%}.col-11{-ms-flex:0 0 91.666667%;flex:0 0 91.666667%;max-width:91.666667%}.col-12{-ms-flex:0 0 100%;flex:0 0 100%;max-width:100%}.order-1{-ms-flex-order:1;order:1}.order-2{-ms-flex-order:2;order:2}.order-3{-ms-flex-order:3;order:3}.order-4{-ms-flex-order:4;order:4}.order-5{-ms-flex-order:5;order:5}.order-6{-ms-flex-order:6;order:6}.order-7{-ms-flex-order:7;order:7}.order-8{-ms-flex-order:8;order:8}.order-9{-ms-flex-order:9;order:9}.order-10{-ms-flex-order:10;order:10}.order-11{-ms-flex-order:11;order:11}.order-12{-ms-flex-order:12;order:12}@media (min-width:576px){.col-sm{-ms-flex-preferred-size:0;flex-basis:0;-ms-flex-positive:1;flex-grow:1;max-width:100%}.col-sm-auto{-ms-flex:0 0 auto;flex:0 0 auto;width:auto;max-width:none}.col-sm-1{-ms-flex:0 0 8.333333%;flex:0 0 8.333333%;max-width:8.333333%}.col-sm-2{-ms-flex:0 0 16.666667%;flex:0 0 16.666667%;max-width:16.666667%}.col-sm-3{-ms-flex:0 0 25%;flex:0 0 25%;max-width:25%}.col-sm-4{-ms-flex:0 0 33.333333%;flex:0 0 33.333333%;max-width:33.333333%}.col-sm-5{-ms-flex:0 0 41.666667%;flex:0 0 41.666667%;max-width:41.666667%}.col-sm-6{-ms-flex:0 0 50%;flex:0 0 50%;max-width:50%}.col-sm-7{-ms-flex:0 0 58.333333%;flex:0 0 58.333333%;max-width:58.333333%}.col-sm-8{-ms-flex:0 0 66.666667%;flex:0 0 66.666667%;max-width:66.666667%}.col-sm-9{-ms-flex:0 0 75%;flex:0 0 75%;max-width:75%}.col-sm-10{-ms-flex:0 0 83.333333%;flex:0 0 83.333333%;max-width:83.333333%}.col-sm-11{-ms-flex:0 0 91.666667%;flex:0 0 91.666667%;max-width:91.666667%}.col-sm-12{-ms-flex:0 0 100%;flex:0 0 100%;max-width:100%}.order-sm-1{-ms-flex-order:1;order:1}.order-sm-2{-ms-flex-order:2;order:2}.order-sm-3{-ms-flex-order:3;order:3}.order-sm-4{-ms-flex-order:4;order:4}.order-sm-5{-ms-flex-order:5;order:5}.order-sm-6{-ms-flex-order:6;order:6}.order-sm-7{-ms-flex-order:7;order:7}.order-sm-8{-ms-flex-order:8;order:8}.order-sm-9{-ms-flex-order:9;order:9}.order-sm-10{-ms-flex-order:10;order:10}.order-sm-11{-ms-flex-order:11;order:11}.order-sm-12{-ms-flex-order:12;order:12}}@media (min-width:768px){.col-md{-ms-flex-preferred-size:0;flex-basis:0;-ms-flex-positive:1;flex-grow:1;max-width:100%}.col-md-auto{-ms-flex:0 0 auto;flex:0 0 auto;width:auto;max-width:none}.col-md-1{-ms-flex:0 0 8.333333%;flex:0 0 8.333333%;max-width:8.333333%}.col-md-2{-ms-flex:0 0 16.666667%;flex:0 0 16.666667%;max-width:16.666667%}.col-md-3{-ms-flex:0 0 25%;flex:0 0 25%;max-width:25%}.col-md-4{-ms-flex:0 0 33.333333%;flex:0 0 33.333333%;max-width:33.333333%}.col-md-5{-ms-flex:0 0 41.666667%;flex:0 0 41.666667%;max-width:41.666667%}.col-md-6{-ms-flex:0 0 50%;flex:0 0 50%;max-width:50%}.col-md-7{-ms-flex:0 0 58.333333%;flex:0 0 58.333333%;max-width:58.333333%}.col-md-8{-ms-flex:0 0 66.666667%;flex:0 0 66.666667%;max-width:66.666667%}.col-md-9{-ms-flex:0 0 75%;flex:0 0 75%;max-width:75%}.col-md-10{-ms-flex:0 0 83.333333%;flex:0 0 83.333333%;max-width:83.333333%}.col-md-11{-ms-flex:0 0 91.666667%;flex:0 0 91.666667%;max-width:91.666667%}.col-md-12{-ms-flex:0 0 100%;flex:0 0 100%;max-width:100%}.order-md-1{-ms-flex-order:1;order:1}.order-md-2{-ms-flex-order:2;order:2}.order-md-3{-ms-flex-order:3;order:3}.order-md-4{-ms-flex-order:4;order:4}.order-md-5{-ms-flex-order:5;order:5}.order-md-6{-ms-flex-order:6;order:6}.order-md-7{-ms-flex-order:7;order:7}.order-md-8{-ms-flex-order:8;order:8}.order-md-9{-ms-flex-order:9;order:9}.order-md-10{-ms-flex-order:10;order:10}.order-md-11{-ms-flex-order:11;order:11}.order-md-12{-ms-flex-order:12;order:12}}@media (min-width:992px){.col-lg{-ms-flex-preferred-size:0;flex-basis:0;-ms-flex-positive:1;flex-grow:1;max-width:100%}.col-lg-auto{-ms-flex:0 0 auto;flex:0 0 auto;width:auto;max-width:none}.col-lg-1{-ms-flex:0 0 8.333333%;flex:0 0 8.333333%;max-width:8.333333%}.col-lg-2{-ms-flex:0 0 16.666667%;flex:0 0 16.666667%;max-width:16.666667%}.col-lg-3{-ms-flex:0 0 25%;flex:0 0 25%;max-width:25%}.col-lg-4{-ms-flex:0 0 33.333333%;flex:0 0 33.333333%;max-width:33.333333%}.col-lg-5{-ms-flex:0 0 41.666667%;flex:0 0 41.666667%;max-width:41.666667%}.col-lg-6{-ms-flex:0 0 50%;flex:0 0 50%;max-width:50%}.col-lg-7{-ms-flex:0 0 58.333333%;flex:0 0 58.333333%;max-width:58.333333%}.col-lg-8{-ms-flex:0 0 66.666667%;flex:0 0 66.666667%;max-width:66.666667%}.col-lg-9{-ms-flex:0 0 75%;flex:0 0 75%;max-width:75%}.col-lg-10{-ms-flex:0 0 83.333333%;flex:0 0 83.333333%;max-width:83.333333%}.col-lg-11{-ms-flex:0 0 91.666667%;flex:0 0 91.666667%;max-width:91.666667%}.col-lg-12{-ms-flex:0 0 100%;flex:0 0 100%;max-width:100%}.order-lg-1{-ms-flex-order:1;order:1}.order-lg-2{-ms-flex-order:2;order:2}.order-lg-3{-ms-flex-order:3;order:3}.order-lg-4{-ms-flex-order:4;order:4}.order-lg-5{-ms-flex-order:5;order:5}.order-lg-6{-ms-flex-order:6;order:6}.order-lg-7{-ms-flex-order:7;order:7}.order-lg-8{-ms-flex-order:8;order:8}.order-lg-9{-ms-flex-order:9;order:9}.order-lg-10{-ms-flex-order:10;order:10}.order-lg-11{-ms-flex-order:11;order:11}.order-lg-12{-ms-flex-order:12;order:12}}@media (min-width:1200px){.col-xl{-ms-flex-preferred-size:0;flex-basis:0;-ms-flex-positive:1;flex-grow:1;max-width:100%}.col-xl-auto{-ms-flex:0 0 auto;flex:0 0 auto;width:auto;max-width:none}.col-xl-1{-ms-flex:0 0 8.333333%;flex:0 0 8.333333%;max-width:8.333333%}.col-xl-2{-ms-flex:0 0 16.666667%;flex:0 0 16.666667%;max-width:16.666667%}.col-xl-3{-ms-flex:0 0 25%;flex:0 0 25%;max-width:25%}.col-xl-4{-ms-flex:0 0 33.333333%;flex:0 0 33.333333%;max-width:33.333333%}.col-xl-5{-ms-flex:0 0 41.666667%;flex:0 0 41.666667%;max-width:41.666667%}.col-xl-6{-ms-flex:0 0 50%;flex:0 0 50%;max-width:50%}.col-xl-7{-ms-flex:0 0 58.333333%;flex:0 0 58.333333%;max-width:58.333333%}.col-xl-8{-ms-flex:0 0 66.666667%;flex:0 0 66.666667%;max-width:66.666667%}.col-xl-9{-ms-flex:0 0 75%;flex:0 0 75%;max-width:75%}.col-xl-10{-ms-flex:0 0 83.333333%;flex:0 0 83.333333%;max-width:83.333333%}.col-xl-11{-ms-flex:0 0 91.666667%;flex:0 0 91.666667%;max-width:91.666667%}.col-xl-12{-ms-flex:0 0 100%;flex:0 0 100%;max-width:100%}.order-xl-1{-ms-flex-order:1;order:1}.order-xl-2{-ms-flex-order:2;order:2}.order-xl-3{-ms-flex-order:3;order:3}.order-xl-4{-ms-flex-order:4;order:4}.order-xl-5{-ms-flex-order:5;order:5}.order-xl-6{-ms-flex-order:6;order:6}.order-xl-7{-ms-flex-order:7;order:7}.order-xl-8{-ms-flex-order:8;order:8}.order-xl-9{-ms-flex-order:9;order:9}.order-xl-10{-ms-flex-order:10;order:10}.order-xl-11{-ms-flex-order:11;order:11}.order-xl-12{-ms-flex-order:12;order:12}}.table{width:100%;max-width:100%;margin-bottom:1rem;background-color:transparent}.table td,.table th{padding:.75rem;vertical-align:top;border-top:1px solid #e9ecef}.table thead th{vertical-align:bottom;border-bottom:2px solid #e9ecef}.table tbody+tbody{border-top:2px solid #e9ecef}.table .table{background-color:#fff}.table-sm td,.table-sm th{padding:.3rem}.table-bordered{border:1px solid #e9ecef}.table-bordered td,.table-bordered th{border:1px solid #e9ecef}.table-bordered thead td,.table-bordered thead th{border-bottom-width:2px}.table-striped tbody tr:nth-of-type(odd){background-color:rgba(0,0,0,.05)}.table-hover tbody tr:hover{background-color:rgba(0,0,0,.075)}.table-primary,.table-primary>td,.table-primary>th{background-color:#b8daff}.table-hover .table-primary:hover{background-color:#9fcdff}.table-hover .table-primary:hover>td,.table-hover .table-primary:hover>th{background-color:#9fcdff}.table-secondary,.table-secondary>td,.table-secondary>th{background-color:#dddfe2}.table-hover .table-secondary:hover{background-color:#cfd2d6}.table-hover .table-secondary:hover>td,.table-hover .table-secondary:hover>th{background-color:#cfd2d6}.table-success,.table-success>td,.table-success>th{background-color:#c3e6cb}.table-hover .table-success:hover{background-color:#b1dfbb}.table-hover .table-success:hover>td,.table-hover .table-success:hover>th{background-color:#b1dfbb}.table-info,.table-info>td,.table-info>th{background-color:#bee5eb}.table-hover .table-info:hover{background-color:#abdde5}.table-hover .table-info:hover>td,.table-hover .table-info:hover>th{background-color:#abdde5}.table-warning,.table-warning>td,.table-warning>th{background-color:#ffeeba}.table-hover .table-warning:hover{background-color:#ffe8a1}.table-hover .table-warning:hover>td,.table-hover .table-warning:hover>th{background-color:#ffe8a1}.table-danger,.table-danger>td,.table-danger>th{background-color:#f5c6cb}.table-hover .table-danger:hover{background-color:#f1b0b7}.table-hover .table-danger:hover>td,.table-hover .table-danger:hover>th{background-color:#f1b0b7}.table-light,.table-light>td,.table-light>th{background-color:#fdfdfe}.table-hover .table-light:hover{background-color:#ececf6}.table-hover .table-light:hover>td,.table-hover .table-light:hover>th{background-color:#ececf6}.table-dark,.table-dark>td,.table-dark>th{background-color:#c6c8ca}.table-hover .table-dark:hover{background-color:#b9bbbe}.table-hover .table-dark:hover>td,.table-hover .table-dark:hover>th{background-color:#b9bbbe}.table-active,.table-active>td,.table-active>th{background-color:rgba(0,0,0,.075)}.table-hover .table-active:hover{background-color:rgba(0,0,0,.075)}.table-hover .table-active:hover>td,.table-hover .table-active:hover>th{background-color:rgba(0,0,0,.075)}.thead-inverse th{color:#fff;background-color:#212529}.thead-default th{color:#495057;background-color:#e9ecef}.table-inverse{color:#fff;background-color:#212529}.table-inverse td,.table-inverse th,.table-inverse thead th{border-color:#32383e}.table-inverse.table-bordered{border:0}.table-inverse.table-striped tbody tr:nth-of-type(odd){background-color:rgba(255,255,255,.05)}.table-inverse.table-hover tbody tr:hover{background-color:rgba(255,255,255,.075)}@media (max-width:991px){.table-responsive{display:block;width:100%;overflow-x:auto;-ms-overflow-style:-ms-autohiding-scrollbar}.table-responsive.table-bordered{border:0}}.form-control{display:block;width:100%;padding:.5rem .75rem;font-size:1rem;line-height:1.25;color:#495057;background-color:#fff;background-image:none;background-clip:padding-box;border:1px solid rgba(0,0,0,.15);border-radius:.25rem;transition:border-color ease-in-out .15s,box-shadow ease-in-out .15s}.form-control::-ms-expand{background-color:transparent;border:0}.form-control:focus{color:#495057;background-color:#fff;border-color:#80bdff;outline:0}.form-control::-webkit-input-placeholder{color:#868e96;opacity:1}.form-control:-ms-input-placeholder{color:#868e96;opacity:1}.form-control::placeholder{color:#868e96;opacity:1}.form-control:disabled,.form-control[readonly]{background-color:#e9ecef;opacity:1}select.form-control:not([size]):not([multiple]){height:calc(2.25rem + 2px)}select.form-control:focus::-ms-value{color:#495057;background-color:#fff}.form-control-file,.form-control-range{display:block}.col-form-label{padding-top:calc(.5rem - 1px * 2);padding-bottom:calc(.5rem - 1px * 2);margin-bottom:0}.col-form-label-lg{padding-top:calc(.5rem - 1px * 2);padding-bottom:calc(.5rem - 1px * 2);font-size:1.25rem}.col-form-label-sm{padding-top:calc(.25rem - 1px * 2);padding-bottom:calc(.25rem - 1px * 2);font-size:.875rem}.col-form-legend{padding-top:.5rem;padding-bottom:.5rem;margin-bottom:0;font-size:1rem}.form-control-plaintext{padding-top:.5rem;padding-bottom:.5rem;margin-bottom:0;line-height:1.25;border:solid transparent;border-width:1px 0}.form-control-plaintext.form-control-lg,.form-control-plaintext.form-control-sm,.input-group-lg>.form-control-plaintext.form-control,.input-group-lg>.form-control-plaintext.input-group-addon,.input-group-lg>.input-group-btn>.form-control-plaintext.btn,.input-group-sm>.form-control-plaintext.form-control,.input-group-sm>.form-control-plaintext.input-group-addon,.input-group-sm>.input-group-btn>.form-control-plaintext.btn{padding-right:0;padding-left:0}.form-control-sm,.input-group-sm>.form-control,.input-group-sm>.input-group-addon,.input-group-sm>.input-group-btn>.btn{padding:.25rem .5rem;font-size:.875rem;line-height:1.5;border-radius:.2rem}.input-group-sm>.input-group-btn>select.btn:not([size]):not([multiple]),.input-group-sm>select.form-control:not([size]):not([multiple]),.input-group-sm>select.input-group-addon:not([size]):not([multiple]),select.form-control-sm:not([size]):not([multiple]){height:calc(1.8125rem + 2px)}.form-control-lg,.input-group-lg>.form-control,.input-group-lg>.input-group-addon,.input-group-lg>.input-group-btn>.btn{padding:.5rem 1rem;font-size:1.25rem;line-height:1.5;border-radius:.3rem}.input-group-lg>.input-group-btn>select.btn:not([size]):not([multiple]),.input-group-lg>select.form-control:not([size]):not([multiple]),.input-group-lg>select.input-group-addon:not([size]):not([multiple]),select.form-control-lg:not([size]):not([multiple]){height:calc(2.3125rem + 2px)}.form-group{margin-bottom:1rem}.form-text{display:block;margin-top:.25rem}.form-row{display:-ms-flexbox;display:flex;-ms-flex-wrap:wrap;flex-wrap:wrap;margin-right:-5px;margin-left:-5px}.form-row>.col,.form-row>[class*=col-]{padding-right:5px;padding-left:5px}.form-check{position:relative;display:block;margin-bottom:.5rem}.form-check.disabled .form-check-label{color:#868e96}.form-check-label{padding-left:1.25rem;margin-bottom:0}.form-check-input{position:absolute;margin-top:.25rem;margin-left:-1.25rem}.form-check-input:only-child{position:static}.form-check-inline{display:inline-block}.form-check-inline .form-check-label{vertical-align:middle}.form-check-inline+.form-check-inline{margin-left:.75rem}.invalid-feedback{display:none;margin-top:.25rem;font-size:.875rem;color:#dc3545}.invalid-tooltip{position:absolute;top:100%;z-index:5;display:none;width:250px;padding:.5rem;margin-top:.1rem;font-size:.875rem;line-height:1;color:#fff;background-color:rgba(220,53,69,.8);border-radius:.2rem}.custom-select.is-valid,.form-control.is-valid,.was-validated .custom-select:valid,.was-validated .form-control:valid{border-color:#28a745}.custom-select.is-valid:focus,.form-control.is-valid:focus,.was-validated .custom-select:valid:focus,.was-validated .form-control:valid:focus{box-shadow:0 0 0 .2rem rgba(40,167,69,.25)}.custom-select.is-valid~.invalid-feedback,.custom-select.is-valid~.invalid-tooltip,.form-control.is-valid~.invalid-feedback,.form-control.is-valid~.invalid-tooltip,.was-validated .custom-select:valid~.invalid-feedback,.was-validated .custom-select:valid~.invalid-tooltip,.was-validated .form-control:valid~.invalid-feedback,.was-validated .form-control:valid~.invalid-tooltip{display:block}.form-check-input.is-valid+.form-check-label,.was-validated .form-check-input:valid+.form-check-label{color:#28a745}.custom-control-input.is-valid~.custom-control-indicator,.was-validated .custom-control-input:valid~.custom-control-indicator{background-color:rgba(40,167,69,.25)}.custom-control-input.is-valid~.custom-control-description,.was-validated .custom-control-input:valid~.custom-control-description{color:#28a745}.custom-file-input.is-valid~.custom-file-control,.was-validated .custom-file-input:valid~.custom-file-control{border-color:#28a745}.custom-file-input.is-valid~.custom-file-control::before,.was-validated .custom-file-input:valid~.custom-file-control::before{border-color:inherit}.custom-file-input.is-valid:focus,.was-validated .custom-file-input:valid:focus{box-shadow:0 0 0 .2rem rgba(40,167,69,.25)}.custom-select.is-invalid,.form-control.is-invalid,.was-validated .custom-select:invalid,.was-validated .form-control:invalid{border-color:#dc3545}.custom-select.is-invalid:focus,.form-control.is-invalid:focus,.was-validated .custom-select:invalid:focus,.was-validated .form-control:invalid:focus{box-shadow:0 0 0 .2rem rgba(220,53,69,.25)}.custom-select.is-invalid~.invalid-feedback,.custom-select.is-invalid~.invalid-tooltip,.form-control.is-invalid~.invalid-feedback,.form-control.is-invalid~.invalid-tooltip,.was-validated .custom-select:invalid~.invalid-feedback,.was-validated .custom-select:invalid~.invalid-tooltip,.was-validated .form-control:invalid~.invalid-feedback,.was-validated .form-control:invalid~.invalid-tooltip{display:block}.form-check-input.is-invalid+.form-check-label,.was-validated .form-check-input:invalid+.form-check-label{color:#dc3545}.custom-control-input.is-invalid~.custom-control-indicator,.was-validated .custom-control-input:invalid~.custom-control-indicator{background-color:rgba(220,53,69,.25)}.custom-control-input.is-invalid~.custom-control-description,.was-validated .custom-control-input:invalid~.custom-control-description{color:#dc3545}.custom-file-input.is-invalid~.custom-file-control,.was-validated .custom-file-input:invalid~.custom-file-control{border-color:#dc3545}.custom-file-input.is-invalid~.custom-file-control::before,.was-validated .custom-file-input:invalid~.custom-file-control::before{border-color:inherit}.custom-file-input.is-invalid:focus,.was-validated .custom-file-input:invalid:focus{box-shadow:0 0 0 .2rem rgba(220,53,69,.25)}.form-inline{display:-ms-flexbox;display:flex;-ms-flex-flow:row wrap;flex-flow:row wrap;-ms-flex-align:center;align-items:center}.form-inline .form-check{width:100%}@media (min-width:576px){.form-inline label{display:-ms-flexbox;display:flex;-ms-flex-align:center;align-items:center;-ms-flex-pack:center;justify-content:center;margin-bottom:0}.form-inline .form-group{display:-ms-flexbox;display:flex;-ms-flex:0 0 auto;flex:0 0 auto;-ms-flex-flow:row wrap;flex-flow:row wrap;-ms-flex-align:center;align-items:center;margin-bottom:0}.form-inline .form-control{display:inline-block;width:auto;vertical-align:middle}.form-inline .form-control-plaintext{display:inline-block}.form-inline .input-group{width:auto}.form-inline .form-control-label{margin-bottom:0;vertical-align:middle}.form-inline .form-check{display:-ms-flexbox;display:flex;-ms-flex-align:center;align-items:center;-ms-flex-pack:center;justify-content:center;width:auto;margin-top:0;margin-bottom:0}.form-inline .form-check-label{padding-left:0}.form-inline .form-check-input{position:relative;margin-top:0;margin-right:.25rem;margin-left:0}.form-inline .custom-control{display:-ms-flexbox;display:flex;-ms-flex-align:center;align-items:center;-ms-flex-pack:center;justify-content:center;padding-left:0}.form-inline .custom-control-indicator{position:static;display:inline-block;margin-right:.25rem;vertical-align:text-bottom}.form-inline .has-feedback .form-control-feedback{top:0}}.btn{display:inline-block;font-weight:400;text-align:center;white-space:nowrap;vertical-align:middle;-webkit-user-select:none;-moz-user-select:none;-ms-user-select:none;user-select:none;border:1px solid transparent;padding:.5rem .75rem;font-size:1rem;line-height:1.25;border-radius:.25rem;transition:all .15s ease-in-out}.btn:focus,.btn:hover{text-decoration:none}.btn.focus,.btn:focus{outline:0;box-shadow:0 0 0 3px rgba(0,123,255,.25)}.btn.disabled,.btn:disabled{opacity:.65}.btn.active,.btn:active{background-image:none}a.btn.disabled,fieldset[disabled] a.btn{pointer-events:none}.btn-primary{color:#fff;background-color:#007bff;border-color:#007bff}.btn-primary:hover{color:#fff;background-color:#0069d9;border-color:#0062cc}.btn-primary.focus,.btn-primary:focus{box-shadow:0 0 0 3px rgba(0,123,255,.5)}.btn-primary.disabled,.btn-primary:disabled{background-color:#007bff;border-color:#007bff}.btn-primary.active,.btn-primary:active,.show>.btn-primary.dropdown-toggle{background-color:#0069d9;background-image:none;border-color:#0062cc}.btn-secondary{color:#fff;background-color:#868e96;border-color:#868e96}.btn-secondary:hover{color:#fff;background-color:#727b84;border-color:#6c757d}.btn-secondary.focus,.btn-secondary:focus{box-shadow:0 0 0 3px rgba(134,142,150,.5)}.btn-secondary.disabled,.btn-secondary:disabled{background-color:#868e96;border-color:#868e96}.btn-secondary.active,.btn-secondary:active,.show>.btn-secondary.dropdown-toggle{background-color:#727b84;background-image:none;border-color:#6c757d}.btn-success{color:#fff;background-color:#28a745;border-color:#28a745}.btn-success:hover{color:#fff;background-color:#218838;border-color:#1e7e34}.btn-success.focus,.btn-success:focus{box-shadow:0 0 0 3px rgba(40,167,69,.5)}.btn-success.disabled,.btn-success:disabled{background-color:#28a745;border-color:#28a745}.btn-success.active,.btn-success:active,.show>.btn-success.dropdown-toggle{background-color:#218838;background-image:none;border-color:#1e7e34}.btn-info{color:#fff;background-color:#17a2b8;border-color:#17a2b8}.btn-info:hover{color:#fff;background-color:#138496;border-color:#117a8b}.btn-info.focus,.btn-info:focus{box-shadow:0 0 0 3px rgba(23,162,184,.5)}.btn-info.disabled,.btn-info:disabled{background-color:#17a2b8;border-color:#17a2b8}.btn-info.active,.btn-info:active,.show>.btn-info.dropdown-toggle{background-color:#138496;background-image:none;border-color:#117a8b}.btn-warning{color:#111;background-color:#ffc107;border-color:#ffc107}.btn-warning:hover{color:#111;background-color:#e0a800;border-color:#d39e00}.btn-warning.focus,.btn-warning:focus{box-shadow:0 0 0 3px rgba(255,193,7,.5)}.btn-warning.disabled,.btn-warning:disabled{background-color:#ffc107;border-color:#ffc107}.btn-warning.active,.btn-warning:active,.show>.btn-warning.dropdown-toggle{background-color:#e0a800;background-image:none;border-color:#d39e00}.btn-danger{color:#fff;background-color:#dc3545;border-color:#dc3545}.btn-danger:hover{color:#fff;background-color:#c82333;border-color:#bd2130}.btn-danger.focus,.btn-danger:focus{box-shadow:0 0 0 3px rgba(220,53,69,.5)}.btn-danger.disabled,.btn-danger:disabled{background-color:#dc3545;border-color:#dc3545}.btn-danger.active,.btn-danger:active,.show>.btn-danger.dropdown-toggle{background-color:#c82333;background-image:none;border-color:#bd2130}.btn-light{color:#111;background-color:#f8f9fa;border-color:#f8f9fa}.btn-light:hover{color:#111;background-color:#e2e6ea;border-color:#dae0e5}.btn-light.focus,.btn-light:focus{box-shadow:0 0 0 3px rgba(248,249,250,.5)}.btn-light.disabled,.btn-light:disabled{background-color:#f8f9fa;border-color:#f8f9fa}.btn-light.active,.btn-light:active,.show>.btn-light.dropdown-toggle{background-color:#e2e6ea;background-image:none;border-color:#dae0e5}.btn-dark{color:#fff;background-color:#343a40;border-color:#343a40}.btn-dark:hover{color:#fff;background-color:#23272b;border-color:#1d2124}.btn-dark.focus,.btn-dark:focus{box-shadow:0 0 0 3px rgba(52,58,64,.5)}.btn-dark.disabled,.btn-dark:disabled{background-color:#343a40;border-color:#343a40}.btn-dark.active,.btn-dark:active,.show>.btn-dark.dropdown-toggle{background-color:#23272b;background-image:none;border-color:#1d2124}.btn-outline-primary{color:#007bff;background-color:transparent;background-image:none;border-color:#007bff}.btn-outline-primary:hover{color:#fff;background-color:#007bff;border-color:#007bff}.btn-outline-primary.focus,.btn-outline-primary:focus{box-shadow:0 0 0 3px rgba(0,123,255,.5)}.btn-outline-primary.disabled,.btn-outline-primary:disabled{color:#007bff;background-color:transparent}.btn-outline-primary.active,.btn-outline-primary:active,.show>.btn-outline-primary.dropdown-toggle{color:#fff;background-color:#007bff;border-color:#007bff}.btn-outline-secondary{color:#868e96;background-color:transparent;background-image:none;border-color:#868e96}.btn-outline-secondary:hover{color:#fff;background-color:#868e96;border-color:#868e96}.btn-outline-secondary.focus,.btn-outline-secondary:focus{box-shadow:0 0 0 3px rgba(134,142,150,.5)}.btn-outline-secondary.disabled,.btn-outline-secondary:disabled{color:#868e96;background-color:transparent}.btn-outline-secondary.active,.btn-outline-secondary:active,.show>.btn-outline-secondary.dropdown-toggle{color:#fff;background-color:#868e96;border-color:#868e96}.btn-outline-success{color:#28a745;background-color:transparent;background-image:none;border-color:#28a745}.btn-outline-success:hover{color:#fff;background-color:#28a745;border-color:#28a745}.btn-outline-success.focus,.btn-outline-success:focus{box-shadow:0 0 0 3px rgba(40,167,69,.5)}.btn-outline-success.disabled,.btn-outline-success:disabled{color:#28a745;background-color:transparent}.btn-outline-success.active,.btn-outline-success:active,.show>.btn-outline-success.dropdown-toggle{color:#fff;background-color:#28a745;border-color:#28a745}.btn-outline-info{color:#17a2b8;background-color:transparent;background-image:none;border-color:#17a2b8}.btn-outline-info:hover{color:#fff;background-color:#17a2b8;border-color:#17a2b8}.btn-outline-info.focus,.btn-outline-info:focus{box-shadow:0 0 0 3px rgba(23,162,184,.5)}.btn-outline-info.disabled,.btn-outline-info:disabled{color:#17a2b8;background-color:transparent}.btn-outline-info.active,.btn-outline-info:active,.show>.btn-outline-info.dropdown-toggle{color:#fff;background-color:#17a2b8;border-color:#17a2b8}.btn-outline-warning{color:#ffc107;background-color:transparent;background-image:none;border-color:#ffc107}.btn-outline-warning:hover{color:#fff;background-color:#ffc107;border-color:#ffc107}.btn-outline-warning.focus,.btn-outline-warning:focus{box-shadow:0 0 0 3px rgba(255,193,7,.5)}.btn-outline-warning.disabled,.btn-outline-warning:disabled{color:#ffc107;background-color:transparent}.btn-outline-warning.active,.btn-outline-warning:active,.show>.btn-outline-warning.dropdown-toggle{color:#fff;background-color:#ffc107;border-color:#ffc107}.btn-outline-danger{color:#dc3545;background-color:transparent;background-image:none;border-color:#dc3545}.btn-outline-danger:hover{color:#fff;background-color:#dc3545;border-color:#dc3545}.btn-outline-danger.focus,.btn-outline-danger:focus{box-shadow:0 0 0 3px rgba(220,53,69,.5)}.btn-outline-danger.disabled,.btn-outline-danger:disabled{color:#dc3545;background-color:transparent}.btn-outline-danger.active,.btn-outline-danger:active,.show>.btn-outline-danger.dropdown-toggle{color:#fff;background-color:#dc3545;border-color:#dc3545}.btn-outline-light{color:#f8f9fa;background-color:transparent;background-image:none;border-color:#f8f9fa}.btn-outline-light:hover{color:#fff;background-color:#f8f9fa;border-color:#f8f9fa}.btn-outline-light.focus,.btn-outline-light:focus{box-shadow:0 0 0 3px rgba(248,249,250,.5)}.btn-outline-light.disabled,.btn-outline-light:disabled{color:#f8f9fa;background-color:transparent}.btn-outline-light.active,.btn-outline-light:active,.show>.btn-outline-light.dropdown-toggle{color:#fff;background-color:#f8f9fa;border-color:#f8f9fa}.btn-outline-dark{color:#343a40;background-color:transparent;background-image:none;border-color:#343a40}.btn-outline-dark:hover{color:#fff;background-color:#343a40;border-color:#343a40}.btn-outline-dark.focus,.btn-outline-dark:focus{box-shadow:0 0 0 3px rgba(52,58,64,.5)}.btn-outline-dark.disabled,.btn-outline-dark:disabled{color:#343a40;background-color:transparent}.btn-outline-dark.active,.btn-outline-dark:active,.show>.btn-outline-dark.dropdown-toggle{color:#fff;background-color:#343a40;border-color:#343a40}.btn-link{font-weight:400;color:#007bff;border-radius:0}.btn-link,.btn-link.active,.btn-link:active,.btn-link:disabled{background-color:transparent}.btn-link,.btn-link:active,.btn-link:focus{border-color:transparent;box-shadow:none}.btn-link:hover{border-color:transparent}.btn-link:focus,.btn-link:hover{color:#0056b3;text-decoration:underline;background-color:transparent}.btn-link:disabled{color:#868e96}.btn-link:disabled:focus,.btn-link:disabled:hover{text-decoration:none}.btn-group-lg>.btn,.btn-lg{padding:.5rem 1rem;font-size:1.25rem;line-height:1.5;border-radius:.3rem}.btn-group-sm>.btn,.btn-sm{padding:.25rem .5rem;font-size:.875rem;line-height:1.5;border-radius:.2rem}.btn-block{display:block;width:100%}.btn-block+.btn-block{margin-top:.5rem}input[type=button].btn-block,input[type=reset].btn-block,input[type=submit].btn-block{width:100%}.fade{opacity:0;transition:opacity .15s linear}.fade.show{opacity:1}.collapse{display:none}.collapse.show{display:block}tr.collapse.show{display:table-row}tbody.collapse.show{display:table-row-group}.collapsing{position:relative;height:0;overflow:hidden;transition:height .35s ease}.dropdown,.dropup{position:relative}.dropdown-toggle::after{display:inline-block;width:0;height:0;margin-left:.255em;vertical-align:.255em;content:"";border-top:.3em solid;border-right:.3em solid transparent;border-left:.3em solid transparent}.dropdown-toggle:empty::after{margin-left:0}.dropup .dropdown-menu{margin-top:0;margin-bottom:.125rem}.dropup .dropdown-toggle::after{border-top:0;border-bottom:.3em solid}.dropdown-menu{position:absolute;top:100%;left:0;z-index:1000;display:none;float:left;min-width:10rem;padding:.5rem 0;margin:.125rem 0 0;font-size:1rem;color:#212529;text-align:left;list-style:none;background-color:#fff;background-clip:padding-box;border:1px solid rgba(0,0,0,.15);border-radius:.25rem}.dropdown-divider{height:0;margin:.5rem 0;overflow:hidden;border-top:1px solid #e9ecef}.dropdown-item{display:block;width:100%;padding:.25rem 1.5rem;clear:both;font-weight:400;color:#212529;text-align:inherit;white-space:nowrap;background:0 0;border:0}.dropdown-item:focus,.dropdown-item:hover{color:#16181b;text-decoration:none;background-color:#f8f9fa}.dropdown-item.active,.dropdown-item:active{color:#fff;text-decoration:none;background-color:#007bff}.dropdown-item.disabled,.dropdown-item:disabled{color:#868e96;background-color:transparent}.show>a{outline:0}.dropdown-menu.show{display:block}.dropdown-header{display:block;padding:.5rem 1.5rem;margin-bottom:0;font-size:.875rem;color:#868e96;white-space:nowrap}.btn-group,.btn-group-vertical{position:relative;display:-ms-inline-flexbox;display:inline-flex;vertical-align:middle}.btn-group-vertical>.btn,.btn-group>.btn{position:relative;-ms-flex:0 1 auto;flex:0 1 auto;margin-bottom:0}.btn-group-vertical>.btn:hover,.btn-group>.btn:hover{z-index:2}.btn-group-vertical>.btn.active,.btn-group-vertical>.btn:active,.btn-group-vertical>.btn:focus,.btn-group>.btn.active,.btn-group>.btn:active,.btn-group>.btn:focus{z-index:2}.btn-group .btn+.btn,.btn-group .btn+.btn-group,.btn-group .btn-group+.btn,.btn-group .btn-group+.btn-group,.btn-group-vertical .btn+.btn,.btn-group-vertical .btn+.btn-group,.btn-group-vertical .btn-group+.btn,.btn-group-vertical .btn-group+.btn-group{margin-left:-1px}.btn-toolbar{display:-ms-flexbox;display:flex;-ms-flex-wrap:wrap;flex-wrap:wrap;-ms-flex-pack:start;justify-content:flex-start}.btn-toolbar .input-group{width:auto}.btn-group>.btn:not(:first-child):not(:last-child):not(.dropdown-toggle){border-radius:0}.btn-group>.btn:first-child{margin-left:0}.btn-group>.btn:first-child:not(:last-child):not(.dropdown-toggle){border-top-right-radius:0;border-bottom-right-radius:0}.btn-group>.btn:last-child:not(:first-child),.btn-group>.dropdown-toggle:not(:first-child){border-top-left-radius:0;border-bottom-left-radius:0}.btn-group>.btn-group{float:left}.btn-group>.btn-group:not(:first-child):not(:last-child)>.btn{border-radius:0}.btn-group>.btn-group:first-child:not(:last-child)>.btn:last-child,.btn-group>.btn-group:first-child:not(:last-child)>.dropdown-toggle{border-top-right-radius:0;border-bottom-right-radius:0}.btn-group>.btn-group:last-child:not(:first-child)>.btn:first-child{border-top-left-radius:0;border-bottom-left-radius:0}.btn+.dropdown-toggle-split{padding-right:.5625rem;padding-left:.5625rem}.btn+.dropdown-toggle-split::after{margin-left:0}.btn-group-sm>.btn+.dropdown-toggle-split,.btn-sm+.dropdown-toggle-split{padding-right:.375rem;padding-left:.375rem}.btn-group-lg>.btn+.dropdown-toggle-split,.btn-lg+.dropdown-toggle-split{padding-right:.75rem;padding-left:.75rem}.btn-group-vertical{display:-ms-inline-flexbox;display:inline-flex;-ms-flex-direction:column;flex-direction:column;-ms-flex-align:start;align-items:flex-start;-ms-flex-pack:center;justify-content:center}.btn-group-vertical .btn,.btn-group-vertical .btn-group{width:100%}.btn-group-vertical>.btn+.btn,.btn-group-vertical>.btn+.btn-group,.btn-group-vertical>.btn-group+.btn,.btn-group-vertical>.btn-group+.btn-group{margin-top:-1px;margin-left:0}.btn-group-vertical>.btn:not(:first-child):not(:last-child){border-radius:0}.btn-group-vertical>.btn:first-child:not(:last-child){border-bottom-right-radius:0;border-bottom-left-radius:0}.btn-group-vertical>.btn:last-child:not(:first-child){border-top-left-radius:0;border-top-right-radius:0}.btn-group-vertical>.btn-group:not(:first-child):not(:last-child)>.btn{border-radius:0}.btn-group-vertical>.btn-group:first-child:not(:last-child)>.btn:last-child,.btn-group-vertical>.btn-group:first-child:not(:last-child)>.dropdown-toggle{border-bottom-right-radius:0;border-bottom-left-radius:0}.btn-group-vertical>.btn-group:last-child:not(:first-child)>.btn:first-child{border-top-left-radius:0;border-top-right-radius:0}[data-toggle=buttons]>.btn input[type=checkbox],[data-toggle=buttons]>.btn input[type=radio],[data-toggle=buttons]>.btn-group>.btn input[type=checkbox],[data-toggle=buttons]>.btn-group>.btn input[type=radio]{position:absolute;clip:rect(0,0,0,0);pointer-events:none}.input-group{position:relative;display:-ms-flexbox;display:flex;width:100%}.input-group .form-control{position:relative;z-index:2;-ms-flex:1 1 auto;flex:1 1 auto;width:1%;margin-bottom:0}.input-group .form-control:active,.input-group .form-control:focus,.input-group .form-control:hover{z-index:3}.input-group .form-control,.input-group-addon,.input-group-btn{display:-ms-flexbox;display:flex;-ms-flex-align:center;align-items:center}.input-group .form-control:not(:first-child):not(:last-child),.input-group-addon:not(:first-child):not(:last-child),.input-group-btn:not(:first-child):not(:last-child){border-radius:0}.input-group-addon,.input-group-btn{white-space:nowrap;vertical-align:middle}.input-group-addon{padding:.5rem .75rem;margin-bottom:0;font-size:1rem;font-weight:400;line-height:1.25;color:#495057;text-align:center;background-color:#e9ecef;border:1px solid rgba(0,0,0,.15);border-radius:.25rem}.input-group-addon.form-control-sm,.input-group-sm>.input-group-addon,.input-group-sm>.input-group-btn>.input-group-addon.btn{padding:.25rem .5rem;font-size:.875rem;border-radius:.2rem}.input-group-addon.form-control-lg,.input-group-lg>.input-group-addon,.input-group-lg>.input-group-btn>.input-group-addon.btn{padding:.5rem 1rem;font-size:1.25rem;border-radius:.3rem}.input-group-addon input[type=checkbox],.input-group-addon input[type=radio]{margin-top:0}.input-group .form-control:not(:last-child),.input-group-addon:not(:last-child),.input-group-btn:not(:first-child)>.btn-group:not(:last-child)>.btn,.input-group-btn:not(:first-child)>.btn:not(:last-child):not(.dropdown-toggle),.input-group-btn:not(:last-child)>.btn,.input-group-btn:not(:last-child)>.btn-group>.btn,.input-group-btn:not(:last-child)>.dropdown-toggle{border-top-right-radius:0;border-bottom-right-radius:0}.input-group-addon:not(:last-child){border-right:0}.input-group .form-control:not(:first-child),.input-group-addon:not(:first-child),.input-group-btn:not(:first-child)>.btn,.input-group-btn:not(:first-child)>.btn-group>.btn,.input-group-btn:not(:first-child)>.dropdown-toggle,.input-group-btn:not(:last-child)>.btn-group:not(:first-child)>.btn,.input-group-btn:not(:last-child)>.btn:not(:first-child){border-top-left-radius:0;border-bottom-left-radius:0}.form-control+.input-group-addon:not(:first-child){border-left:0}.input-group-btn{position:relative;font-size:0;white-space:nowrap}.input-group-btn>.btn{position:relative}.input-group-btn>.btn+.btn{margin-left:-1px}.input-group-btn>.btn:active,.input-group-btn>.btn:focus,.input-group-btn>.btn:hover{z-index:3}.input-group-btn:not(:last-child)>.btn,.input-group-btn:not(:last-child)>.btn-group{margin-right:-1px}.input-group-btn:not(:first-child)>.btn,.input-group-btn:not(:first-child)>.btn-group{z-index:2;margin-left:-1px}.input-group-btn:not(:first-child)>.btn-group:active,.input-group-btn:not(:first-child)>.btn-group:focus,.input-group-btn:not(:first-child)>.btn-group:hover,.input-group-btn:not(:first-child)>.btn:active,.input-group-btn:not(:first-child)>.btn:focus,.input-group-btn:not(:first-child)>.btn:hover{z-index:3}.custom-control{position:relative;display:-ms-inline-flexbox;display:inline-flex;min-height:1.5rem;padding-left:1.5rem;margin-right:1rem}.custom-control-input{position:absolute;z-index:-1;opacity:0}.custom-control-input:checked~.custom-control-indicator{color:#fff;background-color:#007bff}.custom-control-input:focus~.custom-control-indicator{box-shadow:0 0 0 1px #fff,0 0 0 3px #007bff}.custom-control-input:active~.custom-control-indicator{color:#fff;background-color:#b3d7ff}.custom-control-input:disabled~.custom-control-indicator{background-color:#e9ecef}.custom-control-input:disabled~.custom-control-description{color:#868e96}.custom-control-indicator{position:absolute;top:.25rem;left:0;display:block;width:1rem;height:1rem;pointer-events:none;-webkit-user-select:none;-moz-user-select:none;-ms-user-select:none;user-select:none;background-color:#ddd;background-repeat:no-repeat;background-position:center center;background-size:50% 50%}.custom-checkbox .custom-control-indicator{border-radius:.25rem}.custom-checkbox .custom-control-input:checked~.custom-control-indicator{background-image:url("data:image/svg+xml;charset=utf8,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 8 8'%3E%3Cpath fill='%23fff' d='M6.564.75l-3.59 3.612-1.538-1.55L0 4.26 2.974 7.25 8 2.193z'/%3E%3C/svg%3E")}.custom-checkbox .custom-control-input:indeterminate~.custom-control-indicator{background-color:#007bff;background-image:url("data:image/svg+xml;charset=utf8,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 4 4'%3E%3Cpath stroke='%23fff' d='M0 2h4'/%3E%3C/svg%3E")}.custom-radio .custom-control-indicator{border-radius:50%}.custom-radio .custom-control-input:checked~.custom-control-indicator{background-image:url("data:image/svg+xml;charset=utf8,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='-4 -4 8 8'%3E%3Ccircle r='3' fill='%23fff'/%3E%3C/svg%3E")}.custom-controls-stacked{display:-ms-flexbox;display:flex;-ms-flex-direction:column;flex-direction:column}.custom-controls-stacked .custom-control{margin-bottom:.25rem}.custom-controls-stacked .custom-control+.custom-control{margin-left:0}.custom-select{display:inline-block;max-width:100%;height:calc(2.25rem + 2px);padding:.375rem 1.75rem .375rem .75rem;line-height:1.25;color:#495057;vertical-align:middle;background:#fff url("data:image/svg+xml;charset=utf8,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 4 5'%3E%3Cpath fill='%23333' d='M2 0L0 2h4zm0 5L0 3h4z'/%3E%3C/svg%3E") no-repeat right .75rem center;background-size:8px 10px;border:1px solid rgba(0,0,0,.15);border-radius:.25rem;-webkit-appearance:none;-moz-appearance:none;appearance:none}.custom-select:focus{border-color:#80bdff;outline:0}.custom-select:focus::-ms-value{color:#495057;background-color:#fff}.custom-select:disabled{color:#868e96;background-color:#e9ecef}.custom-select::-ms-expand{opacity:0}.custom-select-sm{height:calc(1.8125rem + 2px);padding-top:.375rem;padding-bottom:.375rem;font-size:75%}.custom-file{position:relative;display:inline-block;max-width:100%;height:2.5rem;margin-bottom:0}.custom-file-input{min-width:14rem;max-width:100%;height:2.5rem;margin:0;opacity:0}.custom-file-control{position:absolute;top:0;right:0;left:0;z-index:5;height:2.5rem;padding:.5rem 1rem;line-height:1.5;color:#495057;pointer-events:none;-webkit-user-select:none;-moz-user-select:none;-ms-user-select:none;user-select:none;background-color:#fff;border:1px solid rgba(0,0,0,.15);border-radius:.25rem}.custom-file-control:lang(en):empty::after{content:"Choose file..."}.custom-file-control::before{position:absolute;top:-1px;right:-1px;bottom:-1px;z-index:6;display:block;height:2.5rem;padding:.5rem 1rem;line-height:1.5;color:#495057;background-color:#e9ecef;border:1px solid rgba(0,0,0,.15);border-radius:0 .25rem .25rem 0}.custom-file-control:lang(en)::before{content:"Browse"}.nav{display:-ms-flexbox;display:flex;-ms-flex-wrap:wrap;flex-wrap:wrap;padding-left:0;margin-bottom:0;list-style:none}.nav-link{display:block;padding:.5rem 1rem}.nav-link:focus,.nav-link:hover{text-decoration:none}.nav-link.disabled{color:#868e96}.nav-tabs{border-bottom:1px solid #ddd}.nav-tabs .nav-item{margin-bottom:-1px}.nav-tabs .nav-link{border:1px solid transparent;border-top-left-radius:.25rem;border-top-right-radius:.25rem}.nav-tabs .nav-link:focus,.nav-tabs .nav-link:hover{border-color:#e9ecef #e9ecef #ddd}.nav-tabs .nav-link.disabled{color:#868e96;background-color:transparent;border-color:transparent}.nav-tabs .nav-item.show .nav-link,.nav-tabs .nav-link.active{color:#495057;background-color:#fff;border-color:#ddd #ddd #fff}.nav-tabs .dropdown-menu{margin-top:-1px;border-top-left-radius:0;border-top-right-radius:0}.nav-pills .nav-link{border-radius:.25rem}.nav-pills .nav-link.active,.show>.nav-pills .nav-link{color:#fff;background-color:#007bff}.nav-fill .nav-item{-ms-flex:1 1 auto;flex:1 1 auto;text-align:center}.nav-justified .nav-item{-ms-flex-preferred-size:0;flex-basis:0;-ms-flex-positive:1;flex-grow:1;text-align:center}.tab-content>.tab-pane{display:none}.tab-content>.active{display:block}.navbar{position:relative;display:-ms-flexbox;display:flex;-ms-flex-wrap:wrap;flex-wrap:wrap;-ms-flex-align:center;align-items:center;-ms-flex-pack:justify;justify-content:space-between;padding:.5rem 1rem}.navbar>.container,.navbar>.container-fluid{display:-ms-flexbox;display:flex;-ms-flex-wrap:wrap;flex-wrap:wrap;-ms-flex-align:center;align-items:center;-ms-flex-pack:justify;justify-content:space-between}.navbar-brand{display:inline-block;padding-top:.3125rem;padding-bottom:.3125rem;margin-right:1rem;font-size:1.25rem;line-height:inherit;white-space:nowrap}.navbar-brand:focus,.navbar-brand:hover{text-decoration:none}.navbar-nav{display:-ms-flexbox;display:flex;-ms-flex-direction:column;flex-direction:column;padding-left:0;margin-bottom:0;list-style:none}.navbar-nav .nav-link{padding-right:0;padding-left:0}.navbar-nav .dropdown-menu{position:static;float:none}.navbar-text{display:inline-block;padding-top:.5rem;padding-bottom:.5rem}.navbar-collapse{-ms-flex-preferred-size:100%;flex-basis:100%;-ms-flex-align:center;align-items:center}.navbar-toggler{padding:.25rem .75rem;font-size:1.25rem;line-height:1;background:0 0;border:1px solid transparent;border-radius:.25rem}.navbar-toggler:focus,.navbar-toggler:hover{text-decoration:none}.navbar-toggler-icon{display:inline-block;width:1.5em;height:1.5em;vertical-align:middle;content:"";background:no-repeat center center;background-size:100% 100%}@media (max-width:575px){.navbar-expand-sm>.container,.navbar-expand-sm>.container-fluid{padding-right:0;padding-left:0}}@media (min-width:576px){.navbar-expand-sm{-ms-flex-direction:row;flex-direction:row;-ms-flex-wrap:nowrap;flex-wrap:nowrap;-ms-flex-pack:start;justify-content:flex-start}.navbar-expand-sm .navbar-nav{-ms-flex-direction:row;flex-direction:row}.navbar-expand-sm .navbar-nav .dropdown-menu{position:absolute}.navbar-expand-sm .navbar-nav .dropdown-menu-right{right:0;left:auto}.navbar-expand-sm .navbar-nav .nav-link{padding-right:.5rem;padding-left:.5rem}.navbar-expand-sm>.container,.navbar-expand-sm>.container-fluid{-ms-flex-wrap:nowrap;flex-wrap:nowrap}.navbar-expand-sm .navbar-collapse{display:-ms-flexbox!important;display:flex!important}.navbar-expand-sm .navbar-toggler{display:none}}@media (max-width:767px){.navbar-expand-md>.container,.navbar-expand-md>.container-fluid{padding-right:0;padding-left:0}}@media (min-width:768px){.navbar-expand-md{-ms-flex-direction:row;flex-direction:row;-ms-flex-wrap:nowrap;flex-wrap:nowrap;-ms-flex-pack:start;justify-content:flex-start}.navbar-expand-md .navbar-nav{-ms-flex-direction:row;flex-direction:row}.navbar-expand-md .navbar-nav .dropdown-menu{position:absolute}.navbar-expand-md .navbar-nav .dropdown-menu-right{right:0;left:auto}.navbar-expand-md .navbar-nav .nav-link{padding-right:.5rem;padding-left:.5rem}.navbar-expand-md>.container,.navbar-expand-md>.container-fluid{-ms-flex-wrap:nowrap;flex-wrap:nowrap}.navbar-expand-md .navbar-collapse{display:-ms-flexbox!important;display:flex!important}.navbar-expand-md .navbar-toggler{display:none}}@media (max-width:991px){.navbar-expand-lg>.container,.navbar-expand-lg>.container-fluid{padding-right:0;padding-left:0}}@media (min-width:992px){.navbar-expand-lg{-ms-flex-direction:row;flex-direction:row;-ms-flex-wrap:nowrap;flex-wrap:nowrap;-ms-flex-pack:start;justify-content:flex-start}.navbar-expand-lg .navbar-nav{-ms-flex-direction:row;flex-direction:row}.navbar-expand-lg .navbar-nav .dropdown-menu{position:absolute}.navbar-expand-lg .navbar-nav .dropdown-menu-right{right:0;left:auto}.navbar-expand-lg .navbar-nav .nav-link{padding-right:.5rem;padding-left:.5rem}.navbar-expand-lg>.container,.navbar-expand-lg>.container-fluid{-ms-flex-wrap:nowrap;flex-wrap:nowrap}.navbar-expand-lg .navbar-collapse{display:-ms-flexbox!important;display:flex!important}.navbar-expand-lg .navbar-toggler{display:none}}@media (max-width:1199px){.navbar-expand-xl>.container,.navbar-expand-xl>.container-fluid{padding-right:0;padding-left:0}}@media (min-width:1200px){.navbar-expand-xl{-ms-flex-direction:row;flex-direction:row;-ms-flex-wrap:nowrap;flex-wrap:nowrap;-ms-flex-pack:start;justify-content:flex-start}.navbar-expand-xl .navbar-nav{-ms-flex-direction:row;flex-direction:row}.navbar-expand-xl .navbar-nav .dropdown-menu{position:absolute}.navbar-expand-xl .navbar-nav .dropdown-menu-right{right:0;left:auto}.navbar-expand-xl .navbar-nav .nav-link{padding-right:.5rem;padding-left:.5rem}.navbar-expand-xl>.container,.navbar-expand-xl>.container-fluid{-ms-flex-wrap:nowrap;flex-wrap:nowrap}.navbar-expand-xl .navbar-collapse{display:-ms-flexbox!important;display:flex!important}.navbar-expand-xl .navbar-toggler{display:none}}.navbar-expand{-ms-flex-direction:row;flex-direction:row;-ms-flex-wrap:nowrap;flex-wrap:nowrap;-ms-flex-pack:start;justify-content:flex-start}.navbar-expand>.container,.navbar-expand>.container-fluid{padding-right:0;padding-left:0}.navbar-expand .navbar-nav{-ms-flex-direction:row;flex-direction:row}.navbar-expand .navbar-nav .dropdown-menu{position:absolute}.navbar-expand .navbar-nav .dropdown-menu-right{right:0;left:auto}.navbar-expand .navbar-nav .nav-link{padding-right:.5rem;padding-left:.5rem}.navbar-expand>.container,.navbar-expand>.container-fluid{-ms-flex-wrap:nowrap;flex-wrap:nowrap}.navbar-expand .navbar-collapse{display:-ms-flexbox!important;display:flex!important}.navbar-expand .navbar-toggler{display:none}.navbar-light .navbar-brand{color:rgba(0,0,0,.9)}.navbar-light .navbar-brand:focus,.navbar-light .navbar-brand:hover{color:rgba(0,0,0,.9)}.navbar-light .navbar-nav .nav-link{color:rgba(0,0,0,.5)}.navbar-light .navbar-nav .nav-link:focus,.navbar-light .navbar-nav .nav-link:hover{color:rgba(0,0,0,.7)}.navbar-light .navbar-nav .nav-link.disabled{color:rgba(0,0,0,.3)}.navbar-light .navbar-nav .active>.nav-link,.navbar-light .navbar-nav .nav-link.active,.navbar-light .navbar-nav .nav-link.show,.navbar-light .navbar-nav .show>.nav-link{color:rgba(0,0,0,.9)}.navbar-light .navbar-toggler{color:rgba(0,0,0,.5);border-color:rgba(0,0,0,.1)}.navbar-light .navbar-toggler-icon{background-image:url("data:image/svg+xml;charset=utf8,%3Csvg viewBox='0 0 30 30' xmlns='http://www.w3.org/2000/svg'%3E%3Cpath stroke='rgba(0, 0, 0, 0.5)' stroke-width='2' stroke-linecap='round' stroke-miterlimit='10' d='M4 7h22M4 15h22M4 23h22'/%3E%3C/svg%3E")}.navbar-light .navbar-text{color:rgba(0,0,0,.5)}.navbar-dark .navbar-brand{color:#fff}.navbar-dark .navbar-brand:focus,.navbar-dark .navbar-brand:hover{color:#fff}.navbar-dark .navbar-nav .nav-link{color:rgba(255,255,255,.5)}.navbar-dark .navbar-nav .nav-link:focus,.navbar-dark .navbar-nav .nav-link:hover{color:rgba(255,255,255,.75)}.navbar-dark .navbar-nav .nav-link.disabled{color:rgba(255,255,255,.25)}.navbar-dark .navbar-nav .active>.nav-link,.navbar-dark .navbar-nav .nav-link.active,.navbar-dark .navbar-nav .nav-link.show,.navbar-dark .navbar-nav .show>.nav-link{color:#fff}.navbar-dark .navbar-toggler{color:rgba(255,255,255,.5);border-color:rgba(255,255,255,.1)}.navbar-dark .navbar-toggler-icon{background-image:url("data:image/svg+xml;charset=utf8,%3Csvg viewBox='0 0 30 30' xmlns='http://www.w3.org/2000/svg'%3E%3Cpath stroke='rgba(255, 255, 255, 0.5)' stroke-width='2' stroke-linecap='round' stroke-miterlimit='10' d='M4 7h22M4 15h22M4 23h22'/%3E%3C/svg%3E")}.navbar-dark .navbar-text{color:rgba(255,255,255,.5)}.card{position:relative;display:-ms-flexbox;display:flex;-ms-flex-direction:column;flex-direction:column;min-width:0;word-wrap:break-word;background-color:#fff;background-clip:border-box;border:1px solid rgba(0,0,0,.125);border-radius:.25rem}.card-body{-ms-flex:1 1 auto;flex:1 1 auto;padding:1.25rem}.card-title{margin-bottom:.75rem}.card-subtitle{margin-top:-.375rem;margin-bottom:0}.card-text:last-child{margin-bottom:0}.card-link:hover{text-decoration:none}.card-link+.card-link{margin-left:1.25rem}.card>.list-group:first-child .list-group-item:first-child{border-top-left-radius:.25rem;border-top-right-radius:.25rem}.card>.list-group:last-child .list-group-item:last-child{border-bottom-right-radius:.25rem;border-bottom-left-radius:.25rem}.card-header{padding:.75rem 1.25rem;margin-bottom:0;background-color:rgba(0,0,0,.03);border-bottom:1px solid rgba(0,0,0,.125)}.card-header:first-child{border-radius:calc(.25rem - 1px) calc(.25rem - 1px) 0 0}.card-footer{padding:.75rem 1.25rem;background-color:rgba(0,0,0,.03);border-top:1px solid rgba(0,0,0,.125)}.card-footer:last-child{border-radius:0 0 calc(.25rem - 1px) calc(.25rem - 1px)}.card-header-tabs{margin-right:-.625rem;margin-bottom:-.75rem;margin-left:-.625rem;border-bottom:0}.card-header-pills{margin-right:-.625rem;margin-left:-.625rem}.card-img-overlay{position:absolute;top:0;right:0;bottom:0;left:0;padding:1.25rem}.card-img{width:100%;border-radius:calc(.25rem - 1px)}.card-img-top{width:100%;border-top-left-radius:calc(.25rem - 1px);border-top-right-radius:calc(.25rem - 1px)}.card-img-bottom{width:100%;border-bottom-right-radius:calc(.25rem - 1px);border-bottom-left-radius:calc(.25rem - 1px)}@media (min-width:576px){.card-deck{display:-ms-flexbox;display:flex;-ms-flex-flow:row wrap;flex-flow:row wrap;margin-right:-15px;margin-left:-15px}.card-deck .card{display:-ms-flexbox;display:flex;-ms-flex:1 0 0%;flex:1 0 0%;-ms-flex-direction:column;flex-direction:column;margin-right:15px;margin-left:15px}}@media (min-width:576px){.card-group{display:-ms-flexbox;display:flex;-ms-flex-flow:row wrap;flex-flow:row wrap}.card-group .card{-ms-flex:1 0 0%;flex:1 0 0%}.card-group .card+.card{margin-left:0;border-left:0}.card-group .card:first-child{border-top-right-radius:0;border-bottom-right-radius:0}.card-group .card:first-child .card-img-top{border-top-right-radius:0}.card-group .card:first-child .card-img-bottom{border-bottom-right-radius:0}.card-group .card:last-child{border-top-left-radius:0;border-bottom-left-radius:0}.card-group .card:last-child .card-img-top{border-top-left-radius:0}.card-group .card:last-child .card-img-bottom{border-bottom-left-radius:0}.card-group .card:not(:first-child):not(:last-child){border-radius:0}.card-group .card:not(:first-child):not(:last-child) .card-img-bottom,.card-group .card:not(:first-child):not(:last-child) .card-img-top{border-radius:0}}.card-columns .card{margin-bottom:.75rem}@media (min-width:576px){.card-columns{-webkit-column-count:3;column-count:3;-webkit-column-gap:1.25rem;column-gap:1.25rem}.card-columns .card{display:inline-block;width:100%}}.breadcrumb{padding:.75rem 1rem;margin-bottom:1rem;list-style:none;background-color:#e9ecef;border-radius:.25rem}.breadcrumb::after{display:block;clear:both;content:""}.breadcrumb-item{float:left}.breadcrumb-item+.breadcrumb-item::before{display:inline-block;padding-right:.5rem;padding-left:.5rem;color:#868e96;content:"/"}.breadcrumb-item+.breadcrumb-item:hover::before{text-decoration:underline}.breadcrumb-item+.breadcrumb-item:hover::before{text-decoration:none}.breadcrumb-item.active{color:#868e96}.pagination{display:-ms-flexbox;display:flex;padding-left:0;list-style:none;border-radius:.25rem}.page-item:first-child .page-link{margin-left:0;border-top-left-radius:.25rem;border-bottom-left-radius:.25rem}.page-item:last-child .page-link{border-top-right-radius:.25rem;border-bottom-right-radius:.25rem}.page-item.active .page-link{z-index:2;color:#fff;background-color:#007bff;border-color:#007bff}.page-item.disabled .page-link{color:#868e96;pointer-events:none;background-color:#fff;border-color:#ddd}.page-link{position:relative;display:block;padding:.5rem .75rem;margin-left:-1px;line-height:1.25;color:#007bff;background-color:#fff;border:1px solid #ddd}.page-link:focus,.page-link:hover{color:#0056b3;text-decoration:none;background-color:#e9ecef;border-color:#ddd}.pagination-lg .page-link{padding:.75rem 1.5rem;font-size:1.25rem;line-height:1.5}.pagination-lg .page-item:first-child .page-link{border-top-left-radius:.3rem;border-bottom-left-radius:.3rem}.pagination-lg .page-item:last-child .page-link{border-top-right-radius:.3rem;border-bottom-right-radius:.3rem}.pagination-sm .page-link{padding:.25rem .5rem;font-size:.875rem;line-height:1.5}.pagination-sm .page-item:first-child .page-link{border-top-left-radius:.2rem;border-bottom-left-radius:.2rem}.pagination-sm .page-item:last-child .page-link{border-top-right-radius:.2rem;border-bottom-right-radius:.2rem}.badge{display:inline-block;padding:.25em .4em;font-size:75%;font-weight:700;line-height:1;color:#fff;text-align:center;white-space:nowrap;vertical-align:baseline;border-radius:.25rem}.badge:empty{display:none}.btn .badge{position:relative;top:-1px}.badge-pill{padding-right:.6em;padding-left:.6em;border-radius:10rem}.badge-primary{color:#fff;background-color:#007bff}.badge-primary[href]:focus,.badge-primary[href]:hover{color:#fff;text-decoration:none;background-color:#0062cc}.badge-secondary{color:#fff;background-color:#868e96}.badge-secondary[href]:focus,.badge-secondary[href]:hover{color:#fff;text-decoration:none;background-color:#6c757d}.badge-success{color:#fff;background-color:#28a745}.badge-success[href]:focus,.badge-success[href]:hover{color:#fff;text-decoration:none;background-color:#1e7e34}.badge-info{color:#fff;background-color:#17a2b8}.badge-info[href]:focus,.badge-info[href]:hover{color:#fff;text-decoration:none;background-color:#117a8b}.badge-warning{color:#111;background-color:#ffc107}.badge-warning[href]:focus,.badge-warning[href]:hover{color:#111;text-decoration:none;background-color:#d39e00}.badge-danger{color:#fff;background-color:#dc3545}.badge-danger[href]:focus,.badge-danger[href]:hover{color:#fff;text-decoration:none;background-color:#bd2130}.badge-light{color:#111;background-color:#f8f9fa}.badge-light[href]:focus,.badge-light[href]:hover{color:#111;text-decoration:none;background-color:#dae0e5}.badge-dark{color:#fff;background-color:#343a40}.badge-dark[href]:focus,.badge-dark[href]:hover{color:#fff;text-decoration:none;background-color:#1d2124}.jumbotron{padding:2rem 1rem;margin-bottom:2rem;background-color:#e9ecef;border-radius:.3rem}@media (min-width:576px){.jumbotron{padding:4rem 2rem}}.jumbotron-fluid{padding-right:0;padding-left:0;border-radius:0}.alert{padding:.75rem 1.25rem;margin-bottom:1rem;border:1px solid transparent;border-radius:.25rem}.alert-heading{color:inherit}.alert-link{font-weight:700}.alert-dismissible .close{position:relative;top:-.75rem;right:-1.25rem;padding:.75rem 1.25rem;color:inherit}.alert-primary{color:#004085;background-color:#cce5ff;border-color:#b8daff}.alert-primary hr{border-top-color:#9fcdff}.alert-primary .alert-link{color:#002752}.alert-secondary{color:#464a4e;background-color:#e7e8ea;border-color:#dddfe2}.alert-secondary hr{border-top-color:#cfd2d6}.alert-secondary .alert-link{color:#2e3133}.alert-success{color:#155724;background-color:#d4edda;border-color:#c3e6cb}.alert-success hr{border-top-color:#b1dfbb}.alert-success .alert-link{color:#0b2e13}.alert-info{color:#0c5460;background-color:#d1ecf1;border-color:#bee5eb}.alert-info hr{border-top-color:#abdde5}.alert-info .alert-link{color:#062c33}.alert-warning{color:#856404;background-color:#fff3cd;border-color:#ffeeba}.alert-warning hr{border-top-color:#ffe8a1}.alert-warning .alert-link{color:#533f03}.alert-danger{color:#721c24;background-color:#f8d7da;border-color:#f5c6cb}.alert-danger hr{border-top-color:#f1b0b7}.alert-danger .alert-link{color:#491217}.alert-light{color:#818182;background-color:#fefefe;border-color:#fdfdfe}.alert-light hr{border-top-color:#ececf6}.alert-light .alert-link{color:#686868}.alert-dark{color:#1b1e21;background-color:#d6d8d9;border-color:#c6c8ca}.alert-dark hr{border-top-color:#b9bbbe}.alert-dark .alert-link{color:#040505}@-webkit-keyframes progress-bar-stripes{from{background-position:1rem 0}to{background-position:0 0}}@keyframes progress-bar-stripes{from{background-position:1rem 0}to{background-position:0 0}}.progress{display:-ms-flexbox;display:flex;overflow:hidden;font-size:.75rem;line-height:1rem;text-align:center;background-color:#e9ecef;border-radius:.25rem}.progress-bar{height:1rem;line-height:1rem;color:#fff;background-color:#007bff;transition:width .6s ease}.progress-bar-striped{background-image:linear-gradient(45deg,rgba(255,255,255,.15) 25%,transparent 25%,transparent 50%,rgba(255,255,255,.15) 50%,rgba(255,255,255,.15) 75%,transparent 75%,transparent);background-size:1rem 1rem}.progress-bar-animated{-webkit-animation:progress-bar-stripes 1s linear infinite;animation:progress-bar-stripes 1s linear infinite}.media{display:-ms-flexbox;display:flex;-ms-flex-align:start;align-items:flex-start}.media-body{-ms-flex:1;flex:1}.list-group{display:-ms-flexbox;display:flex;-ms-flex-direction:column;flex-direction:column;padding-left:0;margin-bottom:0}.list-group-item-action{width:100%;color:#495057;text-align:inherit}.list-group-item-action:focus,.list-group-item-action:hover{color:#495057;text-decoration:none;background-color:#f8f9fa}.list-group-item-action:active{color:#212529;background-color:#e9ecef}.list-group-item{position:relative;display:block;padding:.75rem 1.25rem;margin-bottom:-1px;background-color:#fff;border:1px solid rgba(0,0,0,.125)}.list-group-item:first-child{border-top-left-radius:.25rem;border-top-right-radius:.25rem}.list-group-item:last-child{margin-bottom:0;border-bottom-right-radius:.25rem;border-bottom-left-radius:.25rem}.list-group-item:focus,.list-group-item:hover{text-decoration:none}.list-group-item.disabled,.list-group-item:disabled{color:#868e96;background-color:#fff}.list-group-item.active{z-index:2;color:#fff;background-color:#007bff;border-color:#007bff}.list-group-flush .list-group-item{border-right:0;border-left:0;border-radius:0}.list-group-flush:first-child .list-group-item:first-child{border-top:0}.list-group-flush:last-child .list-group-item:last-child{border-bottom:0}.list-group-item-primary{color:#004085;background-color:#b8daff}a.list-group-item-primary,button.list-group-item-primary{color:#004085}a.list-group-item-primary:focus,a.list-group-item-primary:hover,button.list-group-item-primary:focus,button.list-group-item-primary:hover{color:#004085;background-color:#9fcdff}a.list-group-item-primary.active,button.list-group-item-primary.active{color:#fff;background-color:#004085;border-color:#004085}.list-group-item-secondary{color:#464a4e;background-color:#dddfe2}a.list-group-item-secondary,button.list-group-item-secondary{color:#464a4e}a.list-group-item-secondary:focus,a.list-group-item-secondary:hover,button.list-group-item-secondary:focus,button.list-group-item-secondary:hover{color:#464a4e;background-color:#cfd2d6}a.list-group-item-secondary.active,button.list-group-item-secondary.active{color:#fff;background-color:#464a4e;border-color:#464a4e}.list-group-item-success{color:#155724;background-color:#c3e6cb}a.list-group-item-success,button.list-group-item-success{color:#155724}a.list-group-item-success:focus,a.list-group-item-success:hover,button.list-group-item-success:focus,button.list-group-item-success:hover{color:#155724;background-color:#b1dfbb}a.list-group-item-success.active,button.list-group-item-success.active{color:#fff;background-color:#155724;border-color:#155724}.list-group-item-info{color:#0c5460;background-color:#bee5eb}a.list-group-item-info,button.list-group-item-info{color:#0c5460}a.list-group-item-info:focus,a.list-group-item-info:hover,button.list-group-item-info:focus,button.list-group-item-info:hover{color:#0c5460;background-color:#abdde5}a.list-group-item-info.active,button.list-group-item-info.active{color:#fff;background-color:#0c5460;border-color:#0c5460}.list-group-item-warning{color:#856404;background-color:#ffeeba}a.list-group-item-warning,button.list-group-item-warning{color:#856404}a.list-group-item-warning:focus,a.list-group-item-warning:hover,button.list-group-item-warning:focus,button.list-group-item-warning:hover{color:#856404;background-color:#ffe8a1}a.list-group-item-warning.active,button.list-group-item-warning.active{color:#fff;background-color:#856404;border-color:#856404}.list-group-item-danger{color:#721c24;background-color:#f5c6cb}a.list-group-item-danger,button.list-group-item-danger{color:#721c24}a.list-group-item-danger:focus,a.list-group-item-danger:hover,button.list-group-item-danger:focus,button.list-group-item-danger:hover{color:#721c24;background-color:#f1b0b7}a.list-group-item-danger.active,button.list-group-item-danger.active{color:#fff;background-color:#721c24;border-color:#721c24}.list-group-item-light{color:#818182;background-color:#fdfdfe}a.list-group-item-light,button.list-group-item-light{color:#818182}a.list-group-item-light:focus,a.list-group-item-light:hover,button.list-group-item-light:focus,button.list-group-item-light:hover{color:#818182;background-color:#ececf6}a.list-group-item-light.active,button.list-group-item-light.active{color:#fff;background-color:#818182;border-color:#818182}.list-group-item-dark{color:#1b1e21;background-color:#c6c8ca}a.list-group-item-dark,button.list-group-item-dark{color:#1b1e21}a.list-group-item-dark:focus,a.list-group-item-dark:hover,button.list-group-item-dark:focus,button.list-group-item-dark:hover{color:#1b1e21;background-color:#b9bbbe}a.list-group-item-dark.active,button.list-group-item-dark.active{color:#fff;background-color:#1b1e21;border-color:#1b1e21}.close{float:right;font-size:1.5rem;font-weight:700;line-height:1;color:#000;text-shadow:0 1px 0 #fff;opacity:.5}.close:focus,.close:hover{color:#000;text-decoration:none;opacity:.75}button.close{padding:0;background:0 0;border:0;-webkit-appearance:none}.modal-open{overflow:hidden}.modal{position:fixed;top:0;right:0;bottom:0;left:0;z-index:1050;display:none;overflow:hidden;outline:0}.modal.fade .modal-dialog{transition:-webkit-transform .3s ease-out;transition:transform .3s ease-out;transition:transform .3s ease-out,-webkit-transform .3s ease-out;-webkit-transform:translate(0,-25%);transform:translate(0,-25%)}.modal.show .modal-dialog{-webkit-transform:translate(0,0);transform:translate(0,0)}.modal-open .modal{overflow-x:hidden;overflow-y:auto}.modal-dialog{position:relative;width:auto;margin:10px}.modal-content{position:relative;display:-ms-flexbox;display:flex;-ms-flex-direction:column;flex-direction:column;background-color:#fff;background-clip:padding-box;border:1px solid rgba(0,0,0,.2);border-radius:.3rem;outline:0}.modal-backdrop{position:fixed;top:0;right:0;bottom:0;left:0;z-index:1040;background-color:#000}.modal-backdrop.fade{opacity:0}.modal-backdrop.show{opacity:.5}.modal-header{display:-ms-flexbox;display:flex;-ms-flex-align:center;align-items:center;-ms-flex-pack:justify;justify-content:space-between;padding:15px;border-bottom:1px solid #e9ecef}.modal-title{margin-bottom:0;line-height:1.5}.modal-body{position:relative;-ms-flex:1 1 auto;flex:1 1 auto;padding:15px}.modal-footer{display:-ms-flexbox;display:flex;-ms-flex-align:center;align-items:center;-ms-flex-pack:end;justify-content:flex-end;padding:15px;border-top:1px solid #e9ecef}.modal-footer>:not(:first-child){margin-left:.25rem}.modal-footer>:not(:last-child){margin-right:.25rem}.modal-scrollbar-measure{position:absolute;top:-9999px;width:50px;height:50px;overflow:scroll}@media (min-width:576px){.modal-dialog{max-width:500px;margin:30px auto}.modal-sm{max-width:300px}}@media (min-width:992px){.modal-lg{max-width:800px}}.tooltip{position:absolute;z-index:1070;display:block;margin:0;font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,"Helvetica Neue",Arial,sans-serif;font-style:normal;font-weight:400;line-height:1.5;text-align:left;text-align:start;text-decoration:none;text-shadow:none;text-transform:none;letter-spacing:normal;word-break:normal;word-spacing:normal;white-space:normal;line-break:auto;font-size:.875rem;word-wrap:break-word;opacity:0}.tooltip.show{opacity:.9}.tooltip .arrow{position:absolute;display:block;width:5px;height:5px}.tooltip.bs-tooltip-auto[x-placement^=top],.tooltip.bs-tooltip-top{padding:5px 0}.tooltip.bs-tooltip-auto[x-placement^=top] .arrow,.tooltip.bs-tooltip-top .arrow{bottom:0}.tooltip.bs-tooltip-auto[x-placement^=top] .arrow::before,.tooltip.bs-tooltip-top .arrow::before{margin-left:-3px;content:"";border-width:5px 5px 0;border-top-color:#000}.tooltip.bs-tooltip-auto[x-placement^=right],.tooltip.bs-tooltip-right{padding:0 5px}.tooltip.bs-tooltip-auto[x-placement^=right] .arrow,.tooltip.bs-tooltip-right .arrow{left:0}.tooltip.bs-tooltip-auto[x-placement^=right] .arrow::before,.tooltip.bs-tooltip-right .arrow::before{margin-top:-3px;content:"";border-width:5px 5px 5px 0;border-right-color:#000}.tooltip.bs-tooltip-auto[x-placement^=bottom],.tooltip.bs-tooltip-bottom{padding:5px 0}.tooltip.bs-tooltip-auto[x-placement^=bottom] .arrow,.tooltip.bs-tooltip-bottom .arrow{top:0}.tooltip.bs-tooltip-auto[x-placement^=bottom] .arrow::before,.tooltip.bs-tooltip-bottom .arrow::before{margin-left:-3px;content:"";border-width:0 5px 5px;border-bottom-color:#000}.tooltip.bs-tooltip-auto[x-placement^=left],.tooltip.bs-tooltip-left{padding:0 5px}.tooltip.bs-tooltip-auto[x-placement^=left] .arrow,.tooltip.bs-tooltip-left .arrow{right:0}.tooltip.bs-tooltip-auto[x-placement^=left] .arrow::before,.tooltip.bs-tooltip-left .arrow::before{right:0;margin-top:-3px;content:"";border-width:5px 0 5px 5px;border-left-color:#000}.tooltip .arrow::before{position:absolute;border-color:transparent;border-style:solid}.tooltip-inner{max-width:200px;padding:3px 8px;color:#fff;text-align:center;background-color:#000;border-radius:.25rem}.popover{position:absolute;top:0;left:0;z-index:1060;display:block;max-width:276px;padding:1px;font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,"Helvetica Neue",Arial,sans-serif;font-style:normal;font-weight:400;line-height:1.5;text-align:left;text-align:start;text-decoration:none;text-shadow:none;text-transform:none;letter-spacing:normal;word-break:normal;word-spacing:normal;white-space:normal;line-break:auto;font-size:.875rem;word-wrap:break-word;background-color:#fff;background-clip:padding-box;border:1px solid rgba(0,0,0,.2);border-radius:.3rem}.popover .arrow{position:absolute;display:block;width:10px;height:5px}.popover .arrow::after,.popover .arrow::before{position:absolute;display:block;border-color:transparent;border-style:solid}.popover .arrow::before{content:"";border-width:11px}.popover .arrow::after{content:"";border-width:11px}.popover.bs-popover-auto[x-placement^=top],.popover.bs-popover-top{margin-bottom:10px}.popover.bs-popover-auto[x-placement^=top] .arrow,.popover.bs-popover-top .arrow{bottom:0}.popover.bs-popover-auto[x-placement^=top] .arrow::after,.popover.bs-popover-auto[x-placement^=top] .arrow::before,.popover.bs-popover-top .arrow::after,.popover.bs-popover-top .arrow::before{border-bottom-width:0}.popover.bs-popover-auto[x-placement^=top] .arrow::before,.popover.bs-popover-top .arrow::before{bottom:-11px;margin-left:-6px;border-top-color:rgba(0,0,0,.25)}.popover.bs-popover-auto[x-placement^=top] .arrow::after,.popover.bs-popover-top .arrow::after{bottom:-10px;margin-left:-6px;border-top-color:#fff}.popover.bs-popover-auto[x-placement^=right],.popover.bs-popover-right{margin-left:10px}.popover.bs-popover-auto[x-placement^=right] .arrow,.popover.bs-popover-right .arrow{left:0}.popover.bs-popover-auto[x-placement^=right] .arrow::after,.popover.bs-popover-auto[x-placement^=right] .arrow::before,.popover.bs-popover-right .arrow::after,.popover.bs-popover-right .arrow::before{margin-top:-8px;border-left-width:0}.popover.bs-popover-auto[x-placement^=right] .arrow::before,.popover.bs-popover-right .arrow::before{left:-11px;border-right-color:rgba(0,0,0,.25)}.popover.bs-popover-auto[x-placement^=right] .arrow::after,.popover.bs-popover-right .arrow::after{left:-10px;border-right-color:#fff}.popover.bs-popover-auto[x-placement^=bottom],.popover.bs-popover-bottom{margin-top:10px}.popover.bs-popover-auto[x-placement^=bottom] .arrow,.popover.bs-popover-bottom .arrow{top:0}.popover.bs-popover-auto[x-placement^=bottom] .arrow::after,.popover.bs-popover-auto[x-placement^=bottom] .arrow::before,.popover.bs-popover-bottom .arrow::after,.popover.bs-popover-bottom .arrow::before{margin-left:-7px;border-top-width:0}.popover.bs-popover-auto[x-placement^=bottom] .arrow::before,.popover.bs-popover-bottom .arrow::before{top:-11px;border-bottom-color:rgba(0,0,0,.25)}.popover.bs-popover-auto[x-placement^=bottom] .arrow::after,.popover.bs-popover-bottom .arrow::after{top:-10px;border-bottom-color:#fff}.popover.bs-popover-auto[x-placement^=bottom] .popover-header::before,.popover.bs-popover-bottom .popover-header::before{position:absolute;top:0;left:50%;display:block;width:20px;margin-left:-10px;content:"";border-bottom:1px solid #f7f7f7}.popover.bs-popover-auto[x-placement^=left],.popover.bs-popover-left{margin-right:10px}.popover.bs-popover-auto[x-placement^=left] .arrow,.popover.bs-popover-left .arrow{right:0}.popover.bs-popover-auto[x-placement^=left] .arrow::after,.popover.bs-popover-auto[x-placement^=left] .arrow::before,.popover.bs-popover-left .arrow::after,.popover.bs-popover-left .arrow::before{margin-top:-8px;border-right-width:0}.popover.bs-popover-auto[x-placement^=left] .arrow::before,.popover.bs-popover-left .arrow::before{right:-11px;border-left-color:rgba(0,0,0,.25)}.popover.bs-popover-auto[x-placement^=left] .arrow::after,.popover.bs-popover-left .arrow::after{right:-10px;border-left-color:#fff}.popover-header{padding:8px 14px;margin-bottom:0;font-size:1rem;color:inherit;background-color:#f7f7f7;border-bottom:1px solid #ebebeb;border-top-left-radius:calc(.3rem - 1px);border-top-right-radius:calc(.3rem - 1px)}.popover-header:empty{display:none}.popover-body{padding:9px 14px;color:#212529}.carousel{position:relative}.carousel-inner{position:relative;width:100%;overflow:hidden}.carousel-item{position:relative;display:none;-ms-flex-align:center;align-items:center;width:100%;transition:-webkit-transform .6s ease;transition:transform .6s ease;transition:transform .6s ease,-webkit-transform .6s ease;-webkit-backface-visibility:hidden;backface-visibility:hidden;-webkit-perspective:1000px;perspective:1000px}.carousel-item-next,.carousel-item-prev,.carousel-item.active{display:block}.carousel-item-next,.carousel-item-prev{position:absolute;top:0}.carousel-item-next.carousel-item-left,.carousel-item-prev.carousel-item-right{-webkit-transform:translateX(0);transform:translateX(0)}@supports ((-webkit-transform-style:preserve-3d) or (transform-style:preserve-3d)){.carousel-item-next.carousel-item-left,.carousel-item-prev.carousel-item-right{-webkit-transform:translate3d(0,0,0);transform:translate3d(0,0,0)}}.active.carousel-item-right,.carousel-item-next{-webkit-transform:translateX(100%);transform:translateX(100%)}@supports ((-webkit-transform-style:preserve-3d) or (transform-style:preserve-3d)){.active.carousel-item-right,.carousel-item-next{-webkit-transform:translate3d(100%,0,0);transform:translate3d(100%,0,0)}}.active.carousel-item-left,.carousel-item-prev{-webkit-transform:translateX(-100%);transform:translateX(-100%)}@supports ((-webkit-transform-style:preserve-3d) or (transform-style:preserve-3d)){.active.carousel-item-left,.carousel-item-prev{-webkit-transform:translate3d(-100%,0,0);transform:translate3d(-100%,0,0)}}.carousel-control-next,.carousel-control-prev{position:absolute;top:0;bottom:0;display:-ms-flexbox;display:flex;-ms-flex-align:center;align-items:center;-ms-flex-pack:center;justify-content:center;width:15%;color:#fff;text-align:center;opacity:.5}.carousel-control-next:focus,.carousel-control-next:hover,.carousel-control-prev:focus,.carousel-control-prev:hover{color:#fff;text-decoration:none;outline:0;opacity:.9}.carousel-control-prev{left:0}.carousel-control-next{right:0}.carousel-control-next-icon,.carousel-control-prev-icon{display:inline-block;width:20px;height:20px;background:transparent no-repeat center center;background-size:100% 100%}.carousel-control-prev-icon{background-image:url("data:image/svg+xml;charset=utf8,%3Csvg xmlns='http://www.w3.org/2000/svg' fill='%23fff' viewBox='0 0 8 8'%3E%3Cpath d='M4 0l-4 4 4 4 1.5-1.5-2.5-2.5 2.5-2.5-1.5-1.5z'/%3E%3C/svg%3E")}.carousel-control-next-icon{background-image:url("data:image/svg+xml;charset=utf8,%3Csvg xmlns='http://www.w3.org/2000/svg' fill='%23fff' viewBox='0 0 8 8'%3E%3Cpath d='M1.5 0l-1.5 1.5 2.5 2.5-2.5 2.5 1.5 1.5 4-4-4-4z'/%3E%3C/svg%3E")}.carousel-indicators{position:absolute;right:0;bottom:10px;left:0;z-index:15;display:-ms-flexbox;display:flex;-ms-flex-pack:center;justify-content:center;padding-left:0;margin-right:15%;margin-left:15%;list-style:none}.carousel-indicators li{position:relative;-ms-flex:0 1 auto;flex:0 1 auto;width:30px;height:3px;margin-right:3px;margin-left:3px;text-indent:-999px;background-color:rgba(255,255,255,.5)}.carousel-indicators li::before{position:absolute;top:-10px;left:0;display:inline-block;width:100%;height:10px;content:""}.carousel-indicators li::after{position:absolute;bottom:-10px;left:0;display:inline-block;width:100%;height:10px;content:""}.carousel-indicators .active{background-color:#fff}.carousel-caption{position:absolute;right:15%;bottom:20px;left:15%;z-index:10;padding-top:20px;padding-bottom:20px;color:#fff;text-align:center}.align-baseline{vertical-align:baseline!important}.align-top{vertical-align:top!important}.align-middle{vertical-align:middle!important}.align-bottom{vertical-align:bottom!important}.align-text-bottom{vertical-align:text-bottom!important}.align-text-top{vertical-align:text-top!important}.bg-primary{background-color:#007bff!important}a.bg-primary:focus,a.bg-primary:hover{background-color:#0062cc!important}.bg-secondary{background-color:#868e96!important}a.bg-secondary:focus,a.bg-secondary:hover{background-color:#6c757d!important}.bg-success{background-color:#28a745!important}a.bg-success:focus,a.bg-success:hover{background-color:#1e7e34!important}.bg-info{background-color:#17a2b8!important}a.bg-info:focus,a.bg-info:hover{background-color:#117a8b!important}.bg-warning{background-color:#ffc107!important}a.bg-warning:focus,a.bg-warning:hover{background-color:#d39e00!important}.bg-danger{background-color:#dc3545!important}a.bg-danger:focus,a.bg-danger:hover{background-color:#bd2130!important}.bg-light{background-color:#f8f9fa!important}a.bg-light:focus,a.bg-light:hover{background-color:#dae0e5!important}.bg-dark{background-color:#343a40!important}a.bg-dark:focus,a.bg-dark:hover{background-color:#1d2124!important}.bg-white{background-color:#fff!important}.bg-transparent{background-color:transparent!important}.border{border:1px solid #e9ecef!important}.border-0{border:0!important}.border-top-0{border-top:0!important}.border-right-0{border-right:0!important}.border-bottom-0{border-bottom:0!important}.border-left-0{border-left:0!important}.border-primary{border-color:#007bff!important}.border-secondary{border-color:#868e96!important}.border-success{border-color:#28a745!important}.border-info{border-color:#17a2b8!important}.border-warning{border-color:#ffc107!important}.border-danger{border-color:#dc3545!important}.border-light{border-color:#f8f9fa!important}.border-dark{border-color:#343a40!important}.border-white{border-color:#fff!important}.rounded{border-radius:.25rem!important}.rounded-top{border-top-left-radius:.25rem!important;border-top-right-radius:.25rem!important}.rounded-right{border-top-right-radius:.25rem!important;border-bottom-right-radius:.25rem!important}.rounded-bottom{border-bottom-right-radius:.25rem!important;border-bottom-left-radius:.25rem!important}.rounded-left{border-top-left-radius:.25rem!important;border-bottom-left-radius:.25rem!important}.rounded-circle{border-radius:50%}.rounded-0{border-radius:0}.clearfix::after{display:block;clear:both;content:""}.d-none{display:none!important}.d-inline{display:inline!important}.d-inline-block{display:inline-block!important}.d-block{display:block!important}.d-table{display:table!important}.d-table-cell{display:table-cell!important}.d-flex{display:-ms-flexbox!important;display:flex!important}.d-inline-flex{display:-ms-inline-flexbox!important;display:inline-flex!important}@media (min-width:576px){.d-sm-none{display:none!important}.d-sm-inline{display:inline!important}.d-sm-inline-block{display:inline-block!important}.d-sm-block{display:block!important}.d-sm-table{display:table!important}.d-sm-table-cell{display:table-cell!important}.d-sm-flex{display:-ms-flexbox!important;display:flex!important}.d-sm-inline-flex{display:-ms-inline-flexbox!important;display:inline-flex!important}}@media (min-width:768px){.d-md-none{display:none!important}.d-md-inline{display:inline!important}.d-md-inline-block{display:inline-block!important}.d-md-block{display:block!important}.d-md-table{display:table!important}.d-md-table-cell{display:table-cell!important}.d-md-flex{display:-ms-flexbox!important;display:flex!important}.d-md-inline-flex{display:-ms-inline-flexbox!important;display:inline-flex!important}}@media (min-width:992px){.d-lg-none{display:none!important}.d-lg-inline{display:inline!important}.d-lg-inline-block{display:inline-block!important}.d-lg-block{display:block!important}.d-lg-table{display:table!important}.d-lg-table-cell{display:table-cell!important}.d-lg-flex{display:-ms-flexbox!important;display:flex!important}.d-lg-inline-flex{display:-ms-inline-flexbox!important;display:inline-flex!important}}@media (min-width:1200px){.d-xl-none{display:none!important}.d-xl-inline{display:inline!important}.d-xl-inline-block{display:inline-block!important}.d-xl-block{display:block!important}.d-xl-table{display:table!important}.d-xl-table-cell{display:table-cell!important}.d-xl-flex{display:-ms-flexbox!important;display:flex!important}.d-xl-inline-flex{display:-ms-inline-flexbox!important;display:inline-flex!important}}.d-print-block{display:none!important}@media print{.d-print-block{display:block!important}}.d-print-inline{display:none!important}@media print{.d-print-inline{display:inline!important}}.d-print-inline-block{display:none!important}@media print{.d-print-inline-block{display:inline-block!important}}@media print{.d-print-none{display:none!important}}.embed-responsive{position:relative;display:block;width:100%;padding:0;overflow:hidden}.embed-responsive::before{display:block;content:""}.embed-responsive .embed-responsive-item,.embed-responsive embed,.embed-responsive iframe,.embed-responsive object,.embed-responsive video{position:absolute;top:0;bottom:0;left:0;width:100%;height:100%;border:0}.embed-responsive-21by9::before{padding-top:42.857143%}.embed-responsive-16by9::before{padding-top:56.25%}.embed-responsive-4by3::before{padding-top:75%}.embed-responsive-1by1::before{padding-top:100%}.flex-row{-ms-flex-direction:row!important;flex-direction:row!important}.flex-column{-ms-flex-direction:column!important;flex-direction:column!important}.flex-row-reverse{-ms-flex-direction:row-reverse!important;flex-direction:row-reverse!important}.flex-column-reverse{-ms-flex-direction:column-reverse!important;flex-direction:column-reverse!important}.flex-wrap{-ms-flex-wrap:wrap!important;flex-wrap:wrap!important}.flex-nowrap{-ms-flex-wrap:nowrap!important;flex-wrap:nowrap!important}.flex-wrap-reverse{-ms-flex-wrap:wrap-reverse!important;flex-wrap:wrap-reverse!important}.justify-content-start{-ms-flex-pack:start!important;justify-content:flex-start!important}.justify-content-end{-ms-flex-pack:end!important;justify-content:flex-end!important}.justify-content-center{-ms-flex-pack:center!important;justify-content:center!important}.justify-content-between{-ms-flex-pack:justify!important;justify-content:space-between!important}.justify-content-around{-ms-flex-pack:distribute!important;justify-content:space-around!important}.align-items-start{-ms-flex-align:start!important;align-items:flex-start!important}.align-items-end{-ms-flex-align:end!important;align-items:flex-end!important}.align-items-center{-ms-flex-align:center!important;align-items:center!important}.align-items-baseline{-ms-flex-align:baseline!important;align-items:baseline!important}.align-items-stretch{-ms-flex-align:stretch!important;align-items:stretch!important}.align-content-start{-ms-flex-line-pack:start!important;align-content:flex-start!important}.align-content-end{-ms-flex-line-pack:end!important;align-content:flex-end!important}.align-content-center{-ms-flex-line-pack:center!important;align-content:center!important}.align-content-between{-ms-flex-line-pack:justify!important;align-content:space-between!important}.align-content-around{-ms-flex-line-pack:distribute!important;align-content:space-around!important}.align-content-stretch{-ms-flex-line-pack:stretch!important;align-content:stretch!important}.align-self-auto{-ms-flex-item-align:auto!important;align-self:auto!important}.align-self-start{-ms-flex-item-align:start!important;align-self:flex-start!important}.align-self-end{-ms-flex-item-align:end!important;align-self:flex-end!important}.align-self-center{-ms-flex-item-align:center!important;align-self:center!important}.align-self-baseline{-ms-flex-item-align:baseline!important;align-self:baseline!important}.align-self-stretch{-ms-flex-item-align:stretch!important;align-self:stretch!important}@media (min-width:576px){.flex-sm-row{-ms-flex-direction:row!important;flex-direction:row!important}.flex-sm-column{-ms-flex-direction:column!important;flex-direction:column!important}.flex-sm-row-reverse{-ms-flex-direction:row-reverse!important;flex-direction:row-reverse!important}.flex-sm-column-reverse{-ms-flex-direction:column-reverse!important;flex-direction:column-reverse!important}.flex-sm-wrap{-ms-flex-wrap:wrap!important;flex-wrap:wrap!important}.flex-sm-nowrap{-ms-flex-wrap:nowrap!important;flex-wrap:nowrap!important}.flex-sm-wrap-reverse{-ms-flex-wrap:wrap-reverse!important;flex-wrap:wrap-reverse!important}.justify-content-sm-start{-ms-flex-pack:start!important;justify-content:flex-start!important}.justify-content-sm-end{-ms-flex-pack:end!important;justify-content:flex-end!important}.justify-content-sm-center{-ms-flex-pack:center!important;justify-content:center!important}.justify-content-sm-between{-ms-flex-pack:justify!important;justify-content:space-between!important}.justify-content-sm-around{-ms-flex-pack:distribute!important;justify-content:space-around!important}.align-items-sm-start{-ms-flex-align:start!important;align-items:flex-start!important}.align-items-sm-end{-ms-flex-align:end!important;align-items:flex-end!important}.align-items-sm-center{-ms-flex-align:center!important;align-items:center!important}.align-items-sm-baseline{-ms-flex-align:baseline!important;align-items:baseline!important}.align-items-sm-stretch{-ms-flex-align:stretch!important;align-items:stretch!important}.align-content-sm-start{-ms-flex-line-pack:start!important;align-content:flex-start!important}.align-content-sm-end{-ms-flex-line-pack:end!important;align-content:flex-end!important}.align-content-sm-center{-ms-flex-line-pack:center!important;align-content:center!important}.align-content-sm-between{-ms-flex-line-pack:justify!important;align-content:space-between!important}.align-content-sm-around{-ms-flex-line-pack:distribute!important;align-content:space-around!important}.align-content-sm-stretch{-ms-flex-line-pack:stretch!important;align-content:stretch!important}.align-self-sm-auto{-ms-flex-item-align:auto!important;align-self:auto!important}.align-self-sm-start{-ms-flex-item-align:start!important;align-self:flex-start!important}.align-self-sm-end{-ms-flex-item-align:end!important;align-self:flex-end!important}.align-self-sm-center{-ms-flex-item-align:center!important;align-self:center!important}.align-self-sm-baseline{-ms-flex-item-align:baseline!important;align-self:baseline!important}.align-self-sm-stretch{-ms-flex-item-align:stretch!important;align-self:stretch!important}}@media (min-width:768px){.flex-md-row{-ms-flex-direction:row!important;flex-direction:row!important}.flex-md-column{-ms-flex-direction:column!important;flex-direction:column!important}.flex-md-row-reverse{-ms-flex-direction:row-reverse!important;flex-direction:row-reverse!important}.flex-md-column-reverse{-ms-flex-direction:column-reverse!important;flex-direction:column-reverse!important}.flex-md-wrap{-ms-flex-wrap:wrap!important;flex-wrap:wrap!important}.flex-md-nowrap{-ms-flex-wrap:nowrap!important;flex-wrap:nowrap!important}.flex-md-wrap-reverse{-ms-flex-wrap:wrap-reverse!important;flex-wrap:wrap-reverse!important}.justify-content-md-start{-ms-flex-pack:start!important;justify-content:flex-start!important}.justify-content-md-end{-ms-flex-pack:end!important;justify-content:flex-end!important}.justify-content-md-center{-ms-flex-pack:center!important;justify-content:center!important}.justify-content-md-between{-ms-flex-pack:justify!important;justify-content:space-between!important}.justify-content-md-around{-ms-flex-pack:distribute!important;justify-content:space-around!important}.align-items-md-start{-ms-flex-align:start!important;align-items:flex-start!important}.align-items-md-end{-ms-flex-align:end!important;align-items:flex-end!important}.align-items-md-center{-ms-flex-align:center!important;align-items:center!important}.align-items-md-baseline{-ms-flex-align:baseline!important;align-items:baseline!important}.align-items-md-stretch{-ms-flex-align:stretch!important;align-items:stretch!important}.align-content-md-start{-ms-flex-line-pack:start!important;align-content:flex-start!important}.align-content-md-end{-ms-flex-line-pack:end!important;align-content:flex-end!important}.align-content-md-center{-ms-flex-line-pack:center!important;align-content:center!important}.align-content-md-between{-ms-flex-line-pack:justify!important;align-content:space-between!important}.align-content-md-around{-ms-flex-line-pack:distribute!important;align-content:space-around!important}.align-content-md-stretch{-ms-flex-line-pack:stretch!important;align-content:stretch!important}.align-self-md-auto{-ms-flex-item-align:auto!important;align-self:auto!important}.align-self-md-start{-ms-flex-item-align:start!important;align-self:flex-start!important}.align-self-md-end{-ms-flex-item-align:end!important;align-self:flex-end!important}.align-self-md-center{-ms-flex-item-align:center!important;align-self:center!important}.align-self-md-baseline{-ms-flex-item-align:baseline!important;align-self:baseline!important}.align-self-md-stretch{-ms-flex-item-align:stretch!important;align-self:stretch!important}}@media (min-width:992px){.flex-lg-row{-ms-flex-direction:row!important;flex-direction:row!important}.flex-lg-column{-ms-flex-direction:column!important;flex-direction:column!important}.flex-lg-row-reverse{-ms-flex-direction:row-reverse!important;flex-direction:row-reverse!important}.flex-lg-column-reverse{-ms-flex-direction:column-reverse!important;flex-direction:column-reverse!important}.flex-lg-wrap{-ms-flex-wrap:wrap!important;flex-wrap:wrap!important}.flex-lg-nowrap{-ms-flex-wrap:nowrap!important;flex-wrap:nowrap!important}.flex-lg-wrap-reverse{-ms-flex-wrap:wrap-reverse!important;flex-wrap:wrap-reverse!important}.justify-content-lg-start{-ms-flex-pack:start!important;justify-content:flex-start!important}.justify-content-lg-end{-ms-flex-pack:end!important;justify-content:flex-end!important}.justify-content-lg-center{-ms-flex-pack:center!important;justify-content:center!important}.justify-content-lg-between{-ms-flex-pack:justify!important;justify-content:space-between!important}.justify-content-lg-around{-ms-flex-pack:distribute!important;justify-content:space-around!important}.align-items-lg-start{-ms-flex-align:start!important;align-items:flex-start!important}.align-items-lg-end{-ms-flex-align:end!important;align-items:flex-end!important}.align-items-lg-center{-ms-flex-align:center!important;align-items:center!important}.align-items-lg-baseline{-ms-flex-align:baseline!important;align-items:baseline!important}.align-items-lg-stretch{-ms-flex-align:stretch!important;align-items:stretch!important}.align-content-lg-start{-ms-flex-line-pack:start!important;align-content:flex-start!important}.align-content-lg-end{-ms-flex-line-pack:end!important;align-content:flex-end!important}.align-content-lg-center{-ms-flex-line-pack:center!important;align-content:center!important}.align-content-lg-between{-ms-flex-line-pack:justify!important;align-content:space-between!important}.align-content-lg-around{-ms-flex-line-pack:distribute!important;align-content:space-around!important}.align-content-lg-stretch{-ms-flex-line-pack:stretch!important;align-content:stretch!important}.align-self-lg-auto{-ms-flex-item-align:auto!important;align-self:auto!important}.align-self-lg-start{-ms-flex-item-align:start!important;align-self:flex-start!important}.align-self-lg-end{-ms-flex-item-align:end!important;align-self:flex-end!important}.align-self-lg-center{-ms-flex-item-align:center!important;align-self:center!important}.align-self-lg-baseline{-ms-flex-item-align:baseline!important;align-self:baseline!important}.align-self-lg-stretch{-ms-flex-item-align:stretch!important;align-self:stretch!important}}@media (min-width:1200px){.flex-xl-row{-ms-flex-direction:row!important;flex-direction:row!important}.flex-xl-column{-ms-flex-direction:column!important;flex-direction:column!important}.flex-xl-row-reverse{-ms-flex-direction:row-reverse!important;flex-direction:row-reverse!important}.flex-xl-column-reverse{-ms-flex-direction:column-reverse!important;flex-direction:column-reverse!important}.flex-xl-wrap{-ms-flex-wrap:wrap!important;flex-wrap:wrap!important}.flex-xl-nowrap{-ms-flex-wrap:nowrap!important;flex-wrap:nowrap!important}.flex-xl-wrap-reverse{-ms-flex-wrap:wrap-reverse!important;flex-wrap:wrap-reverse!important}.justify-content-xl-start{-ms-flex-pack:start!important;justify-content:flex-start!important}.justify-content-xl-end{-ms-flex-pack:end!important;justify-content:flex-end!important}.justify-content-xl-center{-ms-flex-pack:center!important;justify-content:center!important}.justify-content-xl-between{-ms-flex-pack:justify!important;justify-content:space-between!important}.justify-content-xl-around{-ms-flex-pack:distribute!important;justify-content:space-around!important}.align-items-xl-start{-ms-flex-align:start!important;align-items:flex-start!important}.align-items-xl-end{-ms-flex-align:end!important;align-items:flex-end!important}.align-items-xl-center{-ms-flex-align:center!important;align-items:center!important}.align-items-xl-baseline{-ms-flex-align:baseline!important;align-items:baseline!important}.align-items-xl-stretch{-ms-flex-align:stretch!important;align-items:stretch!important}.align-content-xl-start{-ms-flex-line-pack:start!important;align-content:flex-start!important}.align-content-xl-end{-ms-flex-line-pack:end!important;align-content:flex-end!important}.align-content-xl-center{-ms-flex-line-pack:center!important;align-content:center!important}.align-content-xl-between{-ms-flex-line-pack:justify!important;align-content:space-between!important}.align-content-xl-around{-ms-flex-line-pack:distribute!important;align-content:space-around!important}.align-content-xl-stretch{-ms-flex-line-pack:stretch!important;align-content:stretch!important}.align-self-xl-auto{-ms-flex-item-align:auto!important;align-self:auto!important}.align-self-xl-start{-ms-flex-item-align:start!important;align-self:flex-start!important}.align-self-xl-end{-ms-flex-item-align:end!important;align-self:flex-end!important}.align-self-xl-center{-ms-flex-item-align:center!important;align-self:center!important}.align-self-xl-baseline{-ms-flex-item-align:baseline!important;align-self:baseline!important}.align-self-xl-stretch{-ms-flex-item-align:stretch!important;align-self:stretch!important}}.float-left{float:left!important}.float-right{float:right!important}.float-none{float:none!important}@media (min-width:576px){.float-sm-left{float:left!important}.float-sm-right{float:right!important}.float-sm-none{float:none!important}}@media (min-width:768px){.float-md-left{float:left!important}.float-md-right{float:right!important}.float-md-none{float:none!important}}@media (min-width:992px){.float-lg-left{float:left!important}.float-lg-right{float:right!important}.float-lg-none{float:none!important}}@media (min-width:1200px){.float-xl-left{float:left!important}.float-xl-right{float:right!important}.float-xl-none{float:none!important}}.fixed-top{position:fixed;top:0;right:0;left:0;z-index:1030}.fixed-bottom{position:fixed;right:0;bottom:0;left:0;z-index:1030}@supports ((position:-webkit-sticky) or (position:sticky)){.sticky-top{position:-webkit-sticky;position:sticky;top:0;z-index:1020}}.sr-only{position:absolute;width:1px;height:1px;padding:0;overflow:hidden;clip:rect(0,0,0,0);white-space:nowrap;-webkit-clip-path:inset(50%);clip-path:inset(50%);border:0}.sr-only-focusable:active,.sr-only-focusable:focus{position:static;width:auto;height:auto;overflow:visible;clip:auto;white-space:normal;-webkit-clip-path:none;clip-path:none}.w-25{width:25%!important}.w-50{width:50%!important}.w-75{width:75%!important}.w-100{width:100%!important}.h-25{height:25%!important}.h-50{height:50%!important}.h-75{height:75%!important}.h-100{height:100%!important}.mw-100{max-width:100%!important}.mh-100{max-height:100%!important}.m-0{margin:0!important}.mt-0{margin-top:0!important}.mr-0{margin-right:0!important}.mb-0{margin-bottom:0!important}.ml-0{margin-left:0!important}.mx-0{margin-right:0!important;margin-left:0!important}.my-0{margin-top:0!important;margin-bottom:0!important}.m-1{margin:.25rem!important}.mt-1{margin-top:.25rem!important}.mr-1{margin-right:.25rem!important}.mb-1{margin-bottom:.25rem!important}.ml-1{margin-left:.25rem!important}.mx-1{margin-right:.25rem!important;margin-left:.25rem!important}.my-1{margin-top:.25rem!important;margin-bottom:.25rem!important}.m-2{margin:.5rem!important}.mt-2{margin-top:.5rem!important}.mr-2{margin-right:.5rem!important}.mb-2{margin-bottom:.5rem!important}.ml-2{margin-left:.5rem!important}.mx-2{margin-right:.5rem!important;margin-left:.5rem!important}.my-2{margin-top:.5rem!important;margin-bottom:.5rem!important}.m-3{margin:1rem!important}.mt-3{margin-top:1rem!important}.mr-3{margin-right:1rem!important}.mb-3{margin-bottom:1rem!important}.ml-3{margin-left:1rem!important}.mx-3{margin-right:1rem!important;margin-left:1rem!important}.my-3{margin-top:1rem!important;margin-bottom:1rem!important}.m-4{margin:1.5rem!important}.mt-4{margin-top:1.5rem!important}.mr-4{margin-right:1.5rem!important}.mb-4{margin-bottom:1.5rem!important}.ml-4{margin-left:1.5rem!important}.mx-4{margin-right:1.5rem!important;margin-left:1.5rem!important}.my-4{margin-top:1.5rem!important;margin-bottom:1.5rem!important}.m-5{margin:3rem!important}.mt-5{margin-top:3rem!important}.mr-5{margin-right:3rem!important}.mb-5{margin-bottom:3rem!important}.ml-5{margin-left:3rem!important}.mx-5{margin-right:3rem!important;margin-left:3rem!important}.my-5{margin-top:3rem!important;margin-bottom:3rem!important}.p-0{padding:0!important}.pt-0{padding-top:0!important}.pr-0{padding-right:0!important}.pb-0{padding-bottom:0!important}.pl-0{padding-left:0!important}.px-0{padding-right:0!important;padding-left:0!important}.py-0{padding-top:0!important;padding-bottom:0!important}.p-1{padding:.25rem!important}.pt-1{padding-top:.25rem!important}.pr-1{padding-right:.25rem!important}.pb-1{padding-bottom:.25rem!important}.pl-1{padding-left:.25rem!important}.px-1{padding-right:.25rem!important;padding-left:.25rem!important}.py-1{padding-top:.25rem!important;padding-bottom:.25rem!important}.p-2{padding:.5rem!important}.pt-2{padding-top:.5rem!important}.pr-2{padding-right:.5rem!important}.pb-2{padding-bottom:.5rem!important}.pl-2{padding-left:.5rem!important}.px-2{padding-right:.5rem!important;padding-left:.5rem!important}.py-2{padding-top:.5rem!important;padding-bottom:.5rem!important}.p-3{padding:1rem!important}.pt-3{padding-top:1rem!important}.pr-3{padding-right:1rem!important}.pb-3{padding-bottom:1rem!important}.pl-3{padding-left:1rem!important}.px-3{padding-right:1rem!important;padding-left:1rem!important}.py-3{padding-top:1rem!important;padding-bottom:1rem!important}.p-4{padding:1.5rem!important}.pt-4{padding-top:1.5rem!important}.pr-4{padding-right:1.5rem!important}.pb-4{padding-bottom:1.5rem!important}.pl-4{padding-left:1.5rem!important}.px-4{padding-right:1.5rem!important;padding-left:1.5rem!important}.py-4{padding-top:1.5rem!important;padding-bottom:1.5rem!important}.p-5{padding:3rem!important}.pt-5{padding-top:3rem!important}.pr-5{padding-right:3rem!important}.pb-5{padding-bottom:3rem!important}.pl-5{padding-left:3rem!important}.px-5{padding-right:3rem!important;padding-left:3rem!important}.py-5{padding-top:3rem!important;padding-bottom:3rem!important}.m-auto{margin:auto!important}.mt-auto{margin-top:auto!important}.mr-auto{margin-right:auto!important}.mb-auto{margin-bottom:auto!important}.ml-auto{margin-left:auto!important}.mx-auto{margin-right:auto!important;margin-left:auto!important}.my-auto{margin-top:auto!important;margin-bottom:auto!important}@media (min-width:576px){.m-sm-0{margin:0!important}.mt-sm-0{margin-top:0!important}.mr-sm-0{margin-right:0!important}.mb-sm-0{margin-bottom:0!important}.ml-sm-0{margin-left:0!important}.mx-sm-0{margin-right:0!important;margin-left:0!important}.my-sm-0{margin-top:0!important;margin-bottom:0!important}.m-sm-1{margin:.25rem!important}.mt-sm-1{margin-top:.25rem!important}.mr-sm-1{margin-right:.25rem!important}.mb-sm-1{margin-bottom:.25rem!important}.ml-sm-1{margin-left:.25rem!important}.mx-sm-1{margin-right:.25rem!important;margin-left:.25rem!important}.my-sm-1{margin-top:.25rem!important;margin-bottom:.25rem!important}.m-sm-2{margin:.5rem!important}.mt-sm-2{margin-top:.5rem!important}.mr-sm-2{margin-right:.5rem!important}.mb-sm-2{margin-bottom:.5rem!important}.ml-sm-2{margin-left:.5rem!important}.mx-sm-2{margin-right:.5rem!important;margin-left:.5rem!important}.my-sm-2{margin-top:.5rem!important;margin-bottom:.5rem!important}.m-sm-3{margin:1rem!important}.mt-sm-3{margin-top:1rem!important}.mr-sm-3{margin-right:1rem!important}.mb-sm-3{margin-bottom:1rem!important}.ml-sm-3{margin-left:1rem!important}.mx-sm-3{margin-right:1rem!important;margin-left:1rem!important}.my-sm-3{margin-top:1rem!important;margin-bottom:1rem!important}.m-sm-4{margin:1.5rem!important}.mt-sm-4{margin-top:1.5rem!important}.mr-sm-4{margin-right:1.5rem!important}.mb-sm-4{margin-bottom:1.5rem!important}.ml-sm-4{margin-left:1.5rem!important}.mx-sm-4{margin-right:1.5rem!important;margin-left:1.5rem!important}.my-sm-4{margin-top:1.5rem!important;margin-bottom:1.5rem!important}.m-sm-5{margin:3rem!important}.mt-sm-5{margin-top:3rem!important}.mr-sm-5{margin-right:3rem!important}.mb-sm-5{margin-bottom:3rem!important}.ml-sm-5{margin-left:3rem!important}.mx-sm-5{margin-right:3rem!important;margin-left:3rem!important}.my-sm-5{margin-top:3rem!important;margin-bottom:3rem!important}.p-sm-0{padding:0!important}.pt-sm-0{padding-top:0!important}.pr-sm-0{padding-right:0!important}.pb-sm-0{padding-bottom:0!important}.pl-sm-0{padding-left:0!important}.px-sm-0{padding-right:0!important;padding-left:0!important}.py-sm-0{padding-top:0!important;padding-bottom:0!important}.p-sm-1{padding:.25rem!important}.pt-sm-1{padding-top:.25rem!important}.pr-sm-1{padding-right:.25rem!important}.pb-sm-1{padding-bottom:.25rem!important}.pl-sm-1{padding-left:.25rem!important}.px-sm-1{padding-right:.25rem!important;padding-left:.25rem!important}.py-sm-1{padding-top:.25rem!important;padding-bottom:.25rem!important}.p-sm-2{padding:.5rem!important}.pt-sm-2{padding-top:.5rem!important}.pr-sm-2{padding-right:.5rem!important}.pb-sm-2{padding-bottom:.5rem!important}.pl-sm-2{padding-left:.5rem!important}.px-sm-2{padding-right:.5rem!important;padding-left:.5rem!important}.py-sm-2{padding-top:.5rem!important;padding-bottom:.5rem!important}.p-sm-3{padding:1rem!important}.pt-sm-3{padding-top:1rem!important}.pr-sm-3{padding-right:1rem!important}.pb-sm-3{padding-bottom:1rem!important}.pl-sm-3{padding-left:1rem!important}.px-sm-3{padding-right:1rem!important;padding-left:1rem!important}.py-sm-3{padding-top:1rem!important;padding-bottom:1rem!important}.p-sm-4{padding:1.5rem!important}.pt-sm-4{padding-top:1.5rem!important}.pr-sm-4{padding-right:1.5rem!important}.pb-sm-4{padding-bottom:1.5rem!important}.pl-sm-4{padding-left:1.5rem!important}.px-sm-4{padding-right:1.5rem!important;padding-left:1.5rem!important}.py-sm-4{padding-top:1.5rem!important;padding-bottom:1.5rem!important}.p-sm-5{padding:3rem!important}.pt-sm-5{padding-top:3rem!important}.pr-sm-5{padding-right:3rem!important}.pb-sm-5{padding-bottom:3rem!important}.pl-sm-5{padding-left:3rem!important}.px-sm-5{padding-right:3rem!important;padding-left:3rem!important}.py-sm-5{padding-top:3rem!important;padding-bottom:3rem!important}.m-sm-auto{margin:auto!important}.mt-sm-auto{margin-top:auto!important}.mr-sm-auto{margin-right:auto!important}.mb-sm-auto{margin-bottom:auto!important}.ml-sm-auto{margin-left:auto!important}.mx-sm-auto{margin-right:auto!important;margin-left:auto!important}.my-sm-auto{margin-top:auto!important;margin-bottom:auto!important}}@media (min-width:768px){.m-md-0{margin:0!important}.mt-md-0{margin-top:0!important}.mr-md-0{margin-right:0!important}.mb-md-0{margin-bottom:0!important}.ml-md-0{margin-left:0!important}.mx-md-0{margin-right:0!important;margin-left:0!important}.my-md-0{margin-top:0!important;margin-bottom:0!important}.m-md-1{margin:.25rem!important}.mt-md-1{margin-top:.25rem!important}.mr-md-1{margin-right:.25rem!important}.mb-md-1{margin-bottom:.25rem!important}.ml-md-1{margin-left:.25rem!important}.mx-md-1{margin-right:.25rem!important;margin-left:.25rem!important}.my-md-1{margin-top:.25rem!important;margin-bottom:.25rem!important}.m-md-2{margin:.5rem!important}.mt-md-2{margin-top:.5rem!important}.mr-md-2{margin-right:.5rem!important}.mb-md-2{margin-bottom:.5rem!important}.ml-md-2{margin-left:.5rem!important}.mx-md-2{margin-right:.5rem!important;margin-left:.5rem!important}.my-md-2{margin-top:.5rem!important;margin-bottom:.5rem!important}.m-md-3{margin:1rem!important}.mt-md-3{margin-top:1rem!important}.mr-md-3{margin-right:1rem!important}.mb-md-3{margin-bottom:1rem!important}.ml-md-3{margin-left:1rem!important}.mx-md-3{margin-right:1rem!important;margin-left:1rem!important}.my-md-3{margin-top:1rem!important;margin-bottom:1rem!important}.m-md-4{margin:1.5rem!important}.mt-md-4{margin-top:1.5rem!important}.mr-md-4{margin-right:1.5rem!important}.mb-md-4{margin-bottom:1.5rem!important}.ml-md-4{margin-left:1.5rem!important}.mx-md-4{margin-right:1.5rem!important;margin-left:1.5rem!important}.my-md-4{margin-top:1.5rem!important;margin-bottom:1.5rem!important}.m-md-5{margin:3rem!important}.mt-md-5{margin-top:3rem!important}.mr-md-5{margin-right:3rem!important}.mb-md-5{margin-bottom:3rem!important}.ml-md-5{margin-left:3rem!important}.mx-md-5{margin-right:3rem!important;margin-left:3rem!important}.my-md-5{margin-top:3rem!important;margin-bottom:3rem!important}.p-md-0{padding:0!important}.pt-md-0{padding-top:0!important}.pr-md-0{padding-right:0!important}.pb-md-0{padding-bottom:0!important}.pl-md-0{padding-left:0!important}.px-md-0{padding-right:0!important;padding-left:0!important}.py-md-0{padding-top:0!important;padding-bottom:0!important}.p-md-1{padding:.25rem!important}.pt-md-1{padding-top:.25rem!important}.pr-md-1{padding-right:.25rem!important}.pb-md-1{padding-bottom:.25rem!important}.pl-md-1{padding-left:.25rem!important}.px-md-1{padding-right:.25rem!important;padding-left:.25rem!important}.py-md-1{padding-top:.25rem!important;padding-bottom:.25rem!important}.p-md-2{padding:.5rem!important}.pt-md-2{padding-top:.5rem!important}.pr-md-2{padding-right:.5rem!important}.pb-md-2{padding-bottom:.5rem!important}.pl-md-2{padding-left:.5rem!important}.px-md-2{padding-right:.5rem!important;padding-left:.5rem!important}.py-md-2{padding-top:.5rem!important;padding-bottom:.5rem!important}.p-md-3{padding:1rem!important}.pt-md-3{padding-top:1rem!important}.pr-md-3{padding-right:1rem!important}.pb-md-3{padding-bottom:1rem!important}.pl-md-3{padding-left:1rem!important}.px-md-3{padding-right:1rem!important;padding-left:1rem!important}.py-md-3{padding-top:1rem!important;padding-bottom:1rem!important}.p-md-4{padding:1.5rem!important}.pt-md-4{padding-top:1.5rem!important}.pr-md-4{padding-right:1.5rem!important}.pb-md-4{padding-bottom:1.5rem!important}.pl-md-4{padding-left:1.5rem!important}.px-md-4{padding-right:1.5rem!important;padding-left:1.5rem!important}.py-md-4{padding-top:1.5rem!important;padding-bottom:1.5rem!important}.p-md-5{padding:3rem!important}.pt-md-5{padding-top:3rem!important}.pr-md-5{padding-right:3rem!important}.pb-md-5{padding-bottom:3rem!important}.pl-md-5{padding-left:3rem!important}.px-md-5{padding-right:3rem!important;padding-left:3rem!important}.py-md-5{padding-top:3rem!important;padding-bottom:3rem!important}.m-md-auto{margin:auto!important}.mt-md-auto{margin-top:auto!important}.mr-md-auto{margin-right:auto!important}.mb-md-auto{margin-bottom:auto!important}.ml-md-auto{margin-left:auto!important}.mx-md-auto{margin-right:auto!important;margin-left:auto!important}.my-md-auto{margin-top:auto!important;margin-bottom:auto!important}}@media (min-width:992px){.m-lg-0{margin:0!important}.mt-lg-0{margin-top:0!important}.mr-lg-0{margin-right:0!important}.mb-lg-0{margin-bottom:0!important}.ml-lg-0{margin-left:0!important}.mx-lg-0{margin-right:0!important;margin-left:0!important}.my-lg-0{margin-top:0!important;margin-bottom:0!important}.m-lg-1{margin:.25rem!important}.mt-lg-1{margin-top:.25rem!important}.mr-lg-1{margin-right:.25rem!important}.mb-lg-1{margin-bottom:.25rem!important}.ml-lg-1{margin-left:.25rem!important}.mx-lg-1{margin-right:.25rem!important;margin-left:.25rem!important}.my-lg-1{margin-top:.25rem!important;margin-bottom:.25rem!important}.m-lg-2{margin:.5rem!important}.mt-lg-2{margin-top:.5rem!important}.mr-lg-2{margin-right:.5rem!important}.mb-lg-2{margin-bottom:.5rem!important}.ml-lg-2{margin-left:.5rem!important}.mx-lg-2{margin-right:.5rem!important;margin-left:.5rem!important}.my-lg-2{margin-top:.5rem!important;margin-bottom:.5rem!important}.m-lg-3{margin:1rem!important}.mt-lg-3{margin-top:1rem!important}.mr-lg-3{margin-right:1rem!important}.mb-lg-3{margin-bottom:1rem!important}.ml-lg-3{margin-left:1rem!important}.mx-lg-3{margin-right:1rem!important;margin-left:1rem!important}.my-lg-3{margin-top:1rem!important;margin-bottom:1rem!important}.m-lg-4{margin:1.5rem!important}.mt-lg-4{margin-top:1.5rem!important}.mr-lg-4{margin-right:1.5rem!important}.mb-lg-4{margin-bottom:1.5rem!important}.ml-lg-4{margin-left:1.5rem!important}.mx-lg-4{margin-right:1.5rem!important;margin-left:1.5rem!important}.my-lg-4{margin-top:1.5rem!important;margin-bottom:1.5rem!important}.m-lg-5{margin:3rem!important}.mt-lg-5{margin-top:3rem!important}.mr-lg-5{margin-right:3rem!important}.mb-lg-5{margin-bottom:3rem!important}.ml-lg-5{margin-left:3rem!important}.mx-lg-5{margin-right:3rem!important;margin-left:3rem!important}.my-lg-5{margin-top:3rem!important;margin-bottom:3rem!important}.p-lg-0{padding:0!important}.pt-lg-0{padding-top:0!important}.pr-lg-0{padding-right:0!important}.pb-lg-0{padding-bottom:0!important}.pl-lg-0{padding-left:0!important}.px-lg-0{padding-right:0!important;padding-left:0!important}.py-lg-0{padding-top:0!important;padding-bottom:0!important}.p-lg-1{padding:.25rem!important}.pt-lg-1{padding-top:.25rem!important}.pr-lg-1{padding-right:.25rem!important}.pb-lg-1{padding-bottom:.25rem!important}.pl-lg-1{padding-left:.25rem!important}.px-lg-1{padding-right:.25rem!important;padding-left:.25rem!important}.py-lg-1{padding-top:.25rem!important;padding-bottom:.25rem!important}.p-lg-2{padding:.5rem!important}.pt-lg-2{padding-top:.5rem!important}.pr-lg-2{padding-right:.5rem!important}.pb-lg-2{padding-bottom:.5rem!important}.pl-lg-2{padding-left:.5rem!important}.px-lg-2{padding-right:.5rem!important;padding-left:.5rem!important}.py-lg-2{padding-top:.5rem!important;padding-bottom:.5rem!important}.p-lg-3{padding:1rem!important}.pt-lg-3{padding-top:1rem!important}.pr-lg-3{padding-right:1rem!important}.pb-lg-3{padding-bottom:1rem!important}.pl-lg-3{padding-left:1rem!important}.px-lg-3{padding-right:1rem!important;padding-left:1rem!important}.py-lg-3{padding-top:1rem!important;padding-bottom:1rem!important}.p-lg-4{padding:1.5rem!important}.pt-lg-4{padding-top:1.5rem!important}.pr-lg-4{padding-right:1.5rem!important}.pb-lg-4{padding-bottom:1.5rem!important}.pl-lg-4{padding-left:1.5rem!important}.px-lg-4{padding-right:1.5rem!important;padding-left:1.5rem!important}.py-lg-4{padding-top:1.5rem!important;padding-bottom:1.5rem!important}.p-lg-5{padding:3rem!important}.pt-lg-5{padding-top:3rem!important}.pr-lg-5{padding-right:3rem!important}.pb-lg-5{padding-bottom:3rem!important}.pl-lg-5{padding-left:3rem!important}.px-lg-5{padding-right:3rem!important;padding-left:3rem!important}.py-lg-5{padding-top:3rem!important;padding-bottom:3rem!important}.m-lg-auto{margin:auto!important}.mt-lg-auto{margin-top:auto!important}.mr-lg-auto{margin-right:auto!important}.mb-lg-auto{margin-bottom:auto!important}.ml-lg-auto{margin-left:auto!important}.mx-lg-auto{margin-right:auto!important;margin-left:auto!important}.my-lg-auto{margin-top:auto!important;margin-bottom:auto!important}}@media (min-width:1200px){.m-xl-0{margin:0!important}.mt-xl-0{margin-top:0!important}.mr-xl-0{margin-right:0!important}.mb-xl-0{margin-bottom:0!important}.ml-xl-0{margin-left:0!important}.mx-xl-0{margin-right:0!important;margin-left:0!important}.my-xl-0{margin-top:0!important;margin-bottom:0!important}.m-xl-1{margin:.25rem!important}.mt-xl-1{margin-top:.25rem!important}.mr-xl-1{margin-right:.25rem!important}.mb-xl-1{margin-bottom:.25rem!important}.ml-xl-1{margin-left:.25rem!important}.mx-xl-1{margin-right:.25rem!important;margin-left:.25rem!important}.my-xl-1{margin-top:.25rem!important;margin-bottom:.25rem!important}.m-xl-2{margin:.5rem!important}.mt-xl-2{margin-top:.5rem!important}.mr-xl-2{margin-right:.5rem!important}.mb-xl-2{margin-bottom:.5rem!important}.ml-xl-2{margin-left:.5rem!important}.mx-xl-2{margin-right:.5rem!important;margin-left:.5rem!important}.my-xl-2{margin-top:.5rem!important;margin-bottom:.5rem!important}.m-xl-3{margin:1rem!important}.mt-xl-3{margin-top:1rem!important}.mr-xl-3{margin-right:1rem!important}.mb-xl-3{margin-bottom:1rem!important}.ml-xl-3{margin-left:1rem!important}.mx-xl-3{margin-right:1rem!important;margin-left:1rem!important}.my-xl-3{margin-top:1rem!important;margin-bottom:1rem!important}.m-xl-4{margin:1.5rem!important}.mt-xl-4{margin-top:1.5rem!important}.mr-xl-4{margin-right:1.5rem!important}.mb-xl-4{margin-bottom:1.5rem!important}.ml-xl-4{margin-left:1.5rem!important}.mx-xl-4{margin-right:1.5rem!important;margin-left:1.5rem!important}.my-xl-4{margin-top:1.5rem!important;margin-bottom:1.5rem!important}.m-xl-5{margin:3rem!important}.mt-xl-5{margin-top:3rem!important}.mr-xl-5{margin-right:3rem!important}.mb-xl-5{margin-bottom:3rem!important}.ml-xl-5{margin-left:3rem!important}.mx-xl-5{margin-right:3rem!important;margin-left:3rem!important}.my-xl-5{margin-top:3rem!important;margin-bottom:3rem!important}.p-xl-0{padding:0!important}.pt-xl-0{padding-top:0!important}.pr-xl-0{padding-right:0!important}.pb-xl-0{padding-bottom:0!important}.pl-xl-0{padding-left:0!important}.px-xl-0{padding-right:0!important;padding-left:0!important}.py-xl-0{padding-top:0!important;padding-bottom:0!important}.p-xl-1{padding:.25rem!important}.pt-xl-1{padding-top:.25rem!important}.pr-xl-1{padding-right:.25rem!important}.pb-xl-1{padding-bottom:.25rem!important}.pl-xl-1{padding-left:.25rem!important}.px-xl-1{padding-right:.25rem!important;padding-left:.25rem!important}.py-xl-1{padding-top:.25rem!important;padding-bottom:.25rem!important}.p-xl-2{padding:.5rem!important}.pt-xl-2{padding-top:.5rem!important}.pr-xl-2{padding-right:.5rem!important}.pb-xl-2{padding-bottom:.5rem!important}.pl-xl-2{padding-left:.5rem!important}.px-xl-2{padding-right:.5rem!important;padding-left:.5rem!important}.py-xl-2{padding-top:.5rem!important;padding-bottom:.5rem!important}.p-xl-3{padding:1rem!important}.pt-xl-3{padding-top:1rem!important}.pr-xl-3{padding-right:1rem!important}.pb-xl-3{padding-bottom:1rem!important}.pl-xl-3{padding-left:1rem!important}.px-xl-3{padding-right:1rem!important;padding-left:1rem!important}.py-xl-3{padding-top:1rem!important;padding-bottom:1rem!important}.p-xl-4{padding:1.5rem!important}.pt-xl-4{padding-top:1.5rem!important}.pr-xl-4{padding-right:1.5rem!important}.pb-xl-4{padding-bottom:1.5rem!important}.pl-xl-4{padding-left:1.5rem!important}.px-xl-4{padding-right:1.5rem!important;padding-left:1.5rem!important}.py-xl-4{padding-top:1.5rem!important;padding-bottom:1.5rem!important}.p-xl-5{padding:3rem!important}.pt-xl-5{padding-top:3rem!important}.pr-xl-5{padding-right:3rem!important}.pb-xl-5{padding-bottom:3rem!important}.pl-xl-5{padding-left:3rem!important}.px-xl-5{padding-right:3rem!important;padding-left:3rem!important}.py-xl-5{padding-top:3rem!important;padding-bottom:3rem!important}.m-xl-auto{margin:auto!important}.mt-xl-auto{margin-top:auto!important}.mr-xl-auto{margin-right:auto!important}.mb-xl-auto{margin-bottom:auto!important}.ml-xl-auto{margin-left:auto!important}.mx-xl-auto{margin-right:auto!important;margin-left:auto!important}.my-xl-auto{margin-top:auto!important;margin-bottom:auto!important}}.text-justify{text-align:justify!important}.text-nowrap{white-space:nowrap!important}.text-truncate{overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.text-left{text-align:left!important}.text-right{text-align:right!important}.text-center{text-align:center!important}@media (min-width:576px){.text-sm-left{text-align:left!important}.text-sm-right{text-align:right!important}.text-sm-center{text-align:center!important}}@media (min-width:768px){.text-md-left{text-align:left!important}.text-md-right{text-align:right!important}.text-md-center{text-align:center!important}}@media (min-width:992px){.text-lg-left{text-align:left!important}.text-lg-right{text-align:right!important}.text-lg-center{text-align:center!important}}@media (min-width:1200px){.text-xl-left{text-align:left!important}.text-xl-right{text-align:right!important}.text-xl-center{text-align:center!important}}.text-lowercase{text-transform:lowercase!important}.text-uppercase{text-transform:uppercase!important}.text-capitalize{text-transform:capitalize!important}.font-weight-normal{font-weight:400}.font-weight-bold{font-weight:700}.font-italic{font-style:italic}.text-white{color:#fff!important}.text-primary{color:#007bff!important}a.text-primary:focus,a.text-primary:hover{color:#0062cc!important}.text-secondary{color:#868e96!important}a.text-secondary:focus,a.text-secondary:hover{color:#6c757d!important}.text-success{color:#28a745!important}a.text-success:focus,a.text-success:hover{color:#1e7e34!important}.text-info{color:#17a2b8!important}a.text-info:focus,a.text-info:hover{color:#117a8b!important}.text-warning{color:#ffc107!important}a.text-warning:focus,a.text-warning:hover{color:#d39e00!important}.text-danger{color:#dc3545!important}a.text-danger:focus,a.text-danger:hover{color:#bd2130!important}.text-light{color:#f8f9fa!important}a.text-light:focus,a.text-light:hover{color:#dae0e5!important}.text-dark{color:#343a40!important}a.text-dark:focus,a.text-dark:hover{color:#1d2124!important}.text-muted{color:#868e96!important}.text-hide{font:0/0 a;color:transparent;text-shadow:none;background-color:transparent;border:0}.visible{visibility:visible!important}.invisible{visibility:hidden!important}
 /*# sourceMappingURL=bootstrap.min.css.map */
    </style>
    <style>
    /*------------------------------------------------------------------
Project:  
Version:  
Last change:  
Assigned to:  Le Xuan Bach
Primary use:  Company
-------------------------------------------------------------------*/
/*------------------------------------------------------------------
[LAYOUT]

* body
  + Header / header
  + Page Content / .page-content .name-page
        + Section Layouts / section .name-section
        ...
  + Footer / footer

-------------------------------------------------------------------*/
/*------------------------------------------------------------------
[COLOR CODES]

# Text Color      :  
# Primary Color 01:  
# Primary Color 02:   
# Primary Color 03:  

------------------------------------------------------------------*/
/*------------------------------------------------------------------
[TYPOGRAPHY]

Body            : 16px/1.6 '', Arial, sans-serif;
Title           : 18px/1.6 '', Arial, sans-serif;
Paragrap        : 18px/1.6 '', Arial, sans-serif;
Input, textarea : 14px/1.6 '', Arial, sans-serif;
-------------------------------------------------------------------*/



/*//////////////////////////////////////////////////////////////////
[ FONT ]*/

@import url('https://fonts.googleapis.com/css2?family=Roboto+Condensed:ital,wght@0,300;0,400;0,700;1,300;1,400&display=swap');

/* @font-face {
  font-family: 'Roboto Condensed', sans-serif;;
  src: url('https://fonts.googleapis.com/css2?family=Roboto:wght@400&display=swap'); 
}

@font-face {
  font-family: 'Roboto Condensed', sans-serif;;
  src: url('https://fonts.googleapis.com/css2?family=Roboto:wght@300&display=swap'); 
}

@font-face {
  font-family: 'Roboto Condensed', sans-serif;;
  src: url('https://fonts.googleapis.com/css2?family=Roboto:wght@100&display=swap'); 
}

@font-face {
  font-family: 'Roboto Condensed', sans-serif;;
  src: url('https://fonts.googleapis.com/css2?family=Roboto:wght@400&display=swap'); 
}

@font-face {
  font-family: 'Roboto Condensed', sans-serif;;
  src: url('../fonts/Poppins/'Roboto Condensed', sans-serif;.ttf'); 
}

@font-face {
  font-family: 'Roboto Condensed', sans-serif;;
  src: url('https://fonts.googleapis.com/css2?family=Roboto:wght@500&display=swap'); 
}

@font-face {
  font-family: 'Roboto Condensed', sans-serif;;
  src: url('https://fonts.googleapis.com/css2?family=Roboto:wght@500&display=swap'); 
} */


/*//////////////////////////////////////////////////////////////////
[ RS PLUGIN ]*/

/*------------------------------------------------------------------
[ Bootstrap ]*/
.container {max-width: 1380px;}

@media (max-width: 1600px) {
  .container {max-width: 1200px;}
}

/*------------------------------------------------------------------
[ Slick2 ]*/
.slick-slide {outline: none !important;}


html {
  font-family: 'Roboto', sans-serif !important;
}

footer {
  font-family: 'Roboto', sans-serif !important;
}


/*//////////////////////////////////////////////////////////////////
[ LOADDING ]*/
.animsition-loading-1 {
  position: absolute;
  top: 50%;
  left: 50%;
  -webkit-transform: translate(-50%, -50%);
  -moz-transform: translate(-50%, -50%);
  -ms-transform: translate(-50%, -50%);
  -o-transform: translate(-50%, -50%);
  transform: translate(-50%, -50%);
}

.loader05 {
  width: 56px;
  height: 56px;
  border: 4px solid #717fe0;
  border-radius: 50%;
  position: relative;
  animation: loader-scale 1s ease-out infinite;
  top: 50%;
  margin: -28px auto 0 auto; 
}

@keyframes loader-scale {
  0% {
    transform: scale(0);
    opacity: 0; }
  50% {
    opacity: 1; }
  100% {
    transform: scale(1);
    opacity: 0; } 
}

/*//////////////////////////////////////////////////////////////////
[ BUTTON BACK TO TOP ]*/
.btn-back-to-top {
  display: none;
  position: fixed;
  width: 40px;
  height: 38px;
  bottom: 0px;
  right: 40px;
  background-color: #717fe0;
  opacity: 0.5;
  justify-content: center;
  align-items: center;
  z-index: 1000;
  cursor: pointer;
  transition: all 0.4s;
  -webkit-transition: all 0.4s;
  -o-transition: all 0.4s;
  -moz-transition: all 0.4s;
}

.symbol-btn-back-to-top {
  font-size: 25px;
  color: white;
  line-height: 1em;
}

.btn-back-to-top:hover {
  opacity: 1;
  background-color: #717fe0;
}

@media (max-width: 575px) {
  .btn-back-to-top {
    bottom: 0px;
    right: 15px;
  }
}


/*//////////////////////////////////////////////////////////////////
[ Header ]*/

/*>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
[ Header Desktop ]*/

.container-menu-desktop {
  height: auto;
  width: 100%;
  position: relative;
  -webkit-transition: all 0.3s;
  -o-transition: all 0.3s;
  -moz-transition: all 0.3s;
  transition: all 0.3s;
}

.header-v2 .container-menu-desktop {
  height: 84px;
}

.header-v3 .container-menu-desktop {
  height: auto;
}

.header-v4 .container-menu-desktop {
  height: 90px;
}


/*==================================================================
[ Top bar ]*/
.top-bar {
  height: 40px;
  background-color: #222;
}

/*---------------------------------------------*/
.left-top-bar {
  font-family: 'Roboto Condensed', sans-serif;;
  font-size: 12px;
  line-height: 1.8;
  color: #b2b2b2;
}


/*---------------------------------------------*/
.right-top-bar a {
  font-family: 'Roboto Condensed', sans-serif;;
  font-size: 12px;
  line-height: 1.8;

  height: 100%;
  color: #b2b2b2;
  border-right: 1px solid rgba(255,255,255,0.3);
}

.right-top-bar a:first-child {
  border-left: 1px solid rgba(255,255,255,0.3);
}

.right-top-bar a:hover {
  color: #6c7ae0;
}


/*---------------------------------------------*/
.topbar-mobile li {
  padding: 8px 20px;
  border-top: 1px solid rgba(255,255,255,0.05);
  background-color: #222;
}



/*==================================================================
[ Menu ]*/

.wrap-menu-desktop {
  position: fixed;
  z-index: 1100;
  background-color: transparent;
  width: 100%;
  height: 84px;
  top: 0px;
  left: 0px; 

  -webkit-transition: height 0.3s, background-color 0.3s;
  -o-transition: height 0.3s, background-color 0.3s;
  -moz-transition: height 0.3s, background-color 0.3s;
  transition: height 0.3s, background-color 0.3s;
}

.header-v2 .wrap-menu-desktop {
  background-color: #fff;
  top: 0;
}

.header-v3 .wrap-menu-desktop {
  background-color: transparent;
  top: 0;
  border-bottom: 1px solid rgba(255,255,255,0.1);
}

.header-v4 .wrap-menu-desktop {
  background-color: #fff;
}


/*---------------------------------------------*/
.limiter-menu-desktop {
  height: 100%;
  display: -webkit-box;
  display: -webkit-flex;
  display: -moz-box;
  display: -ms-flexbox;
  display: flex;
  align-items: center;
  background-color: transparent;
}



/*------------------------------------------------------------------
[ Logo ]*/
.logo {
  display: -webkit-box;
  display: -webkit-flex;
  display: -moz-box;
  display: -ms-flexbox;
  display: flex;
  align-items: center;
  height: 65%;
  margin-right: 55px;
}

.logo img {
  max-width: 100%;
  max-height: 100%;
}



/*------------------------------------------------------------------
[ Menu ]*/

.menu-desktop {
  display: -webkit-box;
  display: -webkit-flex;
  display: -moz-box;
  display: -ms-flexbox;
  display: flex;
  align-items: center;
  height: 100%;
}

.main-menu {
  list-style-type: none;
  margin: 0;

  display: -webkit-box;
  display: -webkit-flex;
  display: -moz-box;
  display: -ms-flexbox;
  display: flex;
  align-items: center;
}

.main-menu > li {
  display: block;
  position: relative;
  padding: 20px 10px 20px 0px;
  margin: 0px 4px 0px 14px;
}

.main-menu > li > a {
  font-family: 'Roboto Condensed', sans-serif;;
  font-size: 14px;
  color: #333;
  padding: 5px 0px;
  transition: all 0.4s;
  -webkit-transition: all 0.4s;
  -o-transition: all 0.4s;
  -moz-transition: all 0.4s;
}

.header-v3 .main-menu > li > a {
  color: #fff;
}

/*---------------------------------------------*/
.sub-menu {
  list-style-type: none;
  position: absolute;
  top:0;
  left:100%;
  min-width: 178px;
  max-width: 225px;
  background-color: #fff;
  transition: all 0.4s;
  -webkit-transition: all 0.4s;
  -o-transition: all 0.4s;
  -moz-transition: all 0.4s;
  padding: 5px 0;

  box-shadow: 0 1px 5px 0px rgba(0,0,0,0.2);
  -moz-box-shadow: 0 1px 5px 0px rgba(0,0,0,0.2);
  -webkit-box-shadow: 0 1px 5px 0px rgba(0,0,0,0.2);
  -o-box-shadow: 0 1px 5px 0px rgba(0,0,0,0.2);
  -ms-box-shadow: 0 1px 5px 0px rgba(0,0,0,0.2);

  visibility: hidden;
  opacity: 0; 
}

.sub-menu li {
  position: relative;
  background-color: transparent;

  transition: all 0.4s;
  -webkit-transition: all 0.4s;
  -o-transition: all 0.4s;
  -moz-transition: all 0.4s;
}

.main-menu > li > .sub-menu {
  top:100%;
  left: 0;
}

.sub-menu a {
  font-family: 'Roboto Condensed', sans-serif;;
  font-size: 14px;
  line-height: 1.5;
  color: #555;

  display: block;
  padding: 8px 20px; 
  width: 100%;

  transition: all 0.4s;
  -webkit-transition: all 0.4s;
  -o-transition: all 0.4s;
  -moz-transition: all 0.4s;
}

/*---------------------------------------------*/
.main-menu > li:hover > a {
  text-decoration: none;
  color: #6c7ae0;
}

.main-menu > li:hover > .sub-menu {
  visibility: visible;
  opacity: 1;
}

.sub-menu li:hover > .sub-menu {
  visibility: visible;
  opacity: 1;
} 

.sub-menu li:hover {
  background-color: transparent;
}

.sub-menu > li:hover > a {
  color: #6c7ae0;
  text-decoration: none;
}

@media (max-width: 1300px) {
  .main-menu > .respon-sub-menu .sub-menu {
    right: 100%;
    left: auto;
  }

  .main-menu > .respon-sub-menu > .sub-menu {
    right: 0px;
    left: auto;
  }
}

/*------------------------------------------------------------------
[ Icon header ]*/

.wrap-icon-header {
  flex-grow: 1;
}

.icon-header-item {
  position: relative;
  font-size: 26px;
  line-height: 1;
  cursor: pointer;
}


/*---------------------------------------------*/
.icon-header-noti::after {
  content: attr(data-notify);
  font-family: 'Roboto Condensed', sans-serif;;
  font-size: 12px;
  color: #fff;
  line-height: 15px;
  text-align: center;

  display: block;
  position: absolute;
  top: -7px;
  right: 0;
  min-width: 15px;
  height: 15px;
  padding: 0 3px;
  background-color: #717fe0;
}

/*---------------------------------------------*/
.wrap-header-mobile .wrap-icon-header {
  flex-grow: unset;
}


/*------------------------------------------------------------------
[ Modal search ]*/
.modal-search-header {
  position: fixed;
  z-index: 2000;
  width: 100%;
  height: 100%;
  bottom: 101%;
  left: 0;
  opacity: 0;
  visibility: hidden;
  background-color: rgba(255,255,255,0.9);
  padding: 50px 15px 100px 15px;
}

.show-modal-search {
  bottom: 0;
  opacity: 1;
  visibility: visible;
}

.container-search-header {
  width: auto;
  max-width: 100%;
  position: relative;
}

/*---------------------------------------------*/
.btn-hide-modal-search {
  position: absolute;
  padding: 5px;
  right: 0;
  top: -45px;
  opacity: 0.8;
}

.btn-hide-modal-search:hover {
  opacity: 1;
}

.wrap-search-header {
  width: 960px;
  max-width: 100%;
  height: 120px;
  border: 2px solid #e6e6e6;
  background: #fff;
}

/*---------------------------------------------*/
.wrap-search-header input {
  font-family: 'Roboto Condensed', sans-serif;;
  font-size: 50px;
  line-height: 1.2;
  color: #333;
  
  padding: 0px 30px 0px 0px;
  width: calc(100% - 70px);
  height: 100%;
  background-color: transparent;
}

.wrap-search-header button {
  font-size: 50px;
  color: #333;
  width: 70px;
  height: 100%;
}

.wrap-search-header button:hover {
  color: #6c7ae0;
}

/*---------------------------------------------*/
@media (max-width: 767px) {
  .wrap-search-header input,
  .wrap-search-header button {
    font-size: 30px;
  }

  .wrap-search-header {
    height: 90px;
  }
}

@media (max-width: 575px) {
  .wrap-search-header input,
  .wrap-search-header button {
    font-size: 20px;
  }

  .wrap-search-header button {
    width: 40px;
  }

  .wrap-search-header {
    height: 80px;
  }
}


/*==================================================================
[ Fixed menu desktop ]*/

.fix-menu-desktop .wrap-menu-desktop {
  height: 70px;
  background-color: rgba(255,255,255,1);
  box-shadow: 0 0px 3px 0px rgba(0,0,0,0.2);
  -moz-box-shadow: 0 0px 3px 0px rgba(0,0,0,0.2);
  -webkit-box-shadow: 0 0px 3px 0px rgba(0,0,0,0.2);
  -o-box-shadow: 0 0px 3px 0px rgba(0,0,0,0.2);
  -ms-box-shadow: 0 0px 3px 0px rgba(0,0,0,0.2);
}

.header-v2 .fix-menu-desktop.container-menu-desktop {
  height: 70px;
}

.header-v3 .fix-menu-desktop .wrap-menu-desktop {
  background-color: #222;
  border-color: #222;
}

.header-v4 .fix-menu-desktop.container-menu-desktop {
  height: 110px;
}

/*---------------------------------------------*/
.main-menu > li.active-menu > a {
  color: #6c7ae0;
}



/*>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
[ Header Mobile ]*/
.wrap-header-mobile {
  display: -webkit-box;
  display: -webkit-flex;
  display: -moz-box;
  display: -ms-flexbox;
  display: flex;
  align-items: center;
  height: 70px;
  background-color: #fff;
  padding: 15px;
  display: none;

  box-shadow: 0 0px 3px 0px rgba(0,0,0,0.2);
  -moz-box-shadow: 0 0px 3px 0px rgba(0,0,0,0.2);
  -webkit-box-shadow: 0 0px 3px 0px rgba(0,0,0,0.2);
  -o-box-shadow: 0 0px 3px 0px rgba(0,0,0,0.2);
  -ms-box-shadow: 0 0px 3px 0px rgba(0,0,0,0.2);
}

/*------------------------------------------------------------------
[ Logo mobile ]*/
.logo-mobile {
  display: block;
  position: relative;
  height: 80%;
  padding-right: 25px;
  -webkit-flex-grow: 1;
  -moz-flex-grow: 1;
  flex-grow: 1;
}

.logo-mobile img {
  max-width: calc(100% - 20px);
  max-height: 100%;
  position:absolute;
  top: 0; 
  left: 0; 
  bottom: 0;
  margin: auto;
}



/*------------------------------------------------------------------
[ btn show menu ]*/
.hamburger {
  display: -webkit-box;
  display: -webkit-flex;
  display: -moz-box;
  display: -ms-flexbox;
  display: flex;
  align-items: center;
  padding: 0;
  -webkit-transform: scale(0.7);
  -moz-transform: scale(0.7);
  -ms-transform: scale(0.7);
  -o-transform: scale(0.7);
  transform: scale(0.7);
}

.hamburger:hover {
  opacity: 1;
}

/*---------------------------------------------*/
@media (max-width: 991px){
  .wrap-header-mobile {
    display: -webkit-box;
    display: -webkit-flex;
    display: -moz-box;
    display: -ms-flexbox;
    display: flex;
  }
  .container-menu-desktop {display: none;}
}

/*==================================================================
[ Menu mobile ]*/
.menu-mobile {
  width: 100%;
  background-color: white;
  display: none;
}

.main-menu-m {
  padding-top: 10px;
  padding-bottom: 10px;
  background-color: #717fe0;
}

.main-menu-m > li > a {
  font-family: 'Roboto Condensed', sans-serif;;
  font-size: 14px;
  color: white;
  line-height: 2.8;
  padding: 8px 20px 8px 20px;
}

.main-menu-m > li {
  color: white;
  position: relative;
}

.arrow-main-menu-m {
  font-size: 14px;
  color: #fff;

  display: -webkit-box;
  display: -webkit-flex;
  display: -moz-box;
  display: -ms-flexbox;
  display: flex;
  justify-content: center;
  align-items: center;
  position: absolute;
  right: 10px;
  top: 2px;
  padding: 10px;
  cursor: pointer;
}

.arrow-main-menu-m i {
  transform-origin: center;
  -webkit-transition: all 0.3s;
  -o-transition: all 0.3s;
  -moz-transition: all 0.3s;
  transition: all 0.3s;
}

.turn-arrow-main-menu-m i {
  -webkit-transform: rotate(90deg);
  -moz-transform: rotate(90deg);
  -ms-transform: rotate(90deg);
  -o-transform: rotate(90deg);
  transform: rotate(90deg);
}

/*---------------------------------------------*/
.sub-menu-m {
  background-color: #fff;
  padding: 10px 15px 10px 32px;
  display: none;
}

.sub-menu-m a {
  font-family: 'Roboto Condensed', sans-serif;;
  font-size: 14px;
  color: #666;
  line-height: 2.5;
  padding: 5px 0 5px 0;
}

.sub-menu-m a:hover {
  text-decoration: none;
  color: #555555;
}

@media (min-width: 992px){
  .menu-mobile {
    display: none;
  }
}


/*//////////////////////////////////////////////////////////////////
[ Sidebar ]*/
.wrap-sidebar {
  position: fixed;
  z-index: 1100;
  width: 100%;
  height: 100vh;
  top: 0;
  right: 0;
  background-color: rgba(0,0,0,0.0);
  visibility: hidden;
  
  -webkit-transition: all 0.4s;
  -o-transition: all 0.4s;
  -moz-transition: all 0.4s;  
  transition: all 0.4s;
}

.sidebar {
  position: fixed;
  z-index: 1100;
  width: 390px;
  max-width: calc(100% - 30px);
  height: 100vh;
  top: 0;
  right: -400px;
  background-color: #fff;
  
  -webkit-transition: all 0.4s;
  -o-transition: all 0.4s;
  -moz-transition: all 0.34;  
  transition: all 0.4s;

  box-shadow: 0 3px 6px 0px rgba(0, 0, 0, 0.18);
  -moz-box-shadow: 0 3px 6px 0px rgba(0, 0, 0, 0.18);
  -webkit-box-shadow: 0 3px 6px 0px rgba(0, 0, 0, 0.18);
  -o-box-shadow: 0 3px 6px 0px rgba(0, 0, 0, 0.18);
  -ms-box-shadow: 0 3px 6px 0px rgba(0, 0, 0, 0.18);
}

.show-sidebar {
  visibility: visible;
  background-color: rgba(0,0,0,0.6);
}

.show-sidebar .sidebar {
  right: 0;
}

@media (max-width: 991px) {
  .wrap-sidebar {
    display: none;
  }
}

/*---------------------------------------------*/
.sidebar-content {
  flex-grow: 1;
  overflow: auto;
  align-content: space-between;
}

/*---------------------------------------------*/
.wrap-item-gallery {
  width: calc((100% - 20px) / 3);
}

.item-gallery {
  display: block;
  width: 100%;
  padding-top: 100%;
  position: relative;
}

.item-gallery::after {
  content: "";
  display: block;
  position: absolute;
  width: 100%;
  height: 100%;
  top: 0;
  left: 0;
  background-color: rgba(103,117,214,0.8);
  opacity: 0;

  -webkit-transition: all 0.4s;
  -o-transition: all 0.4s;
  -moz-transition: all 0.34;  
  transition: all 0.4s;
}

.item-gallery:hover:after {
  opacity: 1;
}


/*//////////////////////////////////////////////////////////////////
[ Header cart ]*/
.wrap-header-cart {
  position: fixed;
  z-index: 1100;
  width: 100%;
  height: 100vh;
  top: 0;
  right: 0;
  background-color: rgba(0,0,0,0.0);
  visibility: hidden;
  
  -webkit-transition: all 0.4s;
  -o-transition: all 0.4s;
  -moz-transition: all 0.4s;  
  transition: all 0.4s;
}

.header-cart {
  position: fixed;
  z-index: 1100;
  width: 390px;
  max-width: calc(100% - 30px);
  height: 100vh;
  top: 0;
  right: -400px;
  background-color: #fff;
  
  -webkit-transition: all 0.4s;
  -o-transition: all 0.4s;
  -moz-transition: all 0.34;  
  transition: all 0.4s;

  box-shadow: 0 3px 6px 0px rgba(0, 0, 0, 0.18);
  -moz-box-shadow: 0 3px 6px 0px rgba(0, 0, 0, 0.18);
  -webkit-box-shadow: 0 3px 6px 0px rgba(0, 0, 0, 0.18);
  -o-box-shadow: 0 3px 6px 0px rgba(0, 0, 0, 0.18);
  -ms-box-shadow: 0 3px 6px 0px rgba(0, 0, 0, 0.18);
}

.header-cart::after {
  content: "";
  display: block;
  width: 100%;
  height: 9%;
  min-height: 30px;
}

.show-header-cart {
  visibility: visible;
  background-color: rgba(0,0,0,0.6);
}

.show-header-cart .header-cart {
  right: 0;
}

/*---------------------------------------------*/
.header-cart-title {
  width: 260px;
  max-width: 100%;
  height: 16.5%;
  min-height: 85px;
}

.header-cart-content {
  flex-grow: 1;
  overflow: auto;
  align-content: space-between;
}

.header-cart-wrapitem {
  flex-grow: 1;
}

/*---------------------------------------------*/
.header-cart-item-img {
  width: 60px;
  position: relative;
  margin-right: 20px;
  cursor: pointer;
}

.header-cart-item-img img {
  width: 100%;
}

.header-cart-item-img::after {
  content: '\e870';
  font-family: Linearicons-Free;
  font-size: 16px;
  display: -webkit-box;
  display: -webkit-flex;
  display: -moz-box;
  display: -ms-flexbox;
  display: flex;
  justify-content: center;
  align-items: center;
  position: absolute;
  width: 100%;
  height: 100%;
  top: 0;
  left: 0;
  background-color: rgba(0,0,0,0.5);
  color: #fff;
  transition: all 0.3s;
  -webkit-transition: all 0.3s;
  -o-transition: all 0.3s;
  -moz-transition: all 0.3s;
  opacity: 0;
}

.header-cart-item-img:hover:after {
  opacity: 1;
}

/*---------------------------------------------*/
.header-cart-item-txt {
  width: calc(100% - 80px);
}

.header-cart-item-name {
  display: block;
  font-family: 'Roboto Condensed', sans-serif;;
  font-size: 14px;
  color: #555;
  line-height: 1.3;
}

.header-cart-item-info {
  display: block;
  font-family: 'Roboto Condensed', sans-serif;;
  font-size: 14px;
  color: #888;
  line-height: 1.5;
}

.header-cart-total {
  font-family: 'Roboto Condensed', sans-serif;;
  font-size: 18px;
  color: #222;
  line-height: 1.3;
}

/*---------------------------------------------*/
@media (max-width: 575px) {
  .header-cart {
    padding: 30px;
  }

  .header-cart-title {
    padding-bottom: 35px;
  }
}


/*//////////////////////////////////////////////////////////////////
[ Restyle Select2 ]*/

.rs1-select2 .select2-container {
  display: block;
  max-width: 100% !important;
  width: auto !important;
}

.rs1-select2 .select2-container .select2-selection--single {
  height: 45px;
  display: -webkit-box;
  display: -webkit-flex;
  display: -moz-box;
  display: -ms-flexbox;
  display: flex;
  align-items: center;
  border: none;
  outline: none;
  background-color: transparent;
  border-radius: 0px;
  position: relative;
}

/*------------------------------------------------------------------
[ in select ]*/
.rs1-select2 .select2-container .select2-selection--single .select2-selection__rendered {
  font-family: 'Roboto Condensed', sans-serif;;
  font-size: 13px;
  color: #555;
  line-height: 1.2;
  padding-left: 20px;
  background-color: transparent;
}

.rs1-select2 .select2-container--default .select2-selection--single .select2-selection__arrow {
  width: 38px;
  height: 20px;
  top: calc(50% - 10px);
  right: 5px;
  display: -webkit-box;
  display: -webkit-flex;
  display: -moz-box;
  display: -ms-flexbox;
  display: flex;
  align-items: center;
  justify-content: center;
  border-left: 1px solid #e6e6e6;
}

.rs1-select2 .select2-container--default .select2-selection--single .select2-selection__arrow b {
  display: none;
}

.rs1-select2 .select2-container--default .select2-selection--single .select2-selection__arrow::after {
  content: "\f0dc";
  font-family: FontAwesome;
  font-size: 13px;
  color: #808080;
}

.rs1-select2 .select2-container--default .select2-selection--single .select2-selection__arrow:hover:after {
  color: #6c7ae0;
}


/*------------------------------------------------------------------
[ Dropdown option ]*/
.rs1-select2 .select2-container--open .select2-dropdown {
  z-index: 1251;
  width: 100%;
  border: 1px solid #fff;
  border-radius: 0px;
  overflow: hidden;
  background-color: white;
  left: 0px;

  box-shadow: 0 3px 10px 0px rgba(0, 0, 0, 0.2);
  -moz-box-shadow: 0 3px 10px 0px rgba(0, 0, 0, 0.2);
  -webkit-box-shadow: 0 3px 10px 0px rgba(0, 0, 0, 0.2);
  -o-box-shadow: 0 3px 10px 0px rgba(0, 0, 0, 0.2);
  -ms-box-shadow: 0 3px 10px 0px rgba(0, 0, 0, 0.2);
}

.rs1-select2 .select2-dropdown--above {top: -2px;}
.rs1-select2 .select2-dropdown--below {top: 2px;}

.rs1-select2 .select2-container .select2-results__option[aria-selected] {
  padding-top: 10px;
  padding-bottom: 10px;
  padding-left: 20px;
}

.rs1-select2 .select2-container .select2-results__option[aria-selected="true"] {
  background: #6c7ae0;
  color: white;
}

.rs1-select2 .select2-container .select2-results__option--highlighted[aria-selected] {
  background: #6c7ae0;
  color: white;
}

.rs1-select2 .select2-results__options {
  font-family: 'Roboto Condensed', sans-serif;;
  font-size: 13px;
  color: #555;
  line-height: 1.2;
}

.rs1-select2 .select2-search--dropdown .select2-search__field {
  border: 1px solid #aaa;
  outline: none;
  font-family: 'Roboto Condensed', sans-serif;;
  font-size: 13px;
  color: #555;
  line-height: 1.2;
}

/*------------------------------------------------------------------
[ rs2 ]*/
.rs2-select2 .select2-container .select2-selection--single {
  height: 40px;
}

.rs2-select2 .select2-container .select2-selection--single .select2-selection__rendered {
  padding-left: 15px;
}

.rs2-select2 .select2-container--default .select2-selection--single .select2-selection__arrow {
  width: 35px;
  right: 0px;
  border-left: none;
}

.rs2-select2 .select2-container--default .select2-selection--single .select2-selection__arrow::after {
  content: "\f0d7";
}



/*//////////////////////////////////////////////////////////////////
[ Slick1 ]*/
.wrap-slick1 {
  position: relative;
}

.item-slick1 {
  height: calc(100vh - 40px);
  background-size: cover;
  background-repeat: no-repeat;
  background-position: center center;
}

.rs1-slick1 .item-slick1 {
  height: calc(100vh - 84px);
}

.rs2-slick1 .item-slick1 {
  height: 100vh;
}

@media (max-width: 991px) {
  .item-slick1 {
    height: calc(100vh - 70px) !important;
  }
}

.arrow-slick1 {
  display: -webkit-box;
  display: -webkit-flex;
  display: -moz-box;
  display: -ms-flexbox;
  display: flex;
  justify-content: center;
  align-items: center;
  width: auto;
  height: auto;
  font-size: 80px;
  color: rgba(0,0,0,0.3);
  position: absolute;
  opacity: 0;
  
  top: 50%;
  -webkit-transform: translateY(-50%);
  -moz-transform: translateY(-50%);
  -ms-transform: translateY(-50%);
  -o-transform: translateY(-50%);
  transform: translateY(-50%);

  z-index: 200;
  -webkit-transition: all 0.4s;
  -o-transition: all 0.4s;
  -moz-transition: all 0.4s;
  transition: all 0.4s;
}

.wrap-slick1:hover .arrow-slick1 {
  opacity: 1;
}

.arrow-slick1:hover {
  color: #7280e0;
}

.next-slick1 {
  right: 50px;
  left: auto;
}

.prev-slick1 {
  left: 50px;
  right: auto;
}

@media (max-width: 991px) {
  .next-slick1 {
    right: 15px;
  }

  .prev-slick1 {
    left: 15px;
  }
}

/*---------------------------------------------*/
.rs2-slick1 .arrow-slick1 {
  color: rgba(255,255,255,0.3);
}

.rs2-slick1 .arrow-slick1:hover {
  color: #7280e0;
}

.wrap-slick1-dots {
  position: absolute;
  width: 100%;
  left: 0;
  bottom: 60px;
}

.slick1-dots {
  display: -webkit-box;
  display: -webkit-flex;
  display: -moz-box;
  display: -ms-flexbox;
  display: flex;
  justify-content: center;
}

.slick1-dots li {
  max-width: 190px;
  position: relative;
  cursor: pointer;
  margin-right: 1px;
}

.slick1-dots li img {
  width: 100%;
}

.caption-dots-slick1 {
  font-family: 'Roboto Condensed', sans-serif;;
  font-size: 16px;
  line-height: 1.3;
  color: #fff;
  text-align: center;

  display: -webkit-box;
  display: -webkit-flex;
  display: -moz-box;
  display: -ms-flexbox;
  display: flex;
  justify-content: center;
  align-items: center;

  position: absolute;
  width: 100%;
  height: 100%;
  top: 0;
  left: 0;
  background-color: rgba(0,0,0,0.5);
  padding: 5px;

  -webkit-transition: all 0.4s;
  -o-transition: all 0.4s;
  -moz-transition: all 0.4s;
  transition: all 0.4s;
  opacity: 0;
}

.slick1-dots li:hover .caption-dots-slick1 {
  opacity: 1;
}

.slick1-dots li.slick-active .caption-dots-slick1 {
  opacity: 1;
}

@media (max-width: 575px) {
  .caption-dots-slick1 {
    font-size: 13px;
  }

  .wrap-slick1-dots {
    bottom: 25px;
  }
}


/*//////////////////////////////////////////////////////////////////
[ Slick2 ]*/

.wrap-slick2 {
  position: relative;
  margin-right: -15px;
  margin-left: -15px;
}

/* ------------------------------------ */
.arrow-slick2 {
  position: absolute;
  z-index: 100;
  top: calc((100% - 60px) / 2);
  -webkit-transform: translateY(-50%);
  -moz-transform: translateY(-50%);
  -ms-transform: translateY(-50%);
  -o-transform: translateY(-50%);
  transform: translateY(-50%);
  font-size: 39px;
  color: #ccc;

  -webkit-transition: all 0.4s;
  -o-transition: all 0.4s;
  -moz-transition: all 0.4s;
  transition: all 0.4s;
}

.arrow-slick2:hover {
  color: #666;
}

.next-slick2 {
  right: -40px;
}

.prev-slick2 {
  left: -40px;
}

@media (max-width: 1300px) {
  .next-slick2 {
    right: 0px;
  }

  .prev-slick2 {
    left: 0px;
  }
}


/*//////////////////////////////////////////////////////////////////
[ Slick3 ]*/
.wrap-slick3 {
  position: relative;
}

/*---------------------------------------------*/
.wrap-slick3-arrows {
  position: absolute;
  z-index: 100;
  width: 83.333333%;
  right: 0;
  top: calc(50% - 20px);
}

.arrow-slick3 {
  font-size: 25px;
  color: #fff;
  
  position: absolute;
  top: 0;
  width: 40px;
  height: 40px;
  background-color: rgba(0,0,0,0.5);

  -webkit-transition: all 0.4s;
  -o-transition: all 0.4s;
  -moz-transition: all 0.4s;
  transition: all 0.4s;
}

.arrow-slick3:hover {
  background-color: rgba(0,0,0,0.9);
}

.prev-slick3 {left: 0px;}
.next-slick3 {right: 0px;}

/*---------------------------------------------*/
.wrap-slick3-dots {
  width: 11.111111%;
}

.slick3 {
  width: 83.333333%;
}

.slick3-dots li {
  display: block;
  position: relative;
  width: 100%;
  margin-bottom: 27px;
}

.slick3-dots li img {
  width: 100%;
}

.slick3-dot-overlay {
  position: absolute;
  width: 100%;
  height: 100%;
  top: 0;
  left: 0;
  cursor: pointer;
  border: 2px solid transparent;
  -webkit-transition: all 0.4s;
  -o-transition: all 0.4s;
  -moz-transition: all 0.4s;
  transition: all 0.4s;
}

.slick3-dot-overlay:hover {
  border-color: #ccc;
}

.slick3-dots .slick-active .slick3-dot-overlay {
  border-color: #ccc;
}



/*//////////////////////////////////////////////////////////////////
[ RS Magnific-Popup ]*/
.mfp-bg {
  z-index: 10000;
  background-color: #000;
  opacity: 0.9;
}

.mfp-wrap {
  z-index: 10000;
}

.mfp-arrow:after,
.mfp-arrow:before {
  display: none;
}

.mfp-arrow {
  -webkit-transition: all 0.4s;
  -o-transition: all 0.4s;
  -moz-transition: all 0.4s;
  transition: all 0.4s;
}

button.mfp-arrow-right {
  background-image: url(../images/icons/icon-next.png);
  background-position: center center;
  background-repeat: no-repeat;
}

button.mfp-arrow-left {
  background-image: url(../images/icons/icon-prev.png);
  background-position: center center;
  background-repeat: no-repeat;
}

button.mfp-close {
  width: 75px !important;
  height: 58px !important;
  line-height: 44px;
  position: fixed;
  right: 0;
  top: 0;
  color: transparent !important;
  background-image: url(../images/icons/icon-close.png);
  background-position: center center;
  background-repeat: no-repeat;
  cursor: pointer !important;
  -webkit-transition: all 0.4s;
  -o-transition: all 0.4s;
  -moz-transition: all 0.4s;
  transition: all 0.4s;
}

/* overlay at start */
.mfp-fade.mfp-bg {
  opacity: 0;

  -webkit-transition: all 0.3s ease-out;
  -moz-transition: all 0.3s ease-out;
  transition: all 0.3s ease-out;
}
/* overlay animate in */
.mfp-fade.mfp-bg.mfp-ready {
  opacity: 0.9;
}
/* overlay animate out */
.mfp-fade.mfp-bg.mfp-removing {
  opacity: 0;
}

/* content at start */
.mfp-fade.mfp-wrap .mfp-content {
  opacity: 0;

  -webkit-transition: all 0.3s ease-out;
  -moz-transition: all 0.3s ease-out;
  transition: all 0.3s ease-out;
}
/* content animate it */
.mfp-fade.mfp-wrap.mfp-ready .mfp-content {
  opacity: 1;
}
/* content animate out */
.mfp-fade.mfp-wrap.mfp-removing .mfp-content {
  opacity: 0;
}


/*//////////////////////////////////////////////////////////////////
[ Tab01 ]*/
.tab01 .nav-tabs {
  display: -webkit-box;
  display: -webkit-flex;
  display: -moz-box;
  display: -ms-flexbox;
  display: flex;
  flex-wrap: wrap;
  justify-content: center;
  align-items: center;
  border: none;
}

.tab01 .nav-tabs .nav-item {
  margin: 0px 15px;
}

.tab01 .nav-link {
  font-family: 'Roboto Condensed', sans-serif;;
  font-size: 15px;
  color: #888;
  line-height: 1.2;

  padding: 0;
  border-radius: 0px;
  border: none;
  border-bottom: 1px solid transparent;

  -webkit-transition: all 0.4s;
  -o-transition: all 0.4s;
  -moz-transition: all 0.4s;
  transition: all 0.4s;
}

.tab01 .nav-link.active {
  color: #333;
  border-color: #797979;
}

.tab01 .nav-link:hover {
  color: #333;
  border-color: #797979;
}



/*//////////////////////////////////////////////////////////////////
[ RS sweet alert ]*/
.swal-overlay {overflow-y: auto;}

.swal-button:focus {
    outline: none;
    box-shadow: none;
}

.swal-button {
  background-color: #717fe0;
  font-family: 'Roboto Condensed', sans-serif;;
  font-size: 16px;
  color: white;
  text-transform: uppercase;
  font-weight: unset;
  border-radius: 4px;
  -webkit-transition: all 0.3s;
  -o-transition: all 0.3s;
  -moz-transition: all 0.3s;
  transition: all 0.3s;
}

.swal-button:hover {
  background-color: #333;
}

.swal-button:active {
  background-color: #333;
}

.swal-title {
  font-family: 'Roboto Condensed', sans-serif;;
  color: #333333;
  font-size: 18px;
  line-height: 1.5;
  padding: 0 15px;
}

.swal-text {
  font-family: 'Roboto Condensed', sans-serif;;
  color: #555555;
  font-size: 16px;
  line-height: 1.666667;
  text-align: center;
}

.swal-footer {
    margin-top: 0;
}


/*//////////////////////////////////////////////////////////////////
[ Filter ]*/
.show-search .icon-search,
.show-filter .icon-filter {display: none;}

.show-search .icon-close-search,
.show-filter .icon-close-filter {display: unset;}

.show-search,
.show-filter {
  background-color: #f2f2f2;
  border-color: #e7e7e7;
  position: relative;
}

.show-search::after,
.show-filter::after {
  content: "";
  position: absolute;
  display: block;

  width: 14px;
  height: 14px;
  background-color: #f2f2f2;
  border-left: 1px solid #e7e7e7;
  border-bottom: 1px solid #e7e7e7;
  
  transform-origin: center center;
  -webkit-transform: rotate(-45deg);
  -moz-transform: rotate(-45deg);
  -ms-transform: rotate(-45deg);
  -o-transform: rotate(-45deg);
  transform: rotate(-45deg);

  left: calc(50% - 7px);
  bottom: -8px;

  -webkit-transition: all 0.4s;
  -o-transition: all 0.4s;
  -moz-transition: all 0.4s;
  transition: all 0.4s;
}

.show-search:hover:after,
.show-filter:hover:after {
  background-color: #717fe0;
  border-color: #717fe0;
}

/*---------------------------------------------*/
.filter-col1 {width: 27%;}
.filter-col2 {width: 27%;}
.filter-col3 {width: 26%;}
.filter-col4 {width: 20%;}

/*---------------------------------------------*/
.filter-link {
  color: #aaa;
  border-bottom: 1px solid transparent;
}

.filter-link:hover {
  color: #6c7ae0;
  border-bottom: 1px solid #6c7ae0;
}

.filter-link-active {
  color: #6c7ae0;
  border-bottom: 1px solid #6c7ae0;
}

@media (max-width: 767px) {
  .filter-col1,
  .filter-col2,
  .filter-col3,
  .filter-col4 {width: 50%;}
}

@media (max-width: 575px) {
  .filter-col1,
  .filter-col2,
  .filter-col3,
  .filter-col4 {width: 100%;}
}



/*//////////////////////////////////////////////////////////////////
[ Num Product ]*/
.wrap-num-product {
  width: 140px;
  height: 45px;
  border: 1px solid #e6e6e6;
  border-radius: 3px;
  overflow: hidden;
}

.btn-num-product-up,
.btn-num-product-down {
  width: 45px;
  height: 100%;
  cursor: pointer;
}

.num-product {
  width: calc(100% - 90px);
  height: 100%;
  border-left: 1px solid #e6e6e6;
  border-right: 1px solid #e6e6e6;
  background-color: #f7f7f7;
}

input.num-product {
  -moz-appearance: textfield;
  appearance: none;
  -webkit-appearance: none;
}

input.num-product::-webkit-outer-spin-button,
input.num-product::-webkit-inner-spin-button {
  -webkit-appearance: none;
  margin: 0; 
}

/*//////////////////////////////////////////////////////////////////
[ Tolltip100 ]*/
.tooltip100 {
  position: relative;
}

.tooltip100::after {
  content: attr(data-tooltip);
  font-family: 'Roboto Condensed', sans-serif;;
  font-size: 12px;
  color: #888;
  line-height: 18px;
  white-space: nowrap;

  display: block;
  position: absolute;
  background: #fff;
  border: 1px solid #ccc;
  height: 20px;
  padding: 0px 8px;
  top: -35px;
  left: 50%;
  -webkit-transform: translateX(-50%);
  -moz-transform: translateX(-50%);
  -ms-transform: translateX(-50%);
  -o-transform: translateX(-50%);
  transform: translateX(-50%);

  box-shadow: 0 3px 6px 0px rgba(0,0,0,0.18);
  -moz-box-shadow: 0 3px 6px 0px rgba(0,0,0,0.18);
  -webkit-box-shadow: 0 3px 6px 0px rgba(0,0,0,0.18);
  -o-box-shadow: 0 3px 6px 0px rgba(0,0,0,0.18);
  -ms-box-shadow: 0 3px 6px 0px rgba(0,0,0,0.18);

  -webkit-transition: all 0.2s;
  -o-transition: all 0.2s;
  -moz-transition: all 0.2s;
  transition: all 0.2s;
  
  visibility: hidden;
  opacity: 0;
}

.tooltip100:hover:after {
  visibility: visible;
  opacity: 1;
}


/*//////////////////////////////////////////////////////////////////
[ Modal1 ]*/
.wrap-modal1 {
  position: fixed;
  width: 100%;
  height: 100vh;
  top: 0;
  left: 0;
  z-index: 9000;
  overflow: auto;

  -webkit-transition: all 0.4s;
  -o-transition: all 0.4s;
  -moz-transition: all 0.4s;
  transition: all 0.4s;

  visibility: hidden;
  opacity: 0;
}

.overlay-modal1 {
  position: fixed;
  z-index: -1;
  width: 100%;
  height: 100%;
  top: 0;
  left: 0;
  background: #000;
  opacity: 0.8;
}

.show-modal1 {
  visibility: visible;
  opacity: 1;
}

/*//////////////////////////////////////////////////////////////////
[ Table Shopping Cart ]*/

.wrap-table-shopping-cart {
  overflow: auto;
  border-left: 1px solid #e6e6e6;
  border-right: 1px solid #e6e6e6;
}

.wrap-table-search-bar {
  overflow: auto;
  border-left: 1px solid #d3d3d3;
  border-right: 1px solid #d3d3d3;
  border-bottom: 1px solid #d3d3d3;
  background: #fff;
}

.table-shopping-cart {
  border-collapse: collapse;
  width: 100%;
  min-width: 680px;
}

.table-shopping-cart tr {
  border-top: 1px solid #e6e6e6;
  border-bottom: 1px solid #e6e6e6;
}

.table-shopping-cart .column-1 {
  width: 133px;
  padding-left: 50px;
}

.table-shopping-cart .column-2 {
  width: 220px;
  font-size: 15px;
}

.table-shopping-cart .column-3 {
  width: 120px;
  font-size: 16px;
}

.table-shopping-cart .column-4 {
  width: 145px;
  text-align: right;
}

.table-shopping-cart .column-5 {
  width: 172px;
  padding-right: 50px;
  text-align: right;
  font-size: 16px;
}

.table-shopping-cart .table_row {
  height: 185px;
}

.table-shopping-cart .table_row td {
  padding-bottom: 20px;
}

.table-shopping-cart .table_row td.column-1 {
  padding-bottom: 30px;
}

.table-shopping-cart .table_head th {
  font-family: 'Roboto Condensed', sans-serif;;
  font-size: 13px;
  color: #555;
  text-transform: uppercase;
  line-height: 1.6;
  padding-top: 15px;
  padding-bottom: 15px;
}

.table-shopping-cart td {
  font-family: 'Roboto Condensed', sans-serif;;
  color: #555;
  line-height: 1.6;
}


/*///*/
.table-search-bar {
  border-collapse: collapse;
  width: 100%;
  min-width: 680px;
}

.table-search-bar tr {
  /* border-top: 1px solid #e6e6e6; */
  /* border-bottom: 1px solid #e6e6e6; */
}

.table-search-bar .column-1 {
  width: 133px;
  padding-left: 10px !important;
}

.table-search-bar .column-2 {
  width: 220px;
  font-size: 15px;
}

.table-search-bar .column-3 {
  width: 120px;
  font-size: 16px;
}

.table-search-bar .column-4 {
  width: 145px;
  text-align: right;
}

.table-search-bar .column-5 {
  width: 172px;
  padding-right: 50px;
  text-align: right;
  font-size: 16px;
}

.table-search-bar .table_row {
  /* height: 185px; */
}

.table-search-bar .table_row td {
  padding-bottom: 20px;
  padding: 10px;
}

.table-search-bar .table_row td.column-1 {
  padding-bottom: 10px;
}

.table-search-bar .table_head th {
  font-family: 'Roboto Condensed', sans-serif;;
  font-size: 13px;
  color: #555;
  text-transform: uppercase;
  line-height: 1.6;
  padding-top: 15px;
  padding-bottom: 15px;
}

.table-search-bar td {
  font-family: 'Roboto Condensed', sans-serif;;
  color: #555;
  line-height: 1.6;
}


/*//////////////////////////////////////////////////////////////////
[ Block1 ]*/
.block1 {
  position: relative;
  border: 1px solid #e6e6e6;
}

.block1-txt {
  background-color: rgba(103,117,214,0.0);
}

/*---------------------------------------------*/
.block1-name {color: #333;}
.block1-info {color: #555;}

/*---------------------------------------------*/
.block1-txt-child2 {
  border-bottom: 2px solid #fff;
  overflow: hidden;
  -webkit-transform: scaleX(0);
  -moz-transform: scaleX(0);
  -ms-transform: scaleX(0);
  -o-transform: scaleX(0);
  transform: scaleX(0);
}

.block1-link {
  -webkit-transform: translateY(250%);
  -moz-transform: translateY(250%);
  -ms-transform: translateY(250%);
  -o-transform: translateY(250%);
  transform: translateY(250%);
}

/*---------------------------------------------*/
.block1-txt:hover {
  background-color: rgba(103,117,214,0.8);
}

.block1-txt:hover .block1-txt-child2 {
  -webkit-transform: scaleX(1);
  -moz-transform: scaleX(1);
  -ms-transform: scaleX(1);
  -o-transform: scaleX(1);
  transform: scaleX(1);
}

.block1-txt:hover .block1-link {
  -webkit-transform: translateY(0%);
  -moz-transform: translateY(0%);
  -ms-transform: translateY(0%);
  -o-transform: translateY(0%);
  transform: translateY(0%);
}

.block1-txt:hover .block1-name,
.block1-txt:hover .block1-info {
  color: #fff;
}

/*//////////////////////////////////////////////////////////////////
[ Block2 ]*/
.block2-pic {
  position: relative;
}

.block2-btn {
  position: absolute;
  bottom: -50px;
  left: 50%;
  -webkit-transform: translateX(-50%);
  -moz-transform: translateX(-50%);
  -ms-transform: translateX(-50%);
  -o-transform: translateX(-50%);
  transform: translateX(-50%);
}

.block2-pic:hover .block2-btn {
  bottom: 20px;
}

/*---------------------------------------------*/
.block2-txt-child1 {
  width: calc(100% - 30px);
}

.block2-txt-child2 {
  width: 30px;
}

.btn-addwish-b2 .icon-heart2 {
  opacity: 0;
}

.btn-addwish-b2:hover .icon-heart2 {
  opacity: 1;
}

.btn-addwish-b2:hover .icon-heart1 {
  opacity: 0;
}

.js-addedwish-b2 .icon-heart2 {
  opacity: 1;
}

.js-addedwish-b2 .icon-heart1 {
  opacity: 0;
}

/*---------------------------------------------*/
.label-new {
  position: relative;
}

.label-new::after {
  content: attr(data-label);
  font-family: Montserrat-Regular;
  font-size: 12px;
  color: #fff;
  line-height: 1.2;

  display: -webkit-box;
  display: -webkit-flex;
  display: -moz-box;
  display: -ms-flexbox;
  display: flex;
  justify-content: center;
  align-items: center;
  position: absolute;
  min-width: 50px;
  height: 22px;
  border-radius: 11px;
  padding: 0 6px;
  background-color: #66a8a6;
  top: 42px;
  left: 12px;
}



/*==================================================================
    TEXT TEXT TEXT TEXT TEXT TEXT TEXT TEXT TEXT TEXT TEXT TEXT TEXT
==================================================================*/
.cl0 {color: #fff;}
.cl1 {color: #717fe0;}
.cl2 {color: #333;}
.cl3 {color: #666;}
.cl4 {color: #999;}
.cl5 {color: #222;}
.cl6 {color: #888;}
.cl7 {color: #b2b2b2;}
.cl8 {color: #555;}
.cl9 {color: #aaa;}
.cl10 {color: #1d1d1d;}
.cl11 {color: #f9ba48;}
.cl12 {color: #ccc;}

/*//////////////////////////////////////////////////////////////////
[ S-Text 0 - 15 ]*/
.stext-101 {
  font-family: 'Roboto Condensed', sans-serif;;
  font-size: 15px;
  line-height: 1.466667;
  text-transform: uppercase;
}

.stext-102 {
  font-family: 'Roboto Condensed', sans-serif;;
  font-size: 14px;
  line-height: 1.7;
}

.stext-103 {
  font-family: 'Roboto Condensed', sans-serif;;
  font-size: 15px;
  line-height: 1.466667;
}

.stext-104 {
  font-family: 'Roboto Condensed', sans-serif;;
  font-size: 14px;
  line-height: 1.466667;
}

.stext-105 {
  font-family: 'Roboto Condensed', sans-serif;;
  font-size: 14px;
  line-height: 1.466667;
  letter-spacing: 1px;
}

.stext-106 {
  font-family: 'Roboto Condensed', sans-serif;;
  font-size: 15px;
  line-height: 1.2;
}

.stext-107 {
  font-family: 'Roboto Condensed', sans-serif;;
  font-size: 13px;
  line-height: 1.923;
}

.stext-108 {
  font-family: 'Roboto Condensed', sans-serif;;
  font-size: 14px;
  line-height: 1.7143;
}

.stext-109 {
  font-family: 'Roboto Condensed', sans-serif;;
  font-size: 12px;
  line-height: 1.833333;
}

.stext-110 {
  font-family: 'Roboto Condensed', sans-serif;;
  font-size: 15px;
  line-height: 1.466667;
}

.stext-111 {
  font-family: 'Roboto Condensed', sans-serif;;
  font-size: 13px;
  line-height: 1.6923;
}

.stext-112 {
  font-family: 'Roboto Condensed', sans-serif;;
  font-size: 13px;
  line-height: 1.6923;
  text-transform: uppercase;
}

.stext-113 {
  font-family: 'Roboto Condensed', sans-serif;;
  font-size: 14px;
  line-height: 1.7857;
}

.stext-114 {
  font-family: 'Roboto Condensed', sans-serif;;
  font-size: 15px;
  line-height: 1.666667;
}

.stext-115 {
  font-family: 'Roboto Condensed', sans-serif;;
  font-size: 15px;
  line-height: 1.666667;
}

.stext-116 {
  font-family: 'Roboto Condensed', sans-serif;;
  font-size: 15px;
  line-height: 1.266667;
}

.stext-117 {
  font-family: 'Roboto Condensed', sans-serif;;
  font-size: 15px;
  line-height: 1.666667;
}


/*---------------------------------------------*/
.stext-301 {
  font-family: 'Roboto Condensed', sans-serif;;
  font-size: 15px;
  line-height: 1.6;
  text-transform: uppercase;
}


/*//////////////////////////////////////////////////////////////////
[ M-Text 16 - 25 ]*/
.mtext-101 {
  font-family: 'Roboto Condensed', sans-serif;;
  font-size: 18px;
  line-height: 1.333333;
}

.mtext-102 {
  font-family: 'Roboto Condensed', sans-serif;;
  font-size: 16px;
  line-height: 1.6;
}

.mtext-103 {
  font-family: 'Roboto Condensed', sans-serif;;
  font-size: 18px;
  line-height: 1.333333;
  text-transform: uppercase;
}

.mtext-104 {
  font-family: 'Roboto Condensed', sans-serif;;
  font-size: 16px;
  line-height: 1.6;
}

.mtext-105 {
  font-family: 'Roboto Condensed', sans-serif;;
  font-size: 24px;
  line-height: 1.5;
}

.mtext-106 {
  font-family: 'Roboto Condensed', sans-serif;;
  font-size: 18px;
  line-height: 1.388888;
}

.mtext-107 {
  font-family: 'Roboto Condensed', sans-serif;;
  font-size: 16px;
  line-height: 1.625;
}

.mtext-108 {
  font-family: 'Roboto Condensed', sans-serif;;
  font-size: 20px;
  line-height: 1.3;
}

.mtext-109 {
  font-family: 'Roboto Condensed', sans-serif;;
  font-size: 20px;
  line-height: 1.3;
  text-transform: uppercase;
}

.mtext-110 {
  font-family: 'Roboto Condensed', sans-serif;;
  font-size: 18px;
  line-height: 1.222222;
}

.mtext-111 {
  font-family: 'Roboto Condensed', sans-serif;;
  font-size: 25px;
  line-height: 1.2;
}

.mtext-112 {
  font-family: 'Roboto Condensed', sans-serif;;
  font-size: 22px;
  line-height: 1.333333;
}

.mtext-113 {
  font-family: 'Roboto Condensed', sans-serif;;
  font-size: 22px;
  line-height: 1.333333;
  text-transform: uppercase;
}


/*//////////////////////////////////////////////////////////////////
[ L-Text >= 26 ]*/
.ltext-101 {
  font-family: 'Roboto Condensed', sans-serif;;
  font-size: 28px;
  line-height: 1.2857;
}

.ltext-102 {
  font-family: 'Roboto Condensed', sans-serif;;
  font-size: 28px;
  line-height: 1.1;
}

.ltext-103 {
  font-family: 'Roboto Condensed', sans-serif;;
  font-size: 36px;
  line-height: 1.1;
  text-transform: uppercase;
}

.ltext-104 {
  font-family: 'Roboto Condensed', sans-serif;;
  font-size: 60px;
  line-height: 1.1;
  text-transform: uppercase;
}

.ltext-105 {
  font-family: 'Roboto Condensed', sans-serif;;
  font-size: 50px;
  line-height: 1.1;
}

.ltext-106 {
  font-family: 'Roboto Condensed', sans-serif;;
  font-size: 36px;
  line-height: 1.2;
}

.ltext-107 {
  font-family: 'Roboto Condensed', sans-serif;;
  font-size: 30px;
  line-height: 1.1;
}

.ltext-108 {
  font-family: 'Roboto Condensed', sans-serif;;
  font-size: 26px;
  line-height: 1.3846;
}

.ltext-109 {
  font-family: 'Roboto Condensed', sans-serif;;
  font-size: 36px;
  line-height: 1.2;
}


/*---------------------------------------------*/
.ltext-201 {
  font-family: PlayfairDisplay-Bold;
  font-size: 60px;
  line-height: 1.1;
  text-transform: uppercase;
}

.ltext-202 {
  font-family: PlayfairDisplay-Regular;
  font-size: 28px;
  line-height: 1.2857;
}




/*==================================================================
    SIZE SIZE SIZE SIZE SIZE SIZE SIZE SIZE SIZE SIZE SIZE SIZE SIZE 
==================================================================*/


/*//////////////////////////////////////////////////////////////////
[ Size ]*/
.size-101 {
  min-width: 161px;
  height: 46px;
}

.size-102 {
  min-width: 139px;
  height: 40px;
}

.size-103 {
  min-width: 179px;
  height: 46px;
}

.size-104 {
  min-width: 94px;
  height: 40px;
}

.size-105 {
  min-width: 111px;
  height: 40px;
}

.size-106 {
  width: 88px;
  height: 100%;
}

.size-107 {
  min-width: 145px;
  height: 40px;
}

.size-108 {
  width: 40px;
  height: 40px;
}

.size-109 {
  width: 60px;
  height: 60px;
}

.size-110 {
  width: 100%;
  min-height: 100px;
}

.size-111 {
  width: 100%;
  height: 40px;
}

.size-112 {
  min-width: 134px;
  height: 43px;
}

.size-113 {
  width: 38px;
  height: 60px;
}

.size-114 {
  width: calc(100% - 38px);
  height: 60px;
}

.size-w-114 {
  width: calc(100% - 38px);
  height: 200px;
}

.size-115 {
  min-width: 185px;
  height: 45px;
}

.size-116 {
  width: 100%;
  height: 50px;
}

.size-117 {
  width: 220px;
  height: 45px;
}

.size-118 {
  min-width: 163px;
  height: 45px;
}

.size-119 {
  min-width: 156px;
  height: 45px;
}

.size-120 {
  width: 100%;
  min-height: 199px;
}

.size-121 {
  width: 100%;
  height: 46px;
}

.size-122 {
  width: 55px;
  height: 100%;
}

.size-123 {
  width: 70px;
  min-height: 70px;
}

.size-124 {
  width: 100%;
  min-height: 150px;
}

.size-125 {
  min-width: 180px;
  height: 40px;
}

/*//////////////////////////////////////////////////////////////////
[ Width ]*/
.size-201 {
  max-width: 270px;
}

.size-202 {
  width: calc(100% / 3);
}

.size-203 {
  width: 105px;
}

.size-204 {
  width: calc(100% - 105px);
}

.size-205 {
  width: 145px;
}

.size-206 {
  width: calc(100% - 145px);
}

.size-207 {
  width: calc(100% - 78px);
}

.size-208 {
  width: 34.5%;
}

.size-209 {
  width: 65.5%;
}

.size-210 {
  width: 50%;
}

.size-211 {
  width: 60px;
}

.size-212 {
  width: calc(100% - 60px);
}

.size-213 {
  max-width: 245px;
}

.size-214 {
  width: 90px;
}

.size-215 {
  width: calc(100% - 110px);
}

.size-216 {
  width: 55px;
}

.size-217 {
  width: calc(100% - 55px);
}

.size-218 {
  max-width: 286px;
}



/*//////////////////////////////////////////////////////////////////
[ Height ]*/
.size-301 {
  min-height: 30px;
}

.size-302 {
  min-height: 80px;
}

.size-303 {
  height: 390px;
}


/*==================================================================
   BACKGROUND BACKGROUND BACKGROUND BACKGROUND BACKGROUND BACKGROUND 
==================================================================*/
.bg-none {background-color: transparent;}
.bg0 {background-color: #fff;}
.bg1 {background-color: #717fe0;}
.bg2 {background-color: #e6e6e6;}
.bg3 {background-color: #222;}
.bg5 {background-color: rgba(0,0,0,0.5);}
.bg6 {background-color: #f2f2f2;}
.bg7 {background-color: #333;}
.bg8 {background-color: #f3f3f3;}
.bg9 {background-color: rgba(255,255,255,0.9);}

/*---------------------------------------------*/
.bg-overlay1::before {
  content: "";
  position: absolute;
  z-index: -100;
  display: block;
  width: 100%;
  height: 100%;
  top: 0;
  left: 0;
  background-color: #000;
  opacity: 0.5;
}

/*---------------------------------------------*/
.bg-img1 {
  background-size: cover;
  background-position: center center;
  background-repeat: no-repeat;
}




/*==================================================================
       BORDER BORDER  BORDER  BORDER  BORDER  BORDER  BORDER  BORDER
==================================================================*/
.bor0 {border-radius: 50%;}

.bor1 {
  border-radius: 23px;
}

.bor2 {
  border-radius: 20px;
}

.bor3 {
  border-bottom: 1px solid transparent;
}

.bor4 {
  border: 1px solid #e6e6e6;
  border-radius: 3px;
}

.bor5 {
  border-left: 1px solid #e5e5e5;
  border-right: 1px solid #e5e5e5;
}

.bor6 {border-right: 1px solid rgba(255,255,255,0.1);}

.bor7 {
  border: 1px solid #ccc;
  border-radius: 15px;
}

.bor8 {
  border: 1px solid #e6e6e6;
  border-radius: 2px;
}

.bor9 {
  border-right: 1px solid #e6e6e6;
}

.bor10 {
  border: 1px solid #e6e6e6;
}

.bor11 {
  border-radius: 21px;
}

.bor12 {
  border-bottom: 1px dashed #d9d9d9;
}

.bor13 {
  border: 1px solid #e6e6e6;
  border-radius: 22px;
}

.bor14 {
  border-radius: 25px;
}

.bor15 {
  border-left: 1px solid #e6e6e6;
  border-right: 1px solid #e6e6e6;
  border-bottom: 1px solid #e6e6e6;
}

.bor16 {
  border-left: 3px solid #e6e6e6;
}

.bor17 {
  border: 1px solid #e6e6e6;
  border-radius: 25px;
}

/*---------------------------------------------*/
.bor18 {
  border-top: 1px solid #e6e6e6;
}

.bor18:last-child {
  border-bottom: 1px solid #e6e6e6;
}

/*---------------------------------------------*/
.bor19 {
  border: 1px solid #d9d9d9;
  border-radius: 2px;
}


/*==================================================================
 HOW HOW HOW HOW HOW HOW HOW HOW HOW HOW HOW HOW HOW HOW HOW HOW HOW 
==================================================================*/
.plh0::-webkit-input-placeholder { color: #999999;}
.plh0:-moz-placeholder { color: #999999;}
.plh0::-moz-placeholder { color: #999999;}
.plh0:-ms-input-placeholder { color: #999999;}

.plh1::-webkit-input-placeholder { color: #b2b2b2;}
.plh1:-moz-placeholder { color: #b2b2b2;}
.plh1::-moz-placeholder { color: #b2b2b2;}
.plh1:-ms-input-placeholder { color: #b2b2b2;}

.plh2::-webkit-input-placeholder { color: #333;}
.plh2:-moz-placeholder { color: #333;}
.plh2::-moz-placeholder { color: #333;}
.plh2:-ms-input-placeholder { color: #333;}

.plh3::-webkit-input-placeholder { color: #555;}
.plh3:-moz-placeholder { color: #555;}
.plh3::-moz-placeholder { color: #555;}
.plh3:-ms-input-placeholder { color: #555;}

.plh4::-webkit-input-placeholder { color: #888;}
.plh4:-moz-placeholder { color: #888;}
.plh4::-moz-placeholder { color: #888;}
.plh4:-ms-input-placeholder { color: #888;}

/*---------------------------------------------*/
.js-addedwish-detail {
  color: #6c7ae0;
}

/*---------------------------------------------*/
.label1 {
  position: relative;
}

.label1::after {
  content: attr(data-label1);
  font-family: 'Roboto Condensed', sans-serif;;
  font-size: 10px;
  line-height: 15px;
  color: #fff;
  text-transform: uppercase;
  text-align: center;

  display: block;
  position: absolute;
  top: 3px;
  right: -9px;
  height: 15px;
  min-width: 32px;
  border-radius: 7px;
  padding: 0 4px;
  background-color: #f74877;
}

.label1.rs1::after {
  top: calc(50% - 8px);
  right: auto;
  left: 90%;
}

/*---------------------------------------------*/
.how-active1 {
  color: #333;
  border-color: #797979;
}


/*---------------------------------------------*/
.wrap-input1 {
  position: relative;
  border-bottom: 2px solid rgba(204,204,204, 0.1);
}

.input1 {
  background-color: transparent;
  width: 100%;
}

input[type="text"]:disabled {
  background-color: rgb(199, 199, 199);
  color: #000;
}

.focus-input1 {
  position: absolute;
  width: 0%;
  height: 2px;
  background-color: #6774d5;
  left: 0;
  bottom: -2px;
}

.input1:focus + .focus-input1 {
  width: 100%;
}


/*---------------------------------------------*/
.how-pagination1 {
  font-family: 'Roboto Condensed', sans-serif;;
  font-size: 14px;
  color: #808080;

  width: 36px;
  height: 36px;
  border-radius: 50%;
  border: 1px solid #e6e6e6;
}

.how-pagination1:hover {
  background-color: #999;
  border-color: #999;
  color: #fff;
}

.active-pagination1 {
  background-color: #999;
  border-color: #999;
  color: #fff;
}

/*---------------------------------------------*/
.how-shadow1 {
  box-shadow: 0 0px 3px 0px rgba(0,0,0,0.2);
  -moz-box-shadow: 0 0px 3px 0px rgba(0,0,0,0.2);
  -webkit-box-shadow: 0 0px 3px 0px rgba(0,0,0,0.2);
  -o-box-shadow: 0 0px 3px 0px rgba(0,0,0,0.2);
  -ms-box-shadow: 0 0px 3px 0px rgba(0,0,0,0.2);
}

/*---------------------------------------------*/
.how-pos1 {
  position: absolute;
  top: 10px;
  right: 10px;
}

/*---------------------------------------------*/
.how-pos2 {
  padding-left: 10.7%;
  padding-right: 11%;
}

@media (max-width: 991px) {
  .how-pos2 {
    padding-left: 8%;
    padding-right: 8%;
  }
}

/*---------------------------------------------*/
.how-pos3-parent {
  position: relative;
}

.how-pos3 {
  position: absolute;
  top: -35px;
  right: 0px;
}

/*---------------------------------------------*/
.how-pos4-parent {
  position: relative;
}

.how-pos4 {
  position: absolute;
  top: calc(50% - 9px);
  left: 28px;
}

/*---------------------------------------------*/
.how-pos5-parent {
  position: relative;
}

.how-pos5 {
  position: absolute;
  top: 15px;
  left: 10px;
}



/*---------------------------------------------*/
.how-itemcart1 {
  width: 60px;
  position: relative;
  margin-right: 20px;
  cursor: pointer;
}

.how-itemcart1 img {
  width: 100%;
}

.how-itemcart1::after {
  content: '\e870';
  font-family: Linearicons-Free;
  font-size: 16px;
  display: -webkit-box;
  display: -webkit-flex;
  display: -moz-box;
  display: -ms-flexbox;
  display: flex;
  justify-content: center;
  align-items: center;
  position: absolute;
  width: 100%;
  height: 100%;
  top: 0;
  left: 0;
  background-color: rgba(0,0,0,0.5);
  color: #fff;
  transition: all 0.3s;
  -webkit-transition: all 0.3s;
  -o-transition: all 0.3s;
  -moz-transition: all 0.3s;
  opacity: 0;
}

.how-itemcart1:hover:after {
  opacity: 1;
}

/*---------------------------------------------*/
.how-bor2,
.how-bor1 {
  position: relative;
  z-index: 1;
}

.how-bor2::before,
.how-bor1::before {
  content: "";
  display: block;
  position: absolute;
  z-index: -1;
  width: 100%;
  height: 100%;
  border: 3px solid #ccc;
}

.how-bor1::before {
  bottom: -21px;
  left: -21px;
}

@media (max-width: 767px) {
  .how-bor1::before {
    bottom: -21px;
    right: -21px;
    left: auto;
  }
}

.how-bor2::before {
  bottom: -21px;
  right: -21px;
}



/*==================================================================
      PSEUDO PSEUDO PSEUDO PSEUDO PSEUDO PSEUDO PSEUDO PSEUDO PSEUDO
==================================================================*/

/*//////////////////////////////////////////////////////////////////
[ Focus ]*/
.focus-in0:focus::-webkit-input-placeholder { color:transparent; }
.focus-in0:focus:-moz-placeholder { color:transparent; }
.focus-in0:focus::-moz-placeholder { color:transparent; }
.focus-in0:focus:-ms-input-placeholder { color:transparent; }




/*//////////////////////////////////////////////////////////////////
[ Hover ]*/

.hov-cl0:hover {color: #fff;}
.hov-bg0:hover {background-color: #fff;}
.hov-cl1:hover {color: #717fe0;}
.hov-bg1:hover {background-color: #717fe0;}

/*---------------------------------------------*/
.hov-img0 {
  display: block;
  overflow: hidden;
}

.hov-img0 img{
  width: 100%;
  -webkit-transition: transform 0.9s ease;
  -o-transition: transform 0.9s ease;
  -moz-transition: transform 0.9s ease;
  transition: transform 0.9s ease;
}

.hov-img0:hover img {
  -webkit-transform: scale(1.1);
  -moz-transform: scale(1.1);
  -ms-transform: scale(1.1);
  -o-transform: scale(1.1);
  transform: scale(1.1);
}

/*---------------------------------------------*/
.hov-btn1:hover {
  border-color: #222;
  background-color: #222;
  color: #fff;
}

.hov-btn1:hover i {
  color: #fff;
}

/*---------------------------------------------*/
.hov-btn2:hover {
  border-color: #fff;
  background-color: #fff;
  color: #717fe0;
}

/*---------------------------------------------*/
.hov-btn3:hover {
  border-color: #717fe0;
  background-color: #717fe0;
  color: #fff;
}

.hov-btn3:hover i {
  color: #fff;
}

/*---------------------------------------------*/
.hov-tag1:hover {
  color: #717fe0;
  border-color: #717fe0;
}


/*---------------------------------------------*/
.hov-ovelay1 {
  position: relative;
}

.hov-ovelay1::after {
  content: "";
  display: block;
  position: absolute;
  width: 100%;
  height: 100%;
  top: 0;
  left: 0;
  background: rgba(103,117,214,0.8);
  opacity: 0;
  transition: all 0.3s;
  -webkit-transition: all 0.3s;
  -o-transition: all 0.3s;
  -moz-transition: all 0.3s;
}

.hov-ovelay1:hover:after {
  opacity: 1;
}


/*---------------------------------------------*/
.hov1:hover {
  color: #333;
  border-color: #797979;
}

/*---------------------------------------------*/
.hov2:hover {
  background-color: #f2f2f2;
}

/*---------------------------------------------*/
.hov3 {
  opacity: 0.6;
}

.hov3:hover {
  opacity: 1;
}




/*==================================================================
  RESPONSIVE RESPONSIVE RESPONSIVE RESPONSIVE RESPONSIVE RESPONSIVE
==================================================================*/

/*//////////////////////////////////////////////////////////////////
[ XL ]*/
@media (max-width: 1199px) {
  .m-0-xl {margin: 0;}
  .m-lr-0-xl {margin-left: 0; margin-right: 0;}
  .m-lr-15-xl {margin-left: 15px; margin-right: 15px;}
  .m-l-0-xl {margin-left: 0;}
  .m-r-0-xl {margin-right: 0;}
  .m-l-15-xl {margin-left: 15px;}
  .m-r-15-xl {margin-right: 15px;}

  .p-0-xl {padding: 0;}
  .p-lr-0-xl {padding-left: 0; padding-right: 0;}
  .p-lr-15-xl {padding-left: 15px; padding-right: 15px;}
  .p-l-0-xl {padding-left: 0;}
  .p-r-0-xl {padding-right: 0;}
  .p-l-15-xl {padding-left: 15px;}
  .p-r-15-xl {padding-right: 15px;}

  .w-full-xl {width: 100%;}

  /*---------------------------------------------*/

}


/*//////////////////////////////////////////////////////////////////
[ LG ]*/
@media (max-width: 991px) {
  .m-0-lg {margin: 0;}
  .m-lr-0-lg {margin-left: 0; margin-right: 0;}
  .m-lr-15-lg {margin-left: 15px; margin-right: 15px;}
  .m-l-0-lg {margin-left: 0;}
  .m-r-0-lg {margin-right: 0;}
  .m-l-15-lg {margin-left: 15px;}
  .m-r-15-lg {margin-right: 15px;}

  .p-0-lg {padding: 0;}
  .p-lr-0-lg {padding-left: 0; padding-right: 0;}
  .p-lr-15-lg {padding-left: 15px; padding-right: 15px;}
  .p-l-0-lg {padding-left: 0;}
  .p-r-0-lg{padding-right: 0;}
  .p-l-15-lg {padding-left: 15px;}
  .p-r-15-lg {padding-right: 15px;}

  .w-full-lg {width: 100%;}

  /*---------------------------------------------*/
  .respon4 {
    width: 50%;
  }

  /*---------------------------------------------*/
  .respon5 {
    padding-top: 50px;
    padding-bottom: 50px;
  }
}


/*//////////////////////////////////////////////////////////////////
[ MD ]*/
@media (max-width: 767px) {
  .m-0-md {margin: 0;}
  .m-lr-0-md {margin-left: 0; margin-right: 0;}
  .m-lr-15-md {margin-left: 15px; margin-right: 15px;}
  .m-l-0-md {margin-left: 0;}
  .m-r-0-md {margin-right: 0;}
  .m-l-15-md {margin-left: 15px;}
  .m-r-15-md {margin-right: 15px;}

  .p-0-md {padding: 0;}
  .p-lr-0-md {padding-left: 0; padding-right: 0;}
  .p-lr-15-md {padding-left: 15px; padding-right: 15px;}
  .p-l-0-md {padding-left: 0;}
  .p-r-0-md{padding-right: 0;}
  .p-l-15-md {padding-left: 15px;}
  .p-r-15-md {padding-right: 15px;}

  .w-full-md {width: 100%;}

  /*---------------------------------------------*/
  .respon4 {
    width: 100%;
  }

}


/*//////////////////////////////////////////////////////////////////
[ SM ]*/
@media (max-width: 575px) {
  .m-0-sm {margin: 0;}
  .m-lr-0-sm {margin-left: 0; margin-right: 0;}
  .m-lr-15-sm {margin-left: 15px; margin-right: 15px;}
  .m-l-0-sm {margin-left: 0;}
  .m-r-0-sm {margin-right: 0;}
  .m-l-15-sm {margin-left: 15px;}
  .m-r-15-sm {margin-right: 15px;}

  .p-0-sm {padding: 0;}
  .p-lr-0-sm {padding-left: 0; padding-right: 0;}
  .p-lr-15-sm {padding-left: 15px; padding-right: 15px;}
  .p-l-0-sm {padding-left: 0;}
  .p-r-0-sm{padding-right: 0;}
  .p-l-15-sm {padding-left: 15px;}
  .p-r-15-sm {padding-right: 15px;}

  .w-full-sm {width: 100%;}

  /*---------------------------------------------*/
  .respon1 {
    font-size: 40px;
  }
  
  /*---------------------------------------------*/
  .respon2 {
    font-size: 20px;
  }

  /*---------------------------------------------*/
  .respon6 {
    width: 65px;
  }

  .respon6-next {
    width: calc(100% - 65px);
  }

  /*---------------------------------------------*/
  .respon7 {
    padding-left: 60px;
  }

  
}


/*//////////////////////////////////////////////////////////////////
[ SSM ]*/
@media (max-width: 480px) {
  .m-0-ssm {margin: 0;}
  .m-lr-0-ssm {margin-left: 0; margin-right: 0;}
  .m-lr-15-ssm {margin-left: 15px; margin-right: 15px;}
  .m-l-0-ssm {margin-left: 0;}
  .m-r-0-ssm {margin-right: 0;}
  .m-l-15-ssm {margin-left: 15px;}
  .m-r-15-ssm {margin-right: 15px;}

  .p-0-ssm {padding: 0;}
  .p-lr-0-ssm {padding-left: 0; padding-right: 0;}
  .p-lr-15-ssm {padding-left: 15px; padding-right: 15px;}
  .p-l-0-ssm {padding-left: 0;}
  .p-r-0-ssm{padding-right: 0;}
  .p-l-15-ssm {padding-left: 15px;}
  .p-r-15-ssm {padding-right: 15px;}

  .w-full-ssm {width: 100%;}

  /*---------------------------------------------*/
  .respon3 {
    padding: 20px;
  }

}

.wrap-login {
  width: 600px;
}

.nav-pills .nav-link.active, .show>.nav-pills .nav-link {
  background-color: #000;
}

    </style>
    <style>
       

/*//////////////////////////////////////////////////////////////////
[ REBOOT ]*/
*, *:before, *:after {
	margin: 0px; 
	padding: 0px; 
	-webkit-box-sizing: border-box;
	-moz-box-sizing: border-box;
	box-sizing: border-box;
}

body, html {
	font-family: Arial, sans-serif;
	font-size: 15px;
	color: #666666;

	height: 100%;
	background-color: #fff;
	-webkit-box-sizing: border-box;
	-moz-box-sizing: border-box;
	box-sizing: border-box;
}

/*---------------------------------------------*/
a:focus {outline: none;}
a:hover {text-decoration: none;}

/*---------------------------------------------*/
h1,h2,h3,h4,h5,h6,p {margin: 0px;}

ul, li {
	margin: 0px;
	list-style-type: none;
}


/*---------------------------------------------*/
input, textarea, label {
	display: block;
	outline: none;
	border: none;
}

/*---------------------------------------------*/
button {
	outline: none;
	border: none;
	background: transparent;
	cursor: pointer;
}

button:focus {outline: none;}

iframe {border: none;}


/*//////////////////////////////////////////////////////////////////
[ FONT SIZE ]*/
.fs-1 {font-size: 1px;}
.fs-2 {font-size: 2px;}
.fs-3 {font-size: 3px;}
.fs-4 {font-size: 4px;}
.fs-5 {font-size: 5px;}
.fs-6 {font-size: 6px;}
.fs-7 {font-size: 7px;}
.fs-8 {font-size: 8px;}
.fs-9 {font-size: 9px;}
.fs-10 {font-size: 10px;}
.fs-11 {font-size: 11px;}
.fs-12 {font-size: 12px;}
.fs-13 {font-size: 13px;}
.fs-14 {font-size: 14px;}
.fs-15 {font-size: 15px;}
.fs-16 {font-size: 16px;}
.fs-17 {font-size: 17px;}
.fs-18 {font-size: 18px;}
.fs-19 {font-size: 19px;}
.fs-20 {font-size: 20px;}
.fs-21 {font-size: 21px;}
.fs-22 {font-size: 22px;}
.fs-23 {font-size: 23px;}
.fs-24 {font-size: 24px;}
.fs-25 {font-size: 25px;}
.fs-26 {font-size: 26px;}
.fs-27 {font-size: 27px;}
.fs-28 {font-size: 28px;}
.fs-29 {font-size: 29px;}
.fs-30 {font-size: 30px;}
.fs-31 {font-size: 31px;}
.fs-32 {font-size: 32px;}
.fs-33 {font-size: 33px;}
.fs-34 {font-size: 34px;}
.fs-35 {font-size: 35px;}
.fs-36 {font-size: 36px;}
.fs-37 {font-size: 37px;}
.fs-38 {font-size: 38px;}
.fs-39 {font-size: 39px;}
.fs-40 {font-size: 40px;}
.fs-41 {font-size: 41px;}
.fs-42 {font-size: 42px;}
.fs-43 {font-size: 43px;}
.fs-44 {font-size: 44px;}
.fs-45 {font-size: 45px;}
.fs-46 {font-size: 46px;}
.fs-47 {font-size: 47px;}
.fs-48 {font-size: 48px;}
.fs-49 {font-size: 49px;}
.fs-50 {font-size: 50px;}
.fs-51 {font-size: 51px;}
.fs-52 {font-size: 52px;}
.fs-53 {font-size: 53px;}
.fs-54 {font-size: 54px;}
.fs-55 {font-size: 55px;}
.fs-56 {font-size: 56px;}
.fs-57 {font-size: 57px;}
.fs-58 {font-size: 58px;}
.fs-59 {font-size: 59px;}
.fs-60 {font-size: 60px;}
.fs-61 {font-size: 61px;}
.fs-62 {font-size: 62px;}
.fs-63 {font-size: 63px;}
.fs-64 {font-size: 64px;}
.fs-65 {font-size: 65px;}
.fs-66 {font-size: 66px;}
.fs-67 {font-size: 67px;}
.fs-68 {font-size: 68px;}
.fs-69 {font-size: 69px;}
.fs-70 {font-size: 70px;}
.fs-71 {font-size: 71px;}
.fs-72 {font-size: 72px;}
.fs-73 {font-size: 73px;}
.fs-74 {font-size: 74px;}
.fs-75 {font-size: 75px;}
.fs-76 {font-size: 76px;}
.fs-77 {font-size: 77px;}
.fs-78 {font-size: 78px;}
.fs-79 {font-size: 79px;}
.fs-80 {font-size: 80px;}
.fs-81 {font-size: 81px;}
.fs-82 {font-size: 82px;}
.fs-83 {font-size: 83px;}
.fs-84 {font-size: 84px;}
.fs-85 {font-size: 85px;}
.fs-86 {font-size: 86px;}
.fs-87 {font-size: 87px;}
.fs-88 {font-size: 88px;}
.fs-89 {font-size: 89px;}
.fs-90 {font-size: 90px;}
.fs-91 {font-size: 91px;}
.fs-92 {font-size: 92px;}
.fs-93 {font-size: 93px;}
.fs-94 {font-size: 94px;}
.fs-95 {font-size: 95px;}
.fs-96 {font-size: 96px;}
.fs-97 {font-size: 97px;}
.fs-98 {font-size: 98px;}
.fs-99 {font-size: 99px;}
.fs-100 {font-size: 100px;}
.fs-101 {font-size: 101px;}
.fs-102 {font-size: 102px;}
.fs-103 {font-size: 103px;}
.fs-104 {font-size: 104px;}
.fs-105 {font-size: 105px;}
.fs-106 {font-size: 106px;}
.fs-107 {font-size: 107px;}
.fs-108 {font-size: 108px;}
.fs-109 {font-size: 109px;}
.fs-110 {font-size: 110px;}
.fs-111 {font-size: 111px;}
.fs-112 {font-size: 112px;}
.fs-113 {font-size: 113px;}
.fs-114 {font-size: 114px;}
.fs-115 {font-size: 115px;}
.fs-116 {font-size: 116px;}
.fs-117 {font-size: 117px;}
.fs-118 {font-size: 118px;}
.fs-119 {font-size: 119px;}
.fs-120 {font-size: 120px;}
.fs-121 {font-size: 121px;}
.fs-122 {font-size: 122px;}
.fs-123 {font-size: 123px;}
.fs-124 {font-size: 124px;}
.fs-125 {font-size: 125px;}
.fs-126 {font-size: 126px;}
.fs-127 {font-size: 127px;}
.fs-128 {font-size: 128px;}
.fs-129 {font-size: 129px;}
.fs-130 {font-size: 130px;}
.fs-131 {font-size: 131px;}
.fs-132 {font-size: 132px;}
.fs-133 {font-size: 133px;}
.fs-134 {font-size: 134px;}
.fs-135 {font-size: 135px;}
.fs-136 {font-size: 136px;}
.fs-137 {font-size: 137px;}
.fs-138 {font-size: 138px;}
.fs-139 {font-size: 139px;}
.fs-140 {font-size: 140px;}
.fs-141 {font-size: 141px;}
.fs-142 {font-size: 142px;}
.fs-143 {font-size: 143px;}
.fs-144 {font-size: 144px;}
.fs-145 {font-size: 145px;}
.fs-146 {font-size: 146px;}
.fs-147 {font-size: 147px;}
.fs-148 {font-size: 148px;}
.fs-149 {font-size: 149px;}
.fs-150 {font-size: 150px;}
.fs-151 {font-size: 151px;}
.fs-152 {font-size: 152px;}
.fs-153 {font-size: 153px;}
.fs-154 {font-size: 154px;}
.fs-155 {font-size: 155px;}
.fs-156 {font-size: 156px;}
.fs-157 {font-size: 157px;}
.fs-158 {font-size: 158px;}
.fs-159 {font-size: 159px;}
.fs-160 {font-size: 160px;}
.fs-161 {font-size: 161px;}
.fs-162 {font-size: 162px;}
.fs-163 {font-size: 163px;}
.fs-164 {font-size: 164px;}
.fs-165 {font-size: 165px;}
.fs-166 {font-size: 166px;}
.fs-167 {font-size: 167px;}
.fs-168 {font-size: 168px;}
.fs-169 {font-size: 169px;}
.fs-170 {font-size: 170px;}
.fs-171 {font-size: 171px;}
.fs-172 {font-size: 172px;}
.fs-173 {font-size: 173px;}
.fs-174 {font-size: 174px;}
.fs-175 {font-size: 175px;}
.fs-176 {font-size: 176px;}
.fs-177 {font-size: 177px;}
.fs-178 {font-size: 178px;}
.fs-179 {font-size: 179px;}
.fs-180 {font-size: 180px;}
.fs-181 {font-size: 181px;}
.fs-182 {font-size: 182px;}
.fs-183 {font-size: 183px;}
.fs-184 {font-size: 184px;}
.fs-185 {font-size: 185px;}
.fs-186 {font-size: 186px;}
.fs-187 {font-size: 187px;}
.fs-188 {font-size: 188px;}
.fs-189 {font-size: 189px;}
.fs-190 {font-size: 190px;}
.fs-191 {font-size: 191px;}
.fs-192 {font-size: 192px;}
.fs-193 {font-size: 193px;}
.fs-194 {font-size: 194px;}
.fs-195 {font-size: 195px;}
.fs-196 {font-size: 196px;}
.fs-197 {font-size: 197px;}
.fs-198 {font-size: 198px;}
.fs-199 {font-size: 199px;}
.fs-200 {font-size: 200px;}

/*//////////////////////////////////////////////////////////////////
[ PADDING ]*/
.p-t-0, .p-tb-0, .p-all-0 {padding-top: 0px;}
.p-t-1, .p-tb-1, .p-all-1 {padding-top: 1px;}
.p-t-2, .p-tb-2, .p-all-2 {padding-top: 2px;}
.p-t-3, .p-tb-3, .p-all-3 {padding-top: 3px;}
.p-t-4, .p-tb-4, .p-all-4 {padding-top: 4px;}
.p-t-5, .p-tb-5, .p-all-5 {padding-top: 5px;}
.p-t-6, .p-tb-6, .p-all-6 {padding-top: 6px;}
.p-t-7, .p-tb-7, .p-all-7 {padding-top: 7px;}
.p-t-8, .p-tb-8, .p-all-8 {padding-top: 8px;}
.p-t-9, .p-tb-9, .p-all-9 {padding-top: 9px;}
.p-t-10, .p-tb-10, .p-all-10 {padding-top: 10px;}
.p-t-11, .p-tb-11, .p-all-11 {padding-top: 11px;}
.p-t-12, .p-tb-12, .p-all-12 {padding-top: 12px;}
.p-t-13, .p-tb-13, .p-all-13 {padding-top: 13px;}
.p-t-14, .p-tb-14, .p-all-14 {padding-top: 14px;}
.p-t-15, .p-tb-15, .p-all-15 {padding-top: 15px;}
.p-t-16, .p-tb-16, .p-all-16 {padding-top: 16px;}
.p-t-17, .p-tb-17, .p-all-17 {padding-top: 17px;}
.p-t-18, .p-tb-18, .p-all-18 {padding-top: 18px;}
.p-t-19, .p-tb-19, .p-all-19 {padding-top: 19px;}
.p-t-20, .p-tb-20, .p-all-20 {padding-top: 20px;}
.p-t-21, .p-tb-21, .p-all-21 {padding-top: 21px;}
.p-t-22, .p-tb-22, .p-all-22 {padding-top: 22px;}
.p-t-23, .p-tb-23, .p-all-23 {padding-top: 23px;}
.p-t-24, .p-tb-24, .p-all-24 {padding-top: 24px;}
.p-t-25, .p-tb-25, .p-all-25 {padding-top: 25px;}
.p-t-26, .p-tb-26, .p-all-26 {padding-top: 26px;}
.p-t-27, .p-tb-27, .p-all-27 {padding-top: 27px;}
.p-t-28, .p-tb-28, .p-all-28 {padding-top: 28px;}
.p-t-29, .p-tb-29, .p-all-29 {padding-top: 29px;}
.p-t-30, .p-tb-30, .p-all-30 {padding-top: 30px;}
.p-t-31, .p-tb-31, .p-all-31 {padding-top: 31px;}
.p-t-32, .p-tb-32, .p-all-32 {padding-top: 32px;}
.p-t-33, .p-tb-33, .p-all-33 {padding-top: 33px;}
.p-t-34, .p-tb-34, .p-all-34 {padding-top: 34px;}
.p-t-35, .p-tb-35, .p-all-35 {padding-top: 35px;}
.p-t-36, .p-tb-36, .p-all-36 {padding-top: 36px;}
.p-t-37, .p-tb-37, .p-all-37 {padding-top: 37px;}
.p-t-38, .p-tb-38, .p-all-38 {padding-top: 38px;}
.p-t-39, .p-tb-39, .p-all-39 {padding-top: 39px;}
.p-t-40, .p-tb-40, .p-all-40 {padding-top: 40px;}
.p-t-41, .p-tb-41, .p-all-41 {padding-top: 41px;}
.p-t-42, .p-tb-42, .p-all-42 {padding-top: 42px;}
.p-t-43, .p-tb-43, .p-all-43 {padding-top: 43px;}
.p-t-44, .p-tb-44, .p-all-44 {padding-top: 44px;}
.p-t-45, .p-tb-45, .p-all-45 {padding-top: 45px;}
.p-t-46, .p-tb-46, .p-all-46 {padding-top: 46px;}
.p-t-47, .p-tb-47, .p-all-47 {padding-top: 47px;}
.p-t-48, .p-tb-48, .p-all-48 {padding-top: 48px;}
.p-t-49, .p-tb-49, .p-all-49 {padding-top: 49px;}
.p-t-50, .p-tb-50, .p-all-50 {padding-top: 50px;}
.p-t-51, .p-tb-51, .p-all-51 {padding-top: 51px;}
.p-t-52, .p-tb-52, .p-all-52 {padding-top: 52px;}
.p-t-53, .p-tb-53, .p-all-53 {padding-top: 53px;}
.p-t-54, .p-tb-54, .p-all-54 {padding-top: 54px;}
.p-t-55, .p-tb-55, .p-all-55 {padding-top: 55px;}
.p-t-56, .p-tb-56, .p-all-56 {padding-top: 56px;}
.p-t-57, .p-tb-57, .p-all-57 {padding-top: 57px;}
.p-t-58, .p-tb-58, .p-all-58 {padding-top: 58px;}
.p-t-59, .p-tb-59, .p-all-59 {padding-top: 59px;}
.p-t-60, .p-tb-60, .p-all-60 {padding-top: 60px;}
.p-t-61, .p-tb-61, .p-all-61 {padding-top: 61px;}
.p-t-62, .p-tb-62, .p-all-62 {padding-top: 62px;}
.p-t-63, .p-tb-63, .p-all-63 {padding-top: 63px;}
.p-t-64, .p-tb-64, .p-all-64 {padding-top: 64px;}
.p-t-65, .p-tb-65, .p-all-65 {padding-top: 65px;}
.p-t-66, .p-tb-66, .p-all-66 {padding-top: 66px;}
.p-t-67, .p-tb-67, .p-all-67 {padding-top: 67px;}
.p-t-68, .p-tb-68, .p-all-68 {padding-top: 68px;}
.p-t-69, .p-tb-69, .p-all-69 {padding-top: 69px;}
.p-t-70, .p-tb-70, .p-all-70 {padding-top: 70px;}
.p-t-71, .p-tb-71, .p-all-71 {padding-top: 71px;}
.p-t-72, .p-tb-72, .p-all-72 {padding-top: 72px;}
.p-t-73, .p-tb-73, .p-all-73 {padding-top: 73px;}
.p-t-74, .p-tb-74, .p-all-74 {padding-top: 74px;}
.p-t-75, .p-tb-75, .p-all-75 {padding-top: 75px;}
.p-t-76, .p-tb-76, .p-all-76 {padding-top: 76px;}
.p-t-77, .p-tb-77, .p-all-77 {padding-top: 77px;}
.p-t-78, .p-tb-78, .p-all-78 {padding-top: 78px;}
.p-t-79, .p-tb-79, .p-all-79 {padding-top: 79px;}
.p-t-80, .p-tb-80, .p-all-80 {padding-top: 80px;}
.p-t-81, .p-tb-81, .p-all-81 {padding-top: 81px;}
.p-t-82, .p-tb-82, .p-all-82 {padding-top: 82px;}
.p-t-83, .p-tb-83, .p-all-83 {padding-top: 83px;}
.p-t-84, .p-tb-84, .p-all-84 {padding-top: 84px;}
.p-t-85, .p-tb-85, .p-all-85 {padding-top: 85px;}
.p-t-86, .p-tb-86, .p-all-86 {padding-top: 86px;}
.p-t-87, .p-tb-87, .p-all-87 {padding-top: 87px;}
.p-t-88, .p-tb-88, .p-all-88 {padding-top: 88px;}
.p-t-89, .p-tb-89, .p-all-89 {padding-top: 89px;}
.p-t-90, .p-tb-90, .p-all-90 {padding-top: 90px;}
.p-t-91, .p-tb-91, .p-all-91 {padding-top: 91px;}
.p-t-92, .p-tb-92, .p-all-92 {padding-top: 92px;}
.p-t-93, .p-tb-93, .p-all-93 {padding-top: 93px;}
.p-t-94, .p-tb-94, .p-all-94 {padding-top: 94px;}
.p-t-95, .p-tb-95, .p-all-95 {padding-top: 95px;}
.p-t-96, .p-tb-96, .p-all-96 {padding-top: 96px;}
.p-t-97, .p-tb-97, .p-all-97 {padding-top: 97px;}
.p-t-98, .p-tb-98, .p-all-98 {padding-top: 98px;}
.p-t-99, .p-tb-99, .p-all-99 {padding-top: 99px;}
.p-t-100, .p-tb-100, .p-all-100 {padding-top: 100px;}
.p-t-101, .p-tb-101, .p-all-101 {padding-top: 101px;}
.p-t-102, .p-tb-102, .p-all-102 {padding-top: 102px;}
.p-t-103, .p-tb-103, .p-all-103 {padding-top: 103px;}
.p-t-104, .p-tb-104, .p-all-104 {padding-top: 104px;}
.p-t-105, .p-tb-105, .p-all-105 {padding-top: 105px;}
.p-t-106, .p-tb-106, .p-all-106 {padding-top: 106px;}
.p-t-107, .p-tb-107, .p-all-107 {padding-top: 107px;}
.p-t-108, .p-tb-108, .p-all-108 {padding-top: 108px;}
.p-t-109, .p-tb-109, .p-all-109 {padding-top: 109px;}
.p-t-110, .p-tb-110, .p-all-110 {padding-top: 110px;}
.p-t-111, .p-tb-111, .p-all-111 {padding-top: 111px;}
.p-t-112, .p-tb-112, .p-all-112 {padding-top: 112px;}
.p-t-113, .p-tb-113, .p-all-113 {padding-top: 113px;}
.p-t-114, .p-tb-114, .p-all-114 {padding-top: 114px;}
.p-t-115, .p-tb-115, .p-all-115 {padding-top: 115px;}
.p-t-116, .p-tb-116, .p-all-116 {padding-top: 116px;}
.p-t-117, .p-tb-117, .p-all-117 {padding-top: 117px;}
.p-t-118, .p-tb-118, .p-all-118 {padding-top: 118px;}
.p-t-119, .p-tb-119, .p-all-119 {padding-top: 119px;}
.p-t-120, .p-tb-120, .p-all-120 {padding-top: 120px;}
.p-t-121, .p-tb-121, .p-all-121 {padding-top: 121px;}
.p-t-122, .p-tb-122, .p-all-122 {padding-top: 122px;}
.p-t-123, .p-tb-123, .p-all-123 {padding-top: 123px;}
.p-t-124, .p-tb-124, .p-all-124 {padding-top: 124px;}
.p-t-125, .p-tb-125, .p-all-125 {padding-top: 125px;}
.p-t-126, .p-tb-126, .p-all-126 {padding-top: 126px;}
.p-t-127, .p-tb-127, .p-all-127 {padding-top: 127px;}
.p-t-128, .p-tb-128, .p-all-128 {padding-top: 128px;}
.p-t-129, .p-tb-129, .p-all-129 {padding-top: 129px;}
.p-t-130, .p-tb-130, .p-all-130 {padding-top: 130px;}
.p-t-131, .p-tb-131, .p-all-131 {padding-top: 131px;}
.p-t-132, .p-tb-132, .p-all-132 {padding-top: 132px;}
.p-t-133, .p-tb-133, .p-all-133 {padding-top: 133px;}
.p-t-134, .p-tb-134, .p-all-134 {padding-top: 134px;}
.p-t-135, .p-tb-135, .p-all-135 {padding-top: 135px;}
.p-t-136, .p-tb-136, .p-all-136 {padding-top: 136px;}
.p-t-137, .p-tb-137, .p-all-137 {padding-top: 137px;}
.p-t-138, .p-tb-138, .p-all-138 {padding-top: 138px;}
.p-t-139, .p-tb-139, .p-all-139 {padding-top: 139px;}
.p-t-140, .p-tb-140, .p-all-140 {padding-top: 140px;}
.p-t-141, .p-tb-141, .p-all-141 {padding-top: 141px;}
.p-t-142, .p-tb-142, .p-all-142 {padding-top: 142px;}
.p-t-143, .p-tb-143, .p-all-143 {padding-top: 143px;}
.p-t-144, .p-tb-144, .p-all-144 {padding-top: 144px;}
.p-t-145, .p-tb-145, .p-all-145 {padding-top: 145px;}
.p-t-146, .p-tb-146, .p-all-146 {padding-top: 146px;}
.p-t-147, .p-tb-147, .p-all-147 {padding-top: 147px;}
.p-t-148, .p-tb-148, .p-all-148 {padding-top: 148px;}
.p-t-149, .p-tb-149, .p-all-149 {padding-top: 149px;}
.p-t-150, .p-tb-150, .p-all-150 {padding-top: 150px;}
.p-t-151, .p-tb-151, .p-all-151 {padding-top: 151px;}
.p-t-152, .p-tb-152, .p-all-152 {padding-top: 152px;}
.p-t-153, .p-tb-153, .p-all-153 {padding-top: 153px;}
.p-t-154, .p-tb-154, .p-all-154 {padding-top: 154px;}
.p-t-155, .p-tb-155, .p-all-155 {padding-top: 155px;}
.p-t-156, .p-tb-156, .p-all-156 {padding-top: 156px;}
.p-t-157, .p-tb-157, .p-all-157 {padding-top: 157px;}
.p-t-158, .p-tb-158, .p-all-158 {padding-top: 158px;}
.p-t-159, .p-tb-159, .p-all-159 {padding-top: 159px;}
.p-t-160, .p-tb-160, .p-all-160 {padding-top: 160px;}
.p-t-161, .p-tb-161, .p-all-161 {padding-top: 161px;}
.p-t-162, .p-tb-162, .p-all-162 {padding-top: 162px;}
.p-t-163, .p-tb-163, .p-all-163 {padding-top: 163px;}
.p-t-164, .p-tb-164, .p-all-164 {padding-top: 164px;}
.p-t-165, .p-tb-165, .p-all-165 {padding-top: 165px;}
.p-t-166, .p-tb-166, .p-all-166 {padding-top: 166px;}
.p-t-167, .p-tb-167, .p-all-167 {padding-top: 167px;}
.p-t-168, .p-tb-168, .p-all-168 {padding-top: 168px;}
.p-t-169, .p-tb-169, .p-all-169 {padding-top: 169px;}
.p-t-170, .p-tb-170, .p-all-170 {padding-top: 170px;}
.p-t-171, .p-tb-171, .p-all-171 {padding-top: 171px;}
.p-t-172, .p-tb-172, .p-all-172 {padding-top: 172px;}
.p-t-173, .p-tb-173, .p-all-173 {padding-top: 173px;}
.p-t-174, .p-tb-174, .p-all-174 {padding-top: 174px;}
.p-t-175, .p-tb-175, .p-all-175 {padding-top: 175px;}
.p-t-176, .p-tb-176, .p-all-176 {padding-top: 176px;}
.p-t-177, .p-tb-177, .p-all-177 {padding-top: 177px;}
.p-t-178, .p-tb-178, .p-all-178 {padding-top: 178px;}
.p-t-179, .p-tb-179, .p-all-179 {padding-top: 179px;}
.p-t-180, .p-tb-180, .p-all-180 {padding-top: 180px;}
.p-t-181, .p-tb-181, .p-all-181 {padding-top: 181px;}
.p-t-182, .p-tb-182, .p-all-182 {padding-top: 182px;}
.p-t-183, .p-tb-183, .p-all-183 {padding-top: 183px;}
.p-t-184, .p-tb-184, .p-all-184 {padding-top: 184px;}
.p-t-185, .p-tb-185, .p-all-185 {padding-top: 185px;}
.p-t-186, .p-tb-186, .p-all-186 {padding-top: 186px;}
.p-t-187, .p-tb-187, .p-all-187 {padding-top: 187px;}
.p-t-188, .p-tb-188, .p-all-188 {padding-top: 188px;}
.p-t-189, .p-tb-189, .p-all-189 {padding-top: 189px;}
.p-t-190, .p-tb-190, .p-all-190 {padding-top: 190px;}
.p-t-191, .p-tb-191, .p-all-191 {padding-top: 191px;}
.p-t-192, .p-tb-192, .p-all-192 {padding-top: 192px;}
.p-t-193, .p-tb-193, .p-all-193 {padding-top: 193px;}
.p-t-194, .p-tb-194, .p-all-194 {padding-top: 194px;}
.p-t-195, .p-tb-195, .p-all-195 {padding-top: 195px;}
.p-t-196, .p-tb-196, .p-all-196 {padding-top: 196px;}
.p-t-197, .p-tb-197, .p-all-197 {padding-top: 197px;}
.p-t-198, .p-tb-198, .p-all-198 {padding-top: 198px;}
.p-t-199, .p-tb-199, .p-all-199 {padding-top: 199px;}
.p-t-200, .p-tb-200, .p-all-200 {padding-top: 200px;}
.p-t-201, .p-tb-201, .p-all-201 {padding-top: 201px;}
.p-t-202, .p-tb-202, .p-all-202 {padding-top: 202px;}
.p-t-203, .p-tb-203, .p-all-203 {padding-top: 203px;}
.p-t-204, .p-tb-204, .p-all-204 {padding-top: 204px;}
.p-t-205, .p-tb-205, .p-all-205 {padding-top: 205px;}
.p-t-206, .p-tb-206, .p-all-206 {padding-top: 206px;}
.p-t-207, .p-tb-207, .p-all-207 {padding-top: 207px;}
.p-t-208, .p-tb-208, .p-all-208 {padding-top: 208px;}
.p-t-209, .p-tb-209, .p-all-209 {padding-top: 209px;}
.p-t-210, .p-tb-210, .p-all-210 {padding-top: 210px;}
.p-t-211, .p-tb-211, .p-all-211 {padding-top: 211px;}
.p-t-212, .p-tb-212, .p-all-212 {padding-top: 212px;}
.p-t-213, .p-tb-213, .p-all-213 {padding-top: 213px;}
.p-t-214, .p-tb-214, .p-all-214 {padding-top: 214px;}
.p-t-215, .p-tb-215, .p-all-215 {padding-top: 215px;}
.p-t-216, .p-tb-216, .p-all-216 {padding-top: 216px;}
.p-t-217, .p-tb-217, .p-all-217 {padding-top: 217px;}
.p-t-218, .p-tb-218, .p-all-218 {padding-top: 218px;}
.p-t-219, .p-tb-219, .p-all-219 {padding-top: 219px;}
.p-t-220, .p-tb-220, .p-all-220 {padding-top: 220px;}
.p-t-221, .p-tb-221, .p-all-221 {padding-top: 221px;}
.p-t-222, .p-tb-222, .p-all-222 {padding-top: 222px;}
.p-t-223, .p-tb-223, .p-all-223 {padding-top: 223px;}
.p-t-224, .p-tb-224, .p-all-224 {padding-top: 224px;}
.p-t-225, .p-tb-225, .p-all-225 {padding-top: 225px;}
.p-t-226, .p-tb-226, .p-all-226 {padding-top: 226px;}
.p-t-227, .p-tb-227, .p-all-227 {padding-top: 227px;}
.p-t-228, .p-tb-228, .p-all-228 {padding-top: 228px;}
.p-t-229, .p-tb-229, .p-all-229 {padding-top: 229px;}
.p-t-230, .p-tb-230, .p-all-230 {padding-top: 230px;}
.p-t-231, .p-tb-231, .p-all-231 {padding-top: 231px;}
.p-t-232, .p-tb-232, .p-all-232 {padding-top: 232px;}
.p-t-233, .p-tb-233, .p-all-233 {padding-top: 233px;}
.p-t-234, .p-tb-234, .p-all-234 {padding-top: 234px;}
.p-t-235, .p-tb-235, .p-all-235 {padding-top: 235px;}
.p-t-236, .p-tb-236, .p-all-236 {padding-top: 236px;}
.p-t-237, .p-tb-237, .p-all-237 {padding-top: 237px;}
.p-t-238, .p-tb-238, .p-all-238 {padding-top: 238px;}
.p-t-239, .p-tb-239, .p-all-239 {padding-top: 239px;}
.p-t-240, .p-tb-240, .p-all-240 {padding-top: 240px;}
.p-t-241, .p-tb-241, .p-all-241 {padding-top: 241px;}
.p-t-242, .p-tb-242, .p-all-242 {padding-top: 242px;}
.p-t-243, .p-tb-243, .p-all-243 {padding-top: 243px;}
.p-t-244, .p-tb-244, .p-all-244 {padding-top: 244px;}
.p-t-245, .p-tb-245, .p-all-245 {padding-top: 245px;}
.p-t-246, .p-tb-246, .p-all-246 {padding-top: 246px;}
.p-t-247, .p-tb-247, .p-all-247 {padding-top: 247px;}
.p-t-248, .p-tb-248, .p-all-248 {padding-top: 248px;}
.p-t-249, .p-tb-249, .p-all-249 {padding-top: 249px;}
.p-t-250, .p-tb-250, .p-all-250 {padding-top: 250px;}
.p-t-251, .p-tb-251, .p-all-251 {padding-top: 251px;}
.p-t-252, .p-tb-252, .p-all-252 {padding-top: 252px;}
.p-t-253, .p-tb-253, .p-all-253 {padding-top: 253px;}
.p-t-254, .p-tb-254, .p-all-254 {padding-top: 254px;}
.p-t-255, .p-tb-255, .p-all-255 {padding-top: 255px;}
.p-t-256, .p-tb-256, .p-all-256 {padding-top: 256px;}
.p-t-257, .p-tb-257, .p-all-257 {padding-top: 257px;}
.p-t-258, .p-tb-258, .p-all-258 {padding-top: 258px;}
.p-t-259, .p-tb-259, .p-all-259 {padding-top: 259px;}
.p-t-260, .p-tb-260, .p-all-260 {padding-top: 260px;}
.p-t-261, .p-tb-261, .p-all-261 {padding-top: 261px;}
.p-t-262, .p-tb-262, .p-all-262 {padding-top: 262px;}
.p-t-263, .p-tb-263, .p-all-263 {padding-top: 263px;}
.p-t-264, .p-tb-264, .p-all-264 {padding-top: 264px;}
.p-t-265, .p-tb-265, .p-all-265 {padding-top: 265px;}
.p-t-266, .p-tb-266, .p-all-266 {padding-top: 266px;}
.p-t-267, .p-tb-267, .p-all-267 {padding-top: 267px;}
.p-t-268, .p-tb-268, .p-all-268 {padding-top: 268px;}
.p-t-269, .p-tb-269, .p-all-269 {padding-top: 269px;}
.p-t-270, .p-tb-270, .p-all-270 {padding-top: 270px;}
.p-t-271, .p-tb-271, .p-all-271 {padding-top: 271px;}
.p-t-272, .p-tb-272, .p-all-272 {padding-top: 272px;}
.p-t-273, .p-tb-273, .p-all-273 {padding-top: 273px;}
.p-t-274, .p-tb-274, .p-all-274 {padding-top: 274px;}
.p-t-275, .p-tb-275, .p-all-275 {padding-top: 275px;}
.p-t-276, .p-tb-276, .p-all-276 {padding-top: 276px;}
.p-t-277, .p-tb-277, .p-all-277 {padding-top: 277px;}
.p-t-278, .p-tb-278, .p-all-278 {padding-top: 278px;}
.p-t-279, .p-tb-279, .p-all-279 {padding-top: 279px;}
.p-t-280, .p-tb-280, .p-all-280 {padding-top: 280px;}
.p-t-281, .p-tb-281, .p-all-281 {padding-top: 281px;}
.p-t-282, .p-tb-282, .p-all-282 {padding-top: 282px;}
.p-t-283, .p-tb-283, .p-all-283 {padding-top: 283px;}
.p-t-284, .p-tb-284, .p-all-284 {padding-top: 284px;}
.p-t-285, .p-tb-285, .p-all-285 {padding-top: 285px;}
.p-t-286, .p-tb-286, .p-all-286 {padding-top: 286px;}
.p-t-287, .p-tb-287, .p-all-287 {padding-top: 287px;}
.p-t-288, .p-tb-288, .p-all-288 {padding-top: 288px;}
.p-t-289, .p-tb-289, .p-all-289 {padding-top: 289px;}
.p-t-290, .p-tb-290, .p-all-290 {padding-top: 290px;}
.p-t-291, .p-tb-291, .p-all-291 {padding-top: 291px;}
.p-t-292, .p-tb-292, .p-all-292 {padding-top: 292px;}
.p-t-293, .p-tb-293, .p-all-293 {padding-top: 293px;}
.p-t-294, .p-tb-294, .p-all-294 {padding-top: 294px;}
.p-t-295, .p-tb-295, .p-all-295 {padding-top: 295px;}
.p-t-296, .p-tb-296, .p-all-296 {padding-top: 296px;}
.p-t-297, .p-tb-297, .p-all-297 {padding-top: 297px;}
.p-t-298, .p-tb-298, .p-all-298 {padding-top: 298px;}
.p-t-299, .p-tb-299, .p-all-299 {padding-top: 299px;}
.p-t-300, .p-tb-300, .p-all-300 {padding-top: 300px;}
.p-b-0, .p-tb-0, .p-all-0 {padding-bottom: 0px;}
.p-b-1, .p-tb-1, .p-all-1 {padding-bottom: 1px;}
.p-b-2, .p-tb-2, .p-all-2 {padding-bottom: 2px;}
.p-b-3, .p-tb-3, .p-all-3 {padding-bottom: 3px;}
.p-b-4, .p-tb-4, .p-all-4 {padding-bottom: 4px;}
.p-b-5, .p-tb-5, .p-all-5 {padding-bottom: 5px;}
.p-b-6, .p-tb-6, .p-all-6 {padding-bottom: 6px;}
.p-b-7, .p-tb-7, .p-all-7 {padding-bottom: 7px;}
.p-b-8, .p-tb-8, .p-all-8 {padding-bottom: 8px;}
.p-b-9, .p-tb-9, .p-all-9 {padding-bottom: 9px;}
.p-b-10, .p-tb-10, .p-all-10 {padding-bottom: 10px;}
.p-b-11, .p-tb-11, .p-all-11 {padding-bottom: 11px;}
.p-b-12, .p-tb-12, .p-all-12 {padding-bottom: 12px;}
.p-b-13, .p-tb-13, .p-all-13 {padding-bottom: 13px;}
.p-b-14, .p-tb-14, .p-all-14 {padding-bottom: 14px;}
.p-b-15, .p-tb-15, .p-all-15 {padding-bottom: 15px;}
.p-b-16, .p-tb-16, .p-all-16 {padding-bottom: 16px;}
.p-b-17, .p-tb-17, .p-all-17 {padding-bottom: 17px;}
.p-b-18, .p-tb-18, .p-all-18 {padding-bottom: 18px;}
.p-b-19, .p-tb-19, .p-all-19 {padding-bottom: 19px;}
.p-b-20, .p-tb-20, .p-all-20 {padding-bottom: 20px;}
.p-b-21, .p-tb-21, .p-all-21 {padding-bottom: 21px;}
.p-b-22, .p-tb-22, .p-all-22 {padding-bottom: 22px;}
.p-b-23, .p-tb-23, .p-all-23 {padding-bottom: 23px;}
.p-b-24, .p-tb-24, .p-all-24 {padding-bottom: 24px;}
.p-b-25, .p-tb-25, .p-all-25 {padding-bottom: 25px;}
.p-b-26, .p-tb-26, .p-all-26 {padding-bottom: 26px;}
.p-b-27, .p-tb-27, .p-all-27 {padding-bottom: 27px;}
.p-b-28, .p-tb-28, .p-all-28 {padding-bottom: 28px;}
.p-b-29, .p-tb-29, .p-all-29 {padding-bottom: 29px;}
.p-b-30, .p-tb-30, .p-all-30 {padding-bottom: 30px;}
.p-b-31, .p-tb-31, .p-all-31 {padding-bottom: 31px;}
.p-b-32, .p-tb-32, .p-all-32 {padding-bottom: 32px;}
.p-b-33, .p-tb-33, .p-all-33 {padding-bottom: 33px;}
.p-b-34, .p-tb-34, .p-all-34 {padding-bottom: 34px;}
.p-b-35, .p-tb-35, .p-all-35 {padding-bottom: 35px;}
.p-b-36, .p-tb-36, .p-all-36 {padding-bottom: 36px;}
.p-b-37, .p-tb-37, .p-all-37 {padding-bottom: 37px;}
.p-b-38, .p-tb-38, .p-all-38 {padding-bottom: 38px;}
.p-b-39, .p-tb-39, .p-all-39 {padding-bottom: 39px;}
.p-b-40, .p-tb-40, .p-all-40 {padding-bottom: 40px;}
.p-b-41, .p-tb-41, .p-all-41 {padding-bottom: 41px;}
.p-b-42, .p-tb-42, .p-all-42 {padding-bottom: 42px;}
.p-b-43, .p-tb-43, .p-all-43 {padding-bottom: 43px;}
.p-b-44, .p-tb-44, .p-all-44 {padding-bottom: 44px;}
.p-b-45, .p-tb-45, .p-all-45 {padding-bottom: 45px;}
.p-b-46, .p-tb-46, .p-all-46 {padding-bottom: 46px;}
.p-b-47, .p-tb-47, .p-all-47 {padding-bottom: 47px;}
.p-b-48, .p-tb-48, .p-all-48 {padding-bottom: 48px;}
.p-b-49, .p-tb-49, .p-all-49 {padding-bottom: 49px;}
.p-b-50, .p-tb-50, .p-all-50 {padding-bottom: 50px;}
.p-b-51, .p-tb-51, .p-all-51 {padding-bottom: 51px;}
.p-b-52, .p-tb-52, .p-all-52 {padding-bottom: 52px;}
.p-b-53, .p-tb-53, .p-all-53 {padding-bottom: 53px;}
.p-b-54, .p-tb-54, .p-all-54 {padding-bottom: 54px;}
.p-b-55, .p-tb-55, .p-all-55 {padding-bottom: 55px;}
.p-b-56, .p-tb-56, .p-all-56 {padding-bottom: 56px;}
.p-b-57, .p-tb-57, .p-all-57 {padding-bottom: 57px;}
.p-b-58, .p-tb-58, .p-all-58 {padding-bottom: 58px;}
.p-b-59, .p-tb-59, .p-all-59 {padding-bottom: 59px;}
.p-b-60, .p-tb-60, .p-all-60 {padding-bottom: 60px;}
.p-b-61, .p-tb-61, .p-all-61 {padding-bottom: 61px;}
.p-b-62, .p-tb-62, .p-all-62 {padding-bottom: 62px;}
.p-b-63, .p-tb-63, .p-all-63 {padding-bottom: 63px;}
.p-b-64, .p-tb-64, .p-all-64 {padding-bottom: 64px;}
.p-b-65, .p-tb-65, .p-all-65 {padding-bottom: 65px;}
.p-b-66, .p-tb-66, .p-all-66 {padding-bottom: 66px;}
.p-b-67, .p-tb-67, .p-all-67 {padding-bottom: 67px;}
.p-b-68, .p-tb-68, .p-all-68 {padding-bottom: 68px;}
.p-b-69, .p-tb-69, .p-all-69 {padding-bottom: 69px;}
.p-b-70, .p-tb-70, .p-all-70 {padding-bottom: 70px;}
.p-b-71, .p-tb-71, .p-all-71 {padding-bottom: 71px;}
.p-b-72, .p-tb-72, .p-all-72 {padding-bottom: 72px;}
.p-b-73, .p-tb-73, .p-all-73 {padding-bottom: 73px;}
.p-b-74, .p-tb-74, .p-all-74 {padding-bottom: 74px;}
.p-b-75, .p-tb-75, .p-all-75 {padding-bottom: 75px;}
.p-b-76, .p-tb-76, .p-all-76 {padding-bottom: 76px;}
.p-b-77, .p-tb-77, .p-all-77 {padding-bottom: 77px;}
.p-b-78, .p-tb-78, .p-all-78 {padding-bottom: 78px;}
.p-b-79, .p-tb-79, .p-all-79 {padding-bottom: 79px;}
.p-b-80, .p-tb-80, .p-all-80 {padding-bottom: 80px;}
.p-b-81, .p-tb-81, .p-all-81 {padding-bottom: 81px;}
.p-b-82, .p-tb-82, .p-all-82 {padding-bottom: 82px;}
.p-b-83, .p-tb-83, .p-all-83 {padding-bottom: 83px;}
.p-b-84, .p-tb-84, .p-all-84 {padding-bottom: 84px;}
.p-b-85, .p-tb-85, .p-all-85 {padding-bottom: 85px;}
.p-b-86, .p-tb-86, .p-all-86 {padding-bottom: 86px;}
.p-b-87, .p-tb-87, .p-all-87 {padding-bottom: 87px;}
.p-b-88, .p-tb-88, .p-all-88 {padding-bottom: 88px;}
.p-b-89, .p-tb-89, .p-all-89 {padding-bottom: 89px;}
.p-b-90, .p-tb-90, .p-all-90 {padding-bottom: 90px;}
.p-b-91, .p-tb-91, .p-all-91 {padding-bottom: 91px;}
.p-b-92, .p-tb-92, .p-all-92 {padding-bottom: 92px;}
.p-b-93, .p-tb-93, .p-all-93 {padding-bottom: 93px;}
.p-b-94, .p-tb-94, .p-all-94 {padding-bottom: 94px;}
.p-b-95, .p-tb-95, .p-all-95 {padding-bottom: 95px;}
.p-b-96, .p-tb-96, .p-all-96 {padding-bottom: 96px;}
.p-b-97, .p-tb-97, .p-all-97 {padding-bottom: 97px;}
.p-b-98, .p-tb-98, .p-all-98 {padding-bottom: 98px;}
.p-b-99, .p-tb-99, .p-all-99 {padding-bottom: 99px;}
.p-b-100, .p-tb-100, .p-all-100 {padding-bottom: 100px;}
.p-b-101, .p-tb-101, .p-all-101 {padding-bottom: 101px;}
.p-b-102, .p-tb-102, .p-all-102 {padding-bottom: 102px;}
.p-b-103, .p-tb-103, .p-all-103 {padding-bottom: 103px;}
.p-b-104, .p-tb-104, .p-all-104 {padding-bottom: 104px;}
.p-b-105, .p-tb-105, .p-all-105 {padding-bottom: 105px;}
.p-b-106, .p-tb-106, .p-all-106 {padding-bottom: 106px;}
.p-b-107, .p-tb-107, .p-all-107 {padding-bottom: 107px;}
.p-b-108, .p-tb-108, .p-all-108 {padding-bottom: 108px;}
.p-b-109, .p-tb-109, .p-all-109 {padding-bottom: 109px;}
.p-b-110, .p-tb-110, .p-all-110 {padding-bottom: 110px;}
.p-b-111, .p-tb-111, .p-all-111 {padding-bottom: 111px;}
.p-b-112, .p-tb-112, .p-all-112 {padding-bottom: 112px;}
.p-b-113, .p-tb-113, .p-all-113 {padding-bottom: 113px;}
.p-b-114, .p-tb-114, .p-all-114 {padding-bottom: 114px;}
.p-b-115, .p-tb-115, .p-all-115 {padding-bottom: 115px;}
.p-b-116, .p-tb-116, .p-all-116 {padding-bottom: 116px;}
.p-b-117, .p-tb-117, .p-all-117 {padding-bottom: 117px;}
.p-b-118, .p-tb-118, .p-all-118 {padding-bottom: 118px;}
.p-b-119, .p-tb-119, .p-all-119 {padding-bottom: 119px;}
.p-b-120, .p-tb-120, .p-all-120 {padding-bottom: 120px;}
.p-b-121, .p-tb-121, .p-all-121 {padding-bottom: 121px;}
.p-b-122, .p-tb-122, .p-all-122 {padding-bottom: 122px;}
.p-b-123, .p-tb-123, .p-all-123 {padding-bottom: 123px;}
.p-b-124, .p-tb-124, .p-all-124 {padding-bottom: 124px;}
.p-b-125, .p-tb-125, .p-all-125 {padding-bottom: 125px;}
.p-b-126, .p-tb-126, .p-all-126 {padding-bottom: 126px;}
.p-b-127, .p-tb-127, .p-all-127 {padding-bottom: 127px;}
.p-b-128, .p-tb-128, .p-all-128 {padding-bottom: 128px;}
.p-b-129, .p-tb-129, .p-all-129 {padding-bottom: 129px;}
.p-b-130, .p-tb-130, .p-all-130 {padding-bottom: 130px;}
.p-b-131, .p-tb-131, .p-all-131 {padding-bottom: 131px;}
.p-b-132, .p-tb-132, .p-all-132 {padding-bottom: 132px;}
.p-b-133, .p-tb-133, .p-all-133 {padding-bottom: 133px;}
.p-b-134, .p-tb-134, .p-all-134 {padding-bottom: 134px;}
.p-b-135, .p-tb-135, .p-all-135 {padding-bottom: 135px;}
.p-b-136, .p-tb-136, .p-all-136 {padding-bottom: 136px;}
.p-b-137, .p-tb-137, .p-all-137 {padding-bottom: 137px;}
.p-b-138, .p-tb-138, .p-all-138 {padding-bottom: 138px;}
.p-b-139, .p-tb-139, .p-all-139 {padding-bottom: 139px;}
.p-b-140, .p-tb-140, .p-all-140 {padding-bottom: 140px;}
.p-b-141, .p-tb-141, .p-all-141 {padding-bottom: 141px;}
.p-b-142, .p-tb-142, .p-all-142 {padding-bottom: 142px;}
.p-b-143, .p-tb-143, .p-all-143 {padding-bottom: 143px;}
.p-b-144, .p-tb-144, .p-all-144 {padding-bottom: 144px;}
.p-b-145, .p-tb-145, .p-all-145 {padding-bottom: 145px;}
.p-b-146, .p-tb-146, .p-all-146 {padding-bottom: 146px;}
.p-b-147, .p-tb-147, .p-all-147 {padding-bottom: 147px;}
.p-b-148, .p-tb-148, .p-all-148 {padding-bottom: 148px;}
.p-b-149, .p-tb-149, .p-all-149 {padding-bottom: 149px;}
.p-b-150, .p-tb-150, .p-all-150 {padding-bottom: 150px;}
.p-b-151, .p-tb-151, .p-all-151 {padding-bottom: 151px;}
.p-b-152, .p-tb-152, .p-all-152 {padding-bottom: 152px;}
.p-b-153, .p-tb-153, .p-all-153 {padding-bottom: 153px;}
.p-b-154, .p-tb-154, .p-all-154 {padding-bottom: 154px;}
.p-b-155, .p-tb-155, .p-all-155 {padding-bottom: 155px;}
.p-b-156, .p-tb-156, .p-all-156 {padding-bottom: 156px;}
.p-b-157, .p-tb-157, .p-all-157 {padding-bottom: 157px;}
.p-b-158, .p-tb-158, .p-all-158 {padding-bottom: 158px;}
.p-b-159, .p-tb-159, .p-all-159 {padding-bottom: 159px;}
.p-b-160, .p-tb-160, .p-all-160 {padding-bottom: 160px;}
.p-b-161, .p-tb-161, .p-all-161 {padding-bottom: 161px;}
.p-b-162, .p-tb-162, .p-all-162 {padding-bottom: 162px;}
.p-b-163, .p-tb-163, .p-all-163 {padding-bottom: 163px;}
.p-b-164, .p-tb-164, .p-all-164 {padding-bottom: 164px;}
.p-b-165, .p-tb-165, .p-all-165 {padding-bottom: 165px;}
.p-b-166, .p-tb-166, .p-all-166 {padding-bottom: 166px;}
.p-b-167, .p-tb-167, .p-all-167 {padding-bottom: 167px;}
.p-b-168, .p-tb-168, .p-all-168 {padding-bottom: 168px;}
.p-b-169, .p-tb-169, .p-all-169 {padding-bottom: 169px;}
.p-b-170, .p-tb-170, .p-all-170 {padding-bottom: 170px;}
.p-b-171, .p-tb-171, .p-all-171 {padding-bottom: 171px;}
.p-b-172, .p-tb-172, .p-all-172 {padding-bottom: 172px;}
.p-b-173, .p-tb-173, .p-all-173 {padding-bottom: 173px;}
.p-b-174, .p-tb-174, .p-all-174 {padding-bottom: 174px;}
.p-b-175, .p-tb-175, .p-all-175 {padding-bottom: 175px;}
.p-b-176, .p-tb-176, .p-all-176 {padding-bottom: 176px;}
.p-b-177, .p-tb-177, .p-all-177 {padding-bottom: 177px;}
.p-b-178, .p-tb-178, .p-all-178 {padding-bottom: 178px;}
.p-b-179, .p-tb-179, .p-all-179 {padding-bottom: 179px;}
.p-b-180, .p-tb-180, .p-all-180 {padding-bottom: 180px;}
.p-b-181, .p-tb-181, .p-all-181 {padding-bottom: 181px;}
.p-b-182, .p-tb-182, .p-all-182 {padding-bottom: 182px;}
.p-b-183, .p-tb-183, .p-all-183 {padding-bottom: 183px;}
.p-b-184, .p-tb-184, .p-all-184 {padding-bottom: 184px;}
.p-b-185, .p-tb-185, .p-all-185 {padding-bottom: 185px;}
.p-b-186, .p-tb-186, .p-all-186 {padding-bottom: 186px;}
.p-b-187, .p-tb-187, .p-all-187 {padding-bottom: 187px;}
.p-b-188, .p-tb-188, .p-all-188 {padding-bottom: 188px;}
.p-b-189, .p-tb-189, .p-all-189 {padding-bottom: 189px;}
.p-b-190, .p-tb-190, .p-all-190 {padding-bottom: 190px;}
.p-b-191, .p-tb-191, .p-all-191 {padding-bottom: 191px;}
.p-b-192, .p-tb-192, .p-all-192 {padding-bottom: 192px;}
.p-b-193, .p-tb-193, .p-all-193 {padding-bottom: 193px;}
.p-b-194, .p-tb-194, .p-all-194 {padding-bottom: 194px;}
.p-b-195, .p-tb-195, .p-all-195 {padding-bottom: 195px;}
.p-b-196, .p-tb-196, .p-all-196 {padding-bottom: 196px;}
.p-b-197, .p-tb-197, .p-all-197 {padding-bottom: 197px;}
.p-b-198, .p-tb-198, .p-all-198 {padding-bottom: 198px;}
.p-b-199, .p-tb-199, .p-all-199 {padding-bottom: 199px;}
.p-b-200, .p-tb-200, .p-all-200 {padding-bottom: 200px;}
.p-b-201, .p-tb-201, .p-all-201 {padding-bottom: 201px;}
.p-b-202, .p-tb-202, .p-all-202 {padding-bottom: 202px;}
.p-b-203, .p-tb-203, .p-all-203 {padding-bottom: 203px;}
.p-b-204, .p-tb-204, .p-all-204 {padding-bottom: 204px;}
.p-b-205, .p-tb-205, .p-all-205 {padding-bottom: 205px;}
.p-b-206, .p-tb-206, .p-all-206 {padding-bottom: 206px;}
.p-b-207, .p-tb-207, .p-all-207 {padding-bottom: 207px;}
.p-b-208, .p-tb-208, .p-all-208 {padding-bottom: 208px;}
.p-b-209, .p-tb-209, .p-all-209 {padding-bottom: 209px;}
.p-b-210, .p-tb-210, .p-all-210 {padding-bottom: 210px;}
.p-b-211, .p-tb-211, .p-all-211 {padding-bottom: 211px;}
.p-b-212, .p-tb-212, .p-all-212 {padding-bottom: 212px;}
.p-b-213, .p-tb-213, .p-all-213 {padding-bottom: 213px;}
.p-b-214, .p-tb-214, .p-all-214 {padding-bottom: 214px;}
.p-b-215, .p-tb-215, .p-all-215 {padding-bottom: 215px;}
.p-b-216, .p-tb-216, .p-all-216 {padding-bottom: 216px;}
.p-b-217, .p-tb-217, .p-all-217 {padding-bottom: 217px;}
.p-b-218, .p-tb-218, .p-all-218 {padding-bottom: 218px;}
.p-b-219, .p-tb-219, .p-all-219 {padding-bottom: 219px;}
.p-b-220, .p-tb-220, .p-all-220 {padding-bottom: 220px;}
.p-b-221, .p-tb-221, .p-all-221 {padding-bottom: 221px;}
.p-b-222, .p-tb-222, .p-all-222 {padding-bottom: 222px;}
.p-b-223, .p-tb-223, .p-all-223 {padding-bottom: 223px;}
.p-b-224, .p-tb-224, .p-all-224 {padding-bottom: 224px;}
.p-b-225, .p-tb-225, .p-all-225 {padding-bottom: 225px;}
.p-b-226, .p-tb-226, .p-all-226 {padding-bottom: 226px;}
.p-b-227, .p-tb-227, .p-all-227 {padding-bottom: 227px;}
.p-b-228, .p-tb-228, .p-all-228 {padding-bottom: 228px;}
.p-b-229, .p-tb-229, .p-all-229 {padding-bottom: 229px;}
.p-b-230, .p-tb-230, .p-all-230 {padding-bottom: 230px;}
.p-b-231, .p-tb-231, .p-all-231 {padding-bottom: 231px;}
.p-b-232, .p-tb-232, .p-all-232 {padding-bottom: 232px;}
.p-b-233, .p-tb-233, .p-all-233 {padding-bottom: 233px;}
.p-b-234, .p-tb-234, .p-all-234 {padding-bottom: 234px;}
.p-b-235, .p-tb-235, .p-all-235 {padding-bottom: 235px;}
.p-b-236, .p-tb-236, .p-all-236 {padding-bottom: 236px;}
.p-b-237, .p-tb-237, .p-all-237 {padding-bottom: 237px;}
.p-b-238, .p-tb-238, .p-all-238 {padding-bottom: 238px;}
.p-b-239, .p-tb-239, .p-all-239 {padding-bottom: 239px;}
.p-b-240, .p-tb-240, .p-all-240 {padding-bottom: 240px;}
.p-b-241, .p-tb-241, .p-all-241 {padding-bottom: 241px;}
.p-b-242, .p-tb-242, .p-all-242 {padding-bottom: 242px;}
.p-b-243, .p-tb-243, .p-all-243 {padding-bottom: 243px;}
.p-b-244, .p-tb-244, .p-all-244 {padding-bottom: 244px;}
.p-b-245, .p-tb-245, .p-all-245 {padding-bottom: 245px;}
.p-b-246, .p-tb-246, .p-all-246 {padding-bottom: 246px;}
.p-b-247, .p-tb-247, .p-all-247 {padding-bottom: 247px;}
.p-b-248, .p-tb-248, .p-all-248 {padding-bottom: 248px;}
.p-b-249, .p-tb-249, .p-all-249 {padding-bottom: 249px;}
.p-b-250, .p-tb-250, .p-all-250 {padding-bottom: 250px;}
.p-b-251, .p-tb-251, .p-all-251 {padding-bottom: 251px;}
.p-b-252, .p-tb-252, .p-all-252 {padding-bottom: 252px;}
.p-b-253, .p-tb-253, .p-all-253 {padding-bottom: 253px;}
.p-b-254, .p-tb-254, .p-all-254 {padding-bottom: 254px;}
.p-b-255, .p-tb-255, .p-all-255 {padding-bottom: 255px;}
.p-b-256, .p-tb-256, .p-all-256 {padding-bottom: 256px;}
.p-b-257, .p-tb-257, .p-all-257 {padding-bottom: 257px;}
.p-b-258, .p-tb-258, .p-all-258 {padding-bottom: 258px;}
.p-b-259, .p-tb-259, .p-all-259 {padding-bottom: 259px;}
.p-b-260, .p-tb-260, .p-all-260 {padding-bottom: 260px;}
.p-b-261, .p-tb-261, .p-all-261 {padding-bottom: 261px;}
.p-b-262, .p-tb-262, .p-all-262 {padding-bottom: 262px;}
.p-b-263, .p-tb-263, .p-all-263 {padding-bottom: 263px;}
.p-b-264, .p-tb-264, .p-all-264 {padding-bottom: 264px;}
.p-b-265, .p-tb-265, .p-all-265 {padding-bottom: 265px;}
.p-b-266, .p-tb-266, .p-all-266 {padding-bottom: 266px;}
.p-b-267, .p-tb-267, .p-all-267 {padding-bottom: 267px;}
.p-b-268, .p-tb-268, .p-all-268 {padding-bottom: 268px;}
.p-b-269, .p-tb-269, .p-all-269 {padding-bottom: 269px;}
.p-b-270, .p-tb-270, .p-all-270 {padding-bottom: 270px;}
.p-b-271, .p-tb-271, .p-all-271 {padding-bottom: 271px;}
.p-b-272, .p-tb-272, .p-all-272 {padding-bottom: 272px;}
.p-b-273, .p-tb-273, .p-all-273 {padding-bottom: 273px;}
.p-b-274, .p-tb-274, .p-all-274 {padding-bottom: 274px;}
.p-b-275, .p-tb-275, .p-all-275 {padding-bottom: 275px;}
.p-b-276, .p-tb-276, .p-all-276 {padding-bottom: 276px;}
.p-b-277, .p-tb-277, .p-all-277 {padding-bottom: 277px;}
.p-b-278, .p-tb-278, .p-all-278 {padding-bottom: 278px;}
.p-b-279, .p-tb-279, .p-all-279 {padding-bottom: 279px;}
.p-b-280, .p-tb-280, .p-all-280 {padding-bottom: 280px;}
.p-b-281, .p-tb-281, .p-all-281 {padding-bottom: 281px;}
.p-b-282, .p-tb-282, .p-all-282 {padding-bottom: 282px;}
.p-b-283, .p-tb-283, .p-all-283 {padding-bottom: 283px;}
.p-b-284, .p-tb-284, .p-all-284 {padding-bottom: 284px;}
.p-b-285, .p-tb-285, .p-all-285 {padding-bottom: 285px;}
.p-b-286, .p-tb-286, .p-all-286 {padding-bottom: 286px;}
.p-b-287, .p-tb-287, .p-all-287 {padding-bottom: 287px;}
.p-b-288, .p-tb-288, .p-all-288 {padding-bottom: 288px;}
.p-b-289, .p-tb-289, .p-all-289 {padding-bottom: 289px;}
.p-b-290, .p-tb-290, .p-all-290 {padding-bottom: 290px;}
.p-b-291, .p-tb-291, .p-all-291 {padding-bottom: 291px;}
.p-b-292, .p-tb-292, .p-all-292 {padding-bottom: 292px;}
.p-b-293, .p-tb-293, .p-all-293 {padding-bottom: 293px;}
.p-b-294, .p-tb-294, .p-all-294 {padding-bottom: 294px;}
.p-b-295, .p-tb-295, .p-all-295 {padding-bottom: 295px;}
.p-b-296, .p-tb-296, .p-all-296 {padding-bottom: 296px;}
.p-b-297, .p-tb-297, .p-all-297 {padding-bottom: 297px;}
.p-b-298, .p-tb-298, .p-all-298 {padding-bottom: 298px;}
.p-b-299, .p-tb-299, .p-all-299 {padding-bottom: 299px;}
.p-b-300, .p-tb-300, .p-all-300 {padding-bottom: 300px;}
.p-l-0, .p-lr-0, .p-all-0 {padding-left: 0px;}
.p-l-1, .p-lr-1, .p-all-1 {padding-left: 1px;}
.p-l-2, .p-lr-2, .p-all-2 {padding-left: 2px;}
.p-l-3, .p-lr-3, .p-all-3 {padding-left: 3px;}
.p-l-4, .p-lr-4, .p-all-4 {padding-left: 4px;}
.p-l-5, .p-lr-5, .p-all-5 {padding-left: 5px;}
.p-l-6, .p-lr-6, .p-all-6 {padding-left: 6px;}
.p-l-7, .p-lr-7, .p-all-7 {padding-left: 7px;}
.p-l-8, .p-lr-8, .p-all-8 {padding-left: 8px;}
.p-l-9, .p-lr-9, .p-all-9 {padding-left: 9px;}
.p-l-10, .p-lr-10, .p-all-10 {padding-left: 10px;}
.p-l-11, .p-lr-11, .p-all-11 {padding-left: 11px;}
.p-l-12, .p-lr-12, .p-all-12 {padding-left: 12px;}
.p-l-13, .p-lr-13, .p-all-13 {padding-left: 13px;}
.p-l-14, .p-lr-14, .p-all-14 {padding-left: 14px;}
.p-l-15, .p-lr-15, .p-all-15 {padding-left: 15px;}
.p-l-16, .p-lr-16, .p-all-16 {padding-left: 16px;}
.p-l-17, .p-lr-17, .p-all-17 {padding-left: 17px;}
.p-l-18, .p-lr-18, .p-all-18 {padding-left: 18px;}
.p-l-19, .p-lr-19, .p-all-19 {padding-left: 19px;}
.p-l-20, .p-lr-20, .p-all-20 {padding-left: 20px;}
.p-l-21, .p-lr-21, .p-all-21 {padding-left: 21px;}
.p-l-22, .p-lr-22, .p-all-22 {padding-left: 22px;}
.p-l-23, .p-lr-23, .p-all-23 {padding-left: 23px;}
.p-l-24, .p-lr-24, .p-all-24 {padding-left: 24px;}
.p-l-25, .p-lr-25, .p-all-25 {padding-left: 25px;}
.p-l-26, .p-lr-26, .p-all-26 {padding-left: 26px;}
.p-l-27, .p-lr-27, .p-all-27 {padding-left: 27px;}
.p-l-28, .p-lr-28, .p-all-28 {padding-left: 28px;}
.p-l-29, .p-lr-29, .p-all-29 {padding-left: 29px;}
.p-l-30, .p-lr-30, .p-all-30 {padding-left: 30px;}
.p-l-31, .p-lr-31, .p-all-31 {padding-left: 31px;}
.p-l-32, .p-lr-32, .p-all-32 {padding-left: 32px;}
.p-l-33, .p-lr-33, .p-all-33 {padding-left: 33px;}
.p-l-34, .p-lr-34, .p-all-34 {padding-left: 34px;}
.p-l-35, .p-lr-35, .p-all-35 {padding-left: 35px;}
.p-l-36, .p-lr-36, .p-all-36 {padding-left: 36px;}
.p-l-37, .p-lr-37, .p-all-37 {padding-left: 37px;}
.p-l-38, .p-lr-38, .p-all-38 {padding-left: 38px;}
.p-l-39, .p-lr-39, .p-all-39 {padding-left: 39px;}
.p-l-40, .p-lr-40, .p-all-40 {padding-left: 40px;}
.p-l-41, .p-lr-41, .p-all-41 {padding-left: 41px;}
.p-l-42, .p-lr-42, .p-all-42 {padding-left: 42px;}
.p-l-43, .p-lr-43, .p-all-43 {padding-left: 43px;}
.p-l-44, .p-lr-44, .p-all-44 {padding-left: 44px;}
.p-l-45, .p-lr-45, .p-all-45 {padding-left: 45px;}
.p-l-46, .p-lr-46, .p-all-46 {padding-left: 46px;}
.p-l-47, .p-lr-47, .p-all-47 {padding-left: 47px;}
.p-l-48, .p-lr-48, .p-all-48 {padding-left: 48px;}
.p-l-49, .p-lr-49, .p-all-49 {padding-left: 49px;}
.p-l-50, .p-lr-50, .p-all-50 {padding-left: 50px;}
.p-l-51, .p-lr-51, .p-all-51 {padding-left: 51px;}
.p-l-52, .p-lr-52, .p-all-52 {padding-left: 52px;}
.p-l-53, .p-lr-53, .p-all-53 {padding-left: 53px;}
.p-l-54, .p-lr-54, .p-all-54 {padding-left: 54px;}
.p-l-55, .p-lr-55, .p-all-55 {padding-left: 55px;}
.p-l-56, .p-lr-56, .p-all-56 {padding-left: 56px;}
.p-l-57, .p-lr-57, .p-all-57 {padding-left: 57px;}
.p-l-58, .p-lr-58, .p-all-58 {padding-left: 58px;}
.p-l-59, .p-lr-59, .p-all-59 {padding-left: 59px;}
.p-l-60, .p-lr-60, .p-all-60 {padding-left: 60px;}
.p-l-61, .p-lr-61, .p-all-61 {padding-left: 61px;}
.p-l-62, .p-lr-62, .p-all-62 {padding-left: 62px;}
.p-l-63, .p-lr-63, .p-all-63 {padding-left: 63px;}
.p-l-64, .p-lr-64, .p-all-64 {padding-left: 64px;}
.p-l-65, .p-lr-65, .p-all-65 {padding-left: 65px;}
.p-l-66, .p-lr-66, .p-all-66 {padding-left: 66px;}
.p-l-67, .p-lr-67, .p-all-67 {padding-left: 67px;}
.p-l-68, .p-lr-68, .p-all-68 {padding-left: 68px;}
.p-l-69, .p-lr-69, .p-all-69 {padding-left: 69px;}
.p-l-70, .p-lr-70, .p-all-70 {padding-left: 70px;}
.p-l-71, .p-lr-71, .p-all-71 {padding-left: 71px;}
.p-l-72, .p-lr-72, .p-all-72 {padding-left: 72px;}
.p-l-73, .p-lr-73, .p-all-73 {padding-left: 73px;}
.p-l-74, .p-lr-74, .p-all-74 {padding-left: 74px;}
.p-l-75, .p-lr-75, .p-all-75 {padding-left: 75px;}
.p-l-76, .p-lr-76, .p-all-76 {padding-left: 76px;}
.p-l-77, .p-lr-77, .p-all-77 {padding-left: 77px;}
.p-l-78, .p-lr-78, .p-all-78 {padding-left: 78px;}
.p-l-79, .p-lr-79, .p-all-79 {padding-left: 79px;}
.p-l-80, .p-lr-80, .p-all-80 {padding-left: 80px;}
.p-l-81, .p-lr-81, .p-all-81 {padding-left: 81px;}
.p-l-82, .p-lr-82, .p-all-82 {padding-left: 82px;}
.p-l-83, .p-lr-83, .p-all-83 {padding-left: 83px;}
.p-l-84, .p-lr-84, .p-all-84 {padding-left: 84px;}
.p-l-85, .p-lr-85, .p-all-85 {padding-left: 85px;}
.p-l-86, .p-lr-86, .p-all-86 {padding-left: 86px;}
.p-l-87, .p-lr-87, .p-all-87 {padding-left: 87px;}
.p-l-88, .p-lr-88, .p-all-88 {padding-left: 88px;}
.p-l-89, .p-lr-89, .p-all-89 {padding-left: 89px;}
.p-l-90, .p-lr-90, .p-all-90 {padding-left: 90px;}
.p-l-91, .p-lr-91, .p-all-91 {padding-left: 91px;}
.p-l-92, .p-lr-92, .p-all-92 {padding-left: 92px;}
.p-l-93, .p-lr-93, .p-all-93 {padding-left: 93px;}
.p-l-94, .p-lr-94, .p-all-94 {padding-left: 94px;}
.p-l-95, .p-lr-95, .p-all-95 {padding-left: 95px;}
.p-l-96, .p-lr-96, .p-all-96 {padding-left: 96px;}
.p-l-97, .p-lr-97, .p-all-97 {padding-left: 97px;}
.p-l-98, .p-lr-98, .p-all-98 {padding-left: 98px;}
.p-l-99, .p-lr-99, .p-all-99 {padding-left: 99px;}
.p-l-100, .p-lr-100, .p-all-100 {padding-left: 100px;}
.p-l-101, .p-lr-101, .p-all-101 {padding-left: 101px;}
.p-l-102, .p-lr-102, .p-all-102 {padding-left: 102px;}
.p-l-103, .p-lr-103, .p-all-103 {padding-left: 103px;}
.p-l-104, .p-lr-104, .p-all-104 {padding-left: 104px;}
.p-l-105, .p-lr-105, .p-all-105 {padding-left: 105px;}
.p-l-106, .p-lr-106, .p-all-106 {padding-left: 106px;}
.p-l-107, .p-lr-107, .p-all-107 {padding-left: 107px;}
.p-l-108, .p-lr-108, .p-all-108 {padding-left: 108px;}
.p-l-109, .p-lr-109, .p-all-109 {padding-left: 109px;}
.p-l-110, .p-lr-110, .p-all-110 {padding-left: 110px;}
.p-l-111, .p-lr-111, .p-all-111 {padding-left: 111px;}
.p-l-112, .p-lr-112, .p-all-112 {padding-left: 112px;}
.p-l-113, .p-lr-113, .p-all-113 {padding-left: 113px;}
.p-l-114, .p-lr-114, .p-all-114 {padding-left: 114px;}
.p-l-115, .p-lr-115, .p-all-115 {padding-left: 115px;}
.p-l-116, .p-lr-116, .p-all-116 {padding-left: 116px;}
.p-l-117, .p-lr-117, .p-all-117 {padding-left: 117px;}
.p-l-118, .p-lr-118, .p-all-118 {padding-left: 118px;}
.p-l-119, .p-lr-119, .p-all-119 {padding-left: 119px;}
.p-l-120, .p-lr-120, .p-all-120 {padding-left: 120px;}
.p-l-121, .p-lr-121, .p-all-121 {padding-left: 121px;}
.p-l-122, .p-lr-122, .p-all-122 {padding-left: 122px;}
.p-l-123, .p-lr-123, .p-all-123 {padding-left: 123px;}
.p-l-124, .p-lr-124, .p-all-124 {padding-left: 124px;}
.p-l-125, .p-lr-125, .p-all-125 {padding-left: 125px;}
.p-l-126, .p-lr-126, .p-all-126 {padding-left: 126px;}
.p-l-127, .p-lr-127, .p-all-127 {padding-left: 127px;}
.p-l-128, .p-lr-128, .p-all-128 {padding-left: 128px;}
.p-l-129, .p-lr-129, .p-all-129 {padding-left: 129px;}
.p-l-130, .p-lr-130, .p-all-130 {padding-left: 130px;}
.p-l-131, .p-lr-131, .p-all-131 {padding-left: 131px;}
.p-l-132, .p-lr-132, .p-all-132 {padding-left: 132px;}
.p-l-133, .p-lr-133, .p-all-133 {padding-left: 133px;}
.p-l-134, .p-lr-134, .p-all-134 {padding-left: 134px;}
.p-l-135, .p-lr-135, .p-all-135 {padding-left: 135px;}
.p-l-136, .p-lr-136, .p-all-136 {padding-left: 136px;}
.p-l-137, .p-lr-137, .p-all-137 {padding-left: 137px;}
.p-l-138, .p-lr-138, .p-all-138 {padding-left: 138px;}
.p-l-139, .p-lr-139, .p-all-139 {padding-left: 139px;}
.p-l-140, .p-lr-140, .p-all-140 {padding-left: 140px;}
.p-l-141, .p-lr-141, .p-all-141 {padding-left: 141px;}
.p-l-142, .p-lr-142, .p-all-142 {padding-left: 142px;}
.p-l-143, .p-lr-143, .p-all-143 {padding-left: 143px;}
.p-l-144, .p-lr-144, .p-all-144 {padding-left: 144px;}
.p-l-145, .p-lr-145, .p-all-145 {padding-left: 145px;}
.p-l-146, .p-lr-146, .p-all-146 {padding-left: 146px;}
.p-l-147, .p-lr-147, .p-all-147 {padding-left: 147px;}
.p-l-148, .p-lr-148, .p-all-148 {padding-left: 148px;}
.p-l-149, .p-lr-149, .p-all-149 {padding-left: 149px;}
.p-l-150, .p-lr-150, .p-all-150 {padding-left: 150px;}
.p-l-151, .p-lr-151, .p-all-151 {padding-left: 151px;}
.p-l-152, .p-lr-152, .p-all-152 {padding-left: 152px;}
.p-l-153, .p-lr-153, .p-all-153 {padding-left: 153px;}
.p-l-154, .p-lr-154, .p-all-154 {padding-left: 154px;}
.p-l-155, .p-lr-155, .p-all-155 {padding-left: 155px;}
.p-l-156, .p-lr-156, .p-all-156 {padding-left: 156px;}
.p-l-157, .p-lr-157, .p-all-157 {padding-left: 157px;}
.p-l-158, .p-lr-158, .p-all-158 {padding-left: 158px;}
.p-l-159, .p-lr-159, .p-all-159 {padding-left: 159px;}
.p-l-160, .p-lr-160, .p-all-160 {padding-left: 160px;}
.p-l-161, .p-lr-161, .p-all-161 {padding-left: 161px;}
.p-l-162, .p-lr-162, .p-all-162 {padding-left: 162px;}
.p-l-163, .p-lr-163, .p-all-163 {padding-left: 163px;}
.p-l-164, .p-lr-164, .p-all-164 {padding-left: 164px;}
.p-l-165, .p-lr-165, .p-all-165 {padding-left: 165px;}
.p-l-166, .p-lr-166, .p-all-166 {padding-left: 166px;}
.p-l-167, .p-lr-167, .p-all-167 {padding-left: 167px;}
.p-l-168, .p-lr-168, .p-all-168 {padding-left: 168px;}
.p-l-169, .p-lr-169, .p-all-169 {padding-left: 169px;}
.p-l-170, .p-lr-170, .p-all-170 {padding-left: 170px;}
.p-l-171, .p-lr-171, .p-all-171 {padding-left: 171px;}
.p-l-172, .p-lr-172, .p-all-172 {padding-left: 172px;}
.p-l-173, .p-lr-173, .p-all-173 {padding-left: 173px;}
.p-l-174, .p-lr-174, .p-all-174 {padding-left: 174px;}
.p-l-175, .p-lr-175, .p-all-175 {padding-left: 175px;}
.p-l-176, .p-lr-176, .p-all-176 {padding-left: 176px;}
.p-l-177, .p-lr-177, .p-all-177 {padding-left: 177px;}
.p-l-178, .p-lr-178, .p-all-178 {padding-left: 178px;}
.p-l-179, .p-lr-179, .p-all-179 {padding-left: 179px;}
.p-l-180, .p-lr-180, .p-all-180 {padding-left: 180px;}
.p-l-181, .p-lr-181, .p-all-181 {padding-left: 181px;}
.p-l-182, .p-lr-182, .p-all-182 {padding-left: 182px;}
.p-l-183, .p-lr-183, .p-all-183 {padding-left: 183px;}
.p-l-184, .p-lr-184, .p-all-184 {padding-left: 184px;}
.p-l-185, .p-lr-185, .p-all-185 {padding-left: 185px;}
.p-l-186, .p-lr-186, .p-all-186 {padding-left: 186px;}
.p-l-187, .p-lr-187, .p-all-187 {padding-left: 187px;}
.p-l-188, .p-lr-188, .p-all-188 {padding-left: 188px;}
.p-l-189, .p-lr-189, .p-all-189 {padding-left: 189px;}
.p-l-190, .p-lr-190, .p-all-190 {padding-left: 190px;}
.p-l-191, .p-lr-191, .p-all-191 {padding-left: 191px;}
.p-l-192, .p-lr-192, .p-all-192 {padding-left: 192px;}
.p-l-193, .p-lr-193, .p-all-193 {padding-left: 193px;}
.p-l-194, .p-lr-194, .p-all-194 {padding-left: 194px;}
.p-l-195, .p-lr-195, .p-all-195 {padding-left: 195px;}
.p-l-196, .p-lr-196, .p-all-196 {padding-left: 196px;}
.p-l-197, .p-lr-197, .p-all-197 {padding-left: 197px;}
.p-l-198, .p-lr-198, .p-all-198 {padding-left: 198px;}
.p-l-199, .p-lr-199, .p-all-199 {padding-left: 199px;}
.p-l-200, .p-lr-200, .p-all-200 {padding-left: 200px;}
.p-l-201, .p-lr-201, .p-all-201 {padding-left: 201px;}
.p-l-202, .p-lr-202, .p-all-202 {padding-left: 202px;}
.p-l-203, .p-lr-203, .p-all-203 {padding-left: 203px;}
.p-l-204, .p-lr-204, .p-all-204 {padding-left: 204px;}
.p-l-205, .p-lr-205, .p-all-205 {padding-left: 205px;}
.p-l-206, .p-lr-206, .p-all-206 {padding-left: 206px;}
.p-l-207, .p-lr-207, .p-all-207 {padding-left: 207px;}
.p-l-208, .p-lr-208, .p-all-208 {padding-left: 208px;}
.p-l-209, .p-lr-209, .p-all-209 {padding-left: 209px;}
.p-l-210, .p-lr-210, .p-all-210 {padding-left: 210px;}
.p-l-211, .p-lr-211, .p-all-211 {padding-left: 211px;}
.p-l-212, .p-lr-212, .p-all-212 {padding-left: 212px;}
.p-l-213, .p-lr-213, .p-all-213 {padding-left: 213px;}
.p-l-214, .p-lr-214, .p-all-214 {padding-left: 214px;}
.p-l-215, .p-lr-215, .p-all-215 {padding-left: 215px;}
.p-l-216, .p-lr-216, .p-all-216 {padding-left: 216px;}
.p-l-217, .p-lr-217, .p-all-217 {padding-left: 217px;}
.p-l-218, .p-lr-218, .p-all-218 {padding-left: 218px;}
.p-l-219, .p-lr-219, .p-all-219 {padding-left: 219px;}
.p-l-220, .p-lr-220, .p-all-220 {padding-left: 220px;}
.p-l-221, .p-lr-221, .p-all-221 {padding-left: 221px;}
.p-l-222, .p-lr-222, .p-all-222 {padding-left: 222px;}
.p-l-223, .p-lr-223, .p-all-223 {padding-left: 223px;}
.p-l-224, .p-lr-224, .p-all-224 {padding-left: 224px;}
.p-l-225, .p-lr-225, .p-all-225 {padding-left: 225px;}
.p-l-226, .p-lr-226, .p-all-226 {padding-left: 226px;}
.p-l-227, .p-lr-227, .p-all-227 {padding-left: 227px;}
.p-l-228, .p-lr-228, .p-all-228 {padding-left: 228px;}
.p-l-229, .p-lr-229, .p-all-229 {padding-left: 229px;}
.p-l-230, .p-lr-230, .p-all-230 {padding-left: 230px;}
.p-l-231, .p-lr-231, .p-all-231 {padding-left: 231px;}
.p-l-232, .p-lr-232, .p-all-232 {padding-left: 232px;}
.p-l-233, .p-lr-233, .p-all-233 {padding-left: 233px;}
.p-l-234, .p-lr-234, .p-all-234 {padding-left: 234px;}
.p-l-235, .p-lr-235, .p-all-235 {padding-left: 235px;}
.p-l-236, .p-lr-236, .p-all-236 {padding-left: 236px;}
.p-l-237, .p-lr-237, .p-all-237 {padding-left: 237px;}
.p-l-238, .p-lr-238, .p-all-238 {padding-left: 238px;}
.p-l-239, .p-lr-239, .p-all-239 {padding-left: 239px;}
.p-l-240, .p-lr-240, .p-all-240 {padding-left: 240px;}
.p-l-241, .p-lr-241, .p-all-241 {padding-left: 241px;}
.p-l-242, .p-lr-242, .p-all-242 {padding-left: 242px;}
.p-l-243, .p-lr-243, .p-all-243 {padding-left: 243px;}
.p-l-244, .p-lr-244, .p-all-244 {padding-left: 244px;}
.p-l-245, .p-lr-245, .p-all-245 {padding-left: 245px;}
.p-l-246, .p-lr-246, .p-all-246 {padding-left: 246px;}
.p-l-247, .p-lr-247, .p-all-247 {padding-left: 247px;}
.p-l-248, .p-lr-248, .p-all-248 {padding-left: 248px;}
.p-l-249, .p-lr-249, .p-all-249 {padding-left: 249px;}
.p-l-250, .p-lr-250, .p-all-250 {padding-left: 250px;}
.p-l-251, .p-lr-251, .p-all-251 {padding-left: 251px;}
.p-l-252, .p-lr-252, .p-all-252 {padding-left: 252px;}
.p-l-253, .p-lr-253, .p-all-253 {padding-left: 253px;}
.p-l-254, .p-lr-254, .p-all-254 {padding-left: 254px;}
.p-l-255, .p-lr-255, .p-all-255 {padding-left: 255px;}
.p-l-256, .p-lr-256, .p-all-256 {padding-left: 256px;}
.p-l-257, .p-lr-257, .p-all-257 {padding-left: 257px;}
.p-l-258, .p-lr-258, .p-all-258 {padding-left: 258px;}
.p-l-259, .p-lr-259, .p-all-259 {padding-left: 259px;}
.p-l-260, .p-lr-260, .p-all-260 {padding-left: 260px;}
.p-l-261, .p-lr-261, .p-all-261 {padding-left: 261px;}
.p-l-262, .p-lr-262, .p-all-262 {padding-left: 262px;}
.p-l-263, .p-lr-263, .p-all-263 {padding-left: 263px;}
.p-l-264, .p-lr-264, .p-all-264 {padding-left: 264px;}
.p-l-265, .p-lr-265, .p-all-265 {padding-left: 265px;}
.p-l-266, .p-lr-266, .p-all-266 {padding-left: 266px;}
.p-l-267, .p-lr-267, .p-all-267 {padding-left: 267px;}
.p-l-268, .p-lr-268, .p-all-268 {padding-left: 268px;}
.p-l-269, .p-lr-269, .p-all-269 {padding-left: 269px;}
.p-l-270, .p-lr-270, .p-all-270 {padding-left: 270px;}
.p-l-271, .p-lr-271, .p-all-271 {padding-left: 271px;}
.p-l-272, .p-lr-272, .p-all-272 {padding-left: 272px;}
.p-l-273, .p-lr-273, .p-all-273 {padding-left: 273px;}
.p-l-274, .p-lr-274, .p-all-274 {padding-left: 274px;}
.p-l-275, .p-lr-275, .p-all-275 {padding-left: 275px;}
.p-l-276, .p-lr-276, .p-all-276 {padding-left: 276px;}
.p-l-277, .p-lr-277, .p-all-277 {padding-left: 277px;}
.p-l-278, .p-lr-278, .p-all-278 {padding-left: 278px;}
.p-l-279, .p-lr-279, .p-all-279 {padding-left: 279px;}
.p-l-280, .p-lr-280, .p-all-280 {padding-left: 280px;}
.p-l-281, .p-lr-281, .p-all-281 {padding-left: 281px;}
.p-l-282, .p-lr-282, .p-all-282 {padding-left: 282px;}
.p-l-283, .p-lr-283, .p-all-283 {padding-left: 283px;}
.p-l-284, .p-lr-284, .p-all-284 {padding-left: 284px;}
.p-l-285, .p-lr-285, .p-all-285 {padding-left: 285px;}
.p-l-286, .p-lr-286, .p-all-286 {padding-left: 286px;}
.p-l-287, .p-lr-287, .p-all-287 {padding-left: 287px;}
.p-l-288, .p-lr-288, .p-all-288 {padding-left: 288px;}
.p-l-289, .p-lr-289, .p-all-289 {padding-left: 289px;}
.p-l-290, .p-lr-290, .p-all-290 {padding-left: 290px;}
.p-l-291, .p-lr-291, .p-all-291 {padding-left: 291px;}
.p-l-292, .p-lr-292, .p-all-292 {padding-left: 292px;}
.p-l-293, .p-lr-293, .p-all-293 {padding-left: 293px;}
.p-l-294, .p-lr-294, .p-all-294 {padding-left: 294px;}
.p-l-295, .p-lr-295, .p-all-295 {padding-left: 295px;}
.p-l-296, .p-lr-296, .p-all-296 {padding-left: 296px;}
.p-l-297, .p-lr-297, .p-all-297 {padding-left: 297px;}
.p-l-298, .p-lr-298, .p-all-298 {padding-left: 298px;}
.p-l-299, .p-lr-299, .p-all-299 {padding-left: 299px;}
.p-l-300, .p-lr-300, .p-all-300 {padding-left: 300px;}
.p-r-0, .p-lr-0, .p-all-0 {padding-right: 0px;}
.p-r-1, .p-lr-1, .p-all-1 {padding-right: 1px;}
.p-r-2, .p-lr-2, .p-all-2 {padding-right: 2px;}
.p-r-3, .p-lr-3, .p-all-3 {padding-right: 3px;}
.p-r-4, .p-lr-4, .p-all-4 {padding-right: 4px;}
.p-r-5, .p-lr-5, .p-all-5 {padding-right: 5px;}
.p-r-6, .p-lr-6, .p-all-6 {padding-right: 6px;}
.p-r-7, .p-lr-7, .p-all-7 {padding-right: 7px;}
.p-r-8, .p-lr-8, .p-all-8 {padding-right: 8px;}
.p-r-9, .p-lr-9, .p-all-9 {padding-right: 9px;}
.p-r-10, .p-lr-10, .p-all-10 {padding-right: 10px;}
.p-r-11, .p-lr-11, .p-all-11 {padding-right: 11px;}
.p-r-12, .p-lr-12, .p-all-12 {padding-right: 12px;}
.p-r-13, .p-lr-13, .p-all-13 {padding-right: 13px;}
.p-r-14, .p-lr-14, .p-all-14 {padding-right: 14px;}
.p-r-15, .p-lr-15, .p-all-15 {padding-right: 15px;}
.p-r-16, .p-lr-16, .p-all-16 {padding-right: 16px;}
.p-r-17, .p-lr-17, .p-all-17 {padding-right: 17px;}
.p-r-18, .p-lr-18, .p-all-18 {padding-right: 18px;}
.p-r-19, .p-lr-19, .p-all-19 {padding-right: 19px;}
.p-r-20, .p-lr-20, .p-all-20 {padding-right: 20px;}
.p-r-21, .p-lr-21, .p-all-21 {padding-right: 21px;}
.p-r-22, .p-lr-22, .p-all-22 {padding-right: 22px;}
.p-r-23, .p-lr-23, .p-all-23 {padding-right: 23px;}
.p-r-24, .p-lr-24, .p-all-24 {padding-right: 24px;}
.p-r-25, .p-lr-25, .p-all-25 {padding-right: 25px;}
.p-r-26, .p-lr-26, .p-all-26 {padding-right: 26px;}
.p-r-27, .p-lr-27, .p-all-27 {padding-right: 27px;}
.p-r-28, .p-lr-28, .p-all-28 {padding-right: 28px;}
.p-r-29, .p-lr-29, .p-all-29 {padding-right: 29px;}
.p-r-30, .p-lr-30, .p-all-30 {padding-right: 30px;}
.p-r-31, .p-lr-31, .p-all-31 {padding-right: 31px;}
.p-r-32, .p-lr-32, .p-all-32 {padding-right: 32px;}
.p-r-33, .p-lr-33, .p-all-33 {padding-right: 33px;}
.p-r-34, .p-lr-34, .p-all-34 {padding-right: 34px;}
.p-r-35, .p-lr-35, .p-all-35 {padding-right: 35px;}
.p-r-36, .p-lr-36, .p-all-36 {padding-right: 36px;}
.p-r-37, .p-lr-37, .p-all-37 {padding-right: 37px;}
.p-r-38, .p-lr-38, .p-all-38 {padding-right: 38px;}
.p-r-39, .p-lr-39, .p-all-39 {padding-right: 39px;}
.p-r-40, .p-lr-40, .p-all-40 {padding-right: 40px;}
.p-r-41, .p-lr-41, .p-all-41 {padding-right: 41px;}
.p-r-42, .p-lr-42, .p-all-42 {padding-right: 42px;}
.p-r-43, .p-lr-43, .p-all-43 {padding-right: 43px;}
.p-r-44, .p-lr-44, .p-all-44 {padding-right: 44px;}
.p-r-45, .p-lr-45, .p-all-45 {padding-right: 45px;}
.p-r-46, .p-lr-46, .p-all-46 {padding-right: 46px;}
.p-r-47, .p-lr-47, .p-all-47 {padding-right: 47px;}
.p-r-48, .p-lr-48, .p-all-48 {padding-right: 48px;}
.p-r-49, .p-lr-49, .p-all-49 {padding-right: 49px;}
.p-r-50, .p-lr-50, .p-all-50 {padding-right: 50px;}
.p-r-51, .p-lr-51, .p-all-51 {padding-right: 51px;}
.p-r-52, .p-lr-52, .p-all-52 {padding-right: 52px;}
.p-r-53, .p-lr-53, .p-all-53 {padding-right: 53px;}
.p-r-54, .p-lr-54, .p-all-54 {padding-right: 54px;}
.p-r-55, .p-lr-55, .p-all-55 {padding-right: 55px;}
.p-r-56, .p-lr-56, .p-all-56 {padding-right: 56px;}
.p-r-57, .p-lr-57, .p-all-57 {padding-right: 57px;}
.p-r-58, .p-lr-58, .p-all-58 {padding-right: 58px;}
.p-r-59, .p-lr-59, .p-all-59 {padding-right: 59px;}
.p-r-60, .p-lr-60, .p-all-60 {padding-right: 60px;}
.p-r-61, .p-lr-61, .p-all-61 {padding-right: 61px;}
.p-r-62, .p-lr-62, .p-all-62 {padding-right: 62px;}
.p-r-63, .p-lr-63, .p-all-63 {padding-right: 63px;}
.p-r-64, .p-lr-64, .p-all-64 {padding-right: 64px;}
.p-r-65, .p-lr-65, .p-all-65 {padding-right: 65px;}
.p-r-66, .p-lr-66, .p-all-66 {padding-right: 66px;}
.p-r-67, .p-lr-67, .p-all-67 {padding-right: 67px;}
.p-r-68, .p-lr-68, .p-all-68 {padding-right: 68px;}
.p-r-69, .p-lr-69, .p-all-69 {padding-right: 69px;}
.p-r-70, .p-lr-70, .p-all-70 {padding-right: 70px;}
.p-r-71, .p-lr-71, .p-all-71 {padding-right: 71px;}
.p-r-72, .p-lr-72, .p-all-72 {padding-right: 72px;}
.p-r-73, .p-lr-73, .p-all-73 {padding-right: 73px;}
.p-r-74, .p-lr-74, .p-all-74 {padding-right: 74px;}
.p-r-75, .p-lr-75, .p-all-75 {padding-right: 75px;}
.p-r-76, .p-lr-76, .p-all-76 {padding-right: 76px;}
.p-r-77, .p-lr-77, .p-all-77 {padding-right: 77px;}
.p-r-78, .p-lr-78, .p-all-78 {padding-right: 78px;}
.p-r-79, .p-lr-79, .p-all-79 {padding-right: 79px;}
.p-r-80, .p-lr-80, .p-all-80 {padding-right: 80px;}
.p-r-81, .p-lr-81, .p-all-81 {padding-right: 81px;}
.p-r-82, .p-lr-82, .p-all-82 {padding-right: 82px;}
.p-r-83, .p-lr-83, .p-all-83 {padding-right: 83px;}
.p-r-84, .p-lr-84, .p-all-84 {padding-right: 84px;}
.p-r-85, .p-lr-85, .p-all-85 {padding-right: 85px;}
.p-r-86, .p-lr-86, .p-all-86 {padding-right: 86px;}
.p-r-87, .p-lr-87, .p-all-87 {padding-right: 87px;}
.p-r-88, .p-lr-88, .p-all-88 {padding-right: 88px;}
.p-r-89, .p-lr-89, .p-all-89 {padding-right: 89px;}
.p-r-90, .p-lr-90, .p-all-90 {padding-right: 90px;}
.p-r-91, .p-lr-91, .p-all-91 {padding-right: 91px;}
.p-r-92, .p-lr-92, .p-all-92 {padding-right: 92px;}
.p-r-93, .p-lr-93, .p-all-93 {padding-right: 93px;}
.p-r-94, .p-lr-94, .p-all-94 {padding-right: 94px;}
.p-r-95, .p-lr-95, .p-all-95 {padding-right: 95px;}
.p-r-96, .p-lr-96, .p-all-96 {padding-right: 96px;}
.p-r-97, .p-lr-97, .p-all-97 {padding-right: 97px;}
.p-r-98, .p-lr-98, .p-all-98 {padding-right: 98px;}
.p-r-99, .p-lr-99, .p-all-99 {padding-right: 99px;}
.p-r-100, .p-lr-100, .p-all-100 {padding-right: 100px;}
.p-r-101, .p-lr-101, .p-all-101 {padding-right: 101px;}
.p-r-102, .p-lr-102, .p-all-102 {padding-right: 102px;}
.p-r-103, .p-lr-103, .p-all-103 {padding-right: 103px;}
.p-r-104, .p-lr-104, .p-all-104 {padding-right: 104px;}
.p-r-105, .p-lr-105, .p-all-105 {padding-right: 105px;}
.p-r-106, .p-lr-106, .p-all-106 {padding-right: 106px;}
.p-r-107, .p-lr-107, .p-all-107 {padding-right: 107px;}
.p-r-108, .p-lr-108, .p-all-108 {padding-right: 108px;}
.p-r-109, .p-lr-109, .p-all-109 {padding-right: 109px;}
.p-r-110, .p-lr-110, .p-all-110 {padding-right: 110px;}
.p-r-111, .p-lr-111, .p-all-111 {padding-right: 111px;}
.p-r-112, .p-lr-112, .p-all-112 {padding-right: 112px;}
.p-r-113, .p-lr-113, .p-all-113 {padding-right: 113px;}
.p-r-114, .p-lr-114, .p-all-114 {padding-right: 114px;}
.p-r-115, .p-lr-115, .p-all-115 {padding-right: 115px;}
.p-r-116, .p-lr-116, .p-all-116 {padding-right: 116px;}
.p-r-117, .p-lr-117, .p-all-117 {padding-right: 117px;}
.p-r-118, .p-lr-118, .p-all-118 {padding-right: 118px;}
.p-r-119, .p-lr-119, .p-all-119 {padding-right: 119px;}
.p-r-120, .p-lr-120, .p-all-120 {padding-right: 120px;}
.p-r-121, .p-lr-121, .p-all-121 {padding-right: 121px;}
.p-r-122, .p-lr-122, .p-all-122 {padding-right: 122px;}
.p-r-123, .p-lr-123, .p-all-123 {padding-right: 123px;}
.p-r-124, .p-lr-124, .p-all-124 {padding-right: 124px;}
.p-r-125, .p-lr-125, .p-all-125 {padding-right: 125px;}
.p-r-126, .p-lr-126, .p-all-126 {padding-right: 126px;}
.p-r-127, .p-lr-127, .p-all-127 {padding-right: 127px;}
.p-r-128, .p-lr-128, .p-all-128 {padding-right: 128px;}
.p-r-129, .p-lr-129, .p-all-129 {padding-right: 129px;}
.p-r-130, .p-lr-130, .p-all-130 {padding-right: 130px;}
.p-r-131, .p-lr-131, .p-all-131 {padding-right: 131px;}
.p-r-132, .p-lr-132, .p-all-132 {padding-right: 132px;}
.p-r-133, .p-lr-133, .p-all-133 {padding-right: 133px;}
.p-r-134, .p-lr-134, .p-all-134 {padding-right: 134px;}
.p-r-135, .p-lr-135, .p-all-135 {padding-right: 135px;}
.p-r-136, .p-lr-136, .p-all-136 {padding-right: 136px;}
.p-r-137, .p-lr-137, .p-all-137 {padding-right: 137px;}
.p-r-138, .p-lr-138, .p-all-138 {padding-right: 138px;}
.p-r-139, .p-lr-139, .p-all-139 {padding-right: 139px;}
.p-r-140, .p-lr-140, .p-all-140 {padding-right: 140px;}
.p-r-141, .p-lr-141, .p-all-141 {padding-right: 141px;}
.p-r-142, .p-lr-142, .p-all-142 {padding-right: 142px;}
.p-r-143, .p-lr-143, .p-all-143 {padding-right: 143px;}
.p-r-144, .p-lr-144, .p-all-144 {padding-right: 144px;}
.p-r-145, .p-lr-145, .p-all-145 {padding-right: 145px;}
.p-r-146, .p-lr-146, .p-all-146 {padding-right: 146px;}
.p-r-147, .p-lr-147, .p-all-147 {padding-right: 147px;}
.p-r-148, .p-lr-148, .p-all-148 {padding-right: 148px;}
.p-r-149, .p-lr-149, .p-all-149 {padding-right: 149px;}
.p-r-150, .p-lr-150, .p-all-150 {padding-right: 150px;}
.p-r-151, .p-lr-151, .p-all-151 {padding-right: 151px;}
.p-r-152, .p-lr-152, .p-all-152 {padding-right: 152px;}
.p-r-153, .p-lr-153, .p-all-153 {padding-right: 153px;}
.p-r-154, .p-lr-154, .p-all-154 {padding-right: 154px;}
.p-r-155, .p-lr-155, .p-all-155 {padding-right: 155px;}
.p-r-156, .p-lr-156, .p-all-156 {padding-right: 156px;}
.p-r-157, .p-lr-157, .p-all-157 {padding-right: 157px;}
.p-r-158, .p-lr-158, .p-all-158 {padding-right: 158px;}
.p-r-159, .p-lr-159, .p-all-159 {padding-right: 159px;}
.p-r-160, .p-lr-160, .p-all-160 {padding-right: 160px;}
.p-r-161, .p-lr-161, .p-all-161 {padding-right: 161px;}
.p-r-162, .p-lr-162, .p-all-162 {padding-right: 162px;}
.p-r-163, .p-lr-163, .p-all-163 {padding-right: 163px;}
.p-r-164, .p-lr-164, .p-all-164 {padding-right: 164px;}
.p-r-165, .p-lr-165, .p-all-165 {padding-right: 165px;}
.p-r-166, .p-lr-166, .p-all-166 {padding-right: 166px;}
.p-r-167, .p-lr-167, .p-all-167 {padding-right: 167px;}
.p-r-168, .p-lr-168, .p-all-168 {padding-right: 168px;}
.p-r-169, .p-lr-169, .p-all-169 {padding-right: 169px;}
.p-r-170, .p-lr-170, .p-all-170 {padding-right: 170px;}
.p-r-171, .p-lr-171, .p-all-171 {padding-right: 171px;}
.p-r-172, .p-lr-172, .p-all-172 {padding-right: 172px;}
.p-r-173, .p-lr-173, .p-all-173 {padding-right: 173px;}
.p-r-174, .p-lr-174, .p-all-174 {padding-right: 174px;}
.p-r-175, .p-lr-175, .p-all-175 {padding-right: 175px;}
.p-r-176, .p-lr-176, .p-all-176 {padding-right: 176px;}
.p-r-177, .p-lr-177, .p-all-177 {padding-right: 177px;}
.p-r-178, .p-lr-178, .p-all-178 {padding-right: 178px;}
.p-r-179, .p-lr-179, .p-all-179 {padding-right: 179px;}
.p-r-180, .p-lr-180, .p-all-180 {padding-right: 180px;}
.p-r-181, .p-lr-181, .p-all-181 {padding-right: 181px;}
.p-r-182, .p-lr-182, .p-all-182 {padding-right: 182px;}
.p-r-183, .p-lr-183, .p-all-183 {padding-right: 183px;}
.p-r-184, .p-lr-184, .p-all-184 {padding-right: 184px;}
.p-r-185, .p-lr-185, .p-all-185 {padding-right: 185px;}
.p-r-186, .p-lr-186, .p-all-186 {padding-right: 186px;}
.p-r-187, .p-lr-187, .p-all-187 {padding-right: 187px;}
.p-r-188, .p-lr-188, .p-all-188 {padding-right: 188px;}
.p-r-189, .p-lr-189, .p-all-189 {padding-right: 189px;}
.p-r-190, .p-lr-190, .p-all-190 {padding-right: 190px;}
.p-r-191, .p-lr-191, .p-all-191 {padding-right: 191px;}
.p-r-192, .p-lr-192, .p-all-192 {padding-right: 192px;}
.p-r-193, .p-lr-193, .p-all-193 {padding-right: 193px;}
.p-r-194, .p-lr-194, .p-all-194 {padding-right: 194px;}
.p-r-195, .p-lr-195, .p-all-195 {padding-right: 195px;}
.p-r-196, .p-lr-196, .p-all-196 {padding-right: 196px;}
.p-r-197, .p-lr-197, .p-all-197 {padding-right: 197px;}
.p-r-198, .p-lr-198, .p-all-198 {padding-right: 198px;}
.p-r-199, .p-lr-199, .p-all-199 {padding-right: 199px;}
.p-r-200, .p-lr-200, .p-all-200 {padding-right: 200px;}
.p-r-201, .p-lr-201, .p-all-201 {padding-right: 201px;}
.p-r-202, .p-lr-202, .p-all-202 {padding-right: 202px;}
.p-r-203, .p-lr-203, .p-all-203 {padding-right: 203px;}
.p-r-204, .p-lr-204, .p-all-204 {padding-right: 204px;}
.p-r-205, .p-lr-205, .p-all-205 {padding-right: 205px;}
.p-r-206, .p-lr-206, .p-all-206 {padding-right: 206px;}
.p-r-207, .p-lr-207, .p-all-207 {padding-right: 207px;}
.p-r-208, .p-lr-208, .p-all-208 {padding-right: 208px;}
.p-r-209, .p-lr-209, .p-all-209 {padding-right: 209px;}
.p-r-210, .p-lr-210, .p-all-210 {padding-right: 210px;}
.p-r-211, .p-lr-211, .p-all-211 {padding-right: 211px;}
.p-r-212, .p-lr-212, .p-all-212 {padding-right: 212px;}
.p-r-213, .p-lr-213, .p-all-213 {padding-right: 213px;}
.p-r-214, .p-lr-214, .p-all-214 {padding-right: 214px;}
.p-r-215, .p-lr-215, .p-all-215 {padding-right: 215px;}
.p-r-216, .p-lr-216, .p-all-216 {padding-right: 216px;}
.p-r-217, .p-lr-217, .p-all-217 {padding-right: 217px;}
.p-r-218, .p-lr-218, .p-all-218 {padding-right: 218px;}
.p-r-219, .p-lr-219, .p-all-219 {padding-right: 219px;}
.p-r-220, .p-lr-220, .p-all-220 {padding-right: 220px;}
.p-r-221, .p-lr-221, .p-all-221 {padding-right: 221px;}
.p-r-222, .p-lr-222, .p-all-222 {padding-right: 222px;}
.p-r-223, .p-lr-223, .p-all-223 {padding-right: 223px;}
.p-r-224, .p-lr-224, .p-all-224 {padding-right: 224px;}
.p-r-225, .p-lr-225, .p-all-225 {padding-right: 225px;}
.p-r-226, .p-lr-226, .p-all-226 {padding-right: 226px;}
.p-r-227, .p-lr-227, .p-all-227 {padding-right: 227px;}
.p-r-228, .p-lr-228, .p-all-228 {padding-right: 228px;}
.p-r-229, .p-lr-229, .p-all-229 {padding-right: 229px;}
.p-r-230, .p-lr-230, .p-all-230 {padding-right: 230px;}
.p-r-231, .p-lr-231, .p-all-231 {padding-right: 231px;}
.p-r-232, .p-lr-232, .p-all-232 {padding-right: 232px;}
.p-r-233, .p-lr-233, .p-all-233 {padding-right: 233px;}
.p-r-234, .p-lr-234, .p-all-234 {padding-right: 234px;}
.p-r-235, .p-lr-235, .p-all-235 {padding-right: 235px;}
.p-r-236, .p-lr-236, .p-all-236 {padding-right: 236px;}
.p-r-237, .p-lr-237, .p-all-237 {padding-right: 237px;}
.p-r-238, .p-lr-238, .p-all-238 {padding-right: 238px;}
.p-r-239, .p-lr-239, .p-all-239 {padding-right: 239px;}
.p-r-240, .p-lr-240, .p-all-240 {padding-right: 240px;}
.p-r-241, .p-lr-241, .p-all-241 {padding-right: 241px;}
.p-r-242, .p-lr-242, .p-all-242 {padding-right: 242px;}
.p-r-243, .p-lr-243, .p-all-243 {padding-right: 243px;}
.p-r-244, .p-lr-244, .p-all-244 {padding-right: 244px;}
.p-r-245, .p-lr-245, .p-all-245 {padding-right: 245px;}
.p-r-246, .p-lr-246, .p-all-246 {padding-right: 246px;}
.p-r-247, .p-lr-247, .p-all-247 {padding-right: 247px;}
.p-r-248, .p-lr-248, .p-all-248 {padding-right: 248px;}
.p-r-249, .p-lr-249, .p-all-249 {padding-right: 249px;}
.p-r-250, .p-lr-250, .p-all-250 {padding-right: 250px;}
.p-r-251, .p-lr-251, .p-all-251 {padding-right: 251px;}
.p-r-252, .p-lr-252, .p-all-252 {padding-right: 252px;}
.p-r-253, .p-lr-253, .p-all-253 {padding-right: 253px;}
.p-r-254, .p-lr-254, .p-all-254 {padding-right: 254px;}
.p-r-255, .p-lr-255, .p-all-255 {padding-right: 255px;}
.p-r-256, .p-lr-256, .p-all-256 {padding-right: 256px;}
.p-r-257, .p-lr-257, .p-all-257 {padding-right: 257px;}
.p-r-258, .p-lr-258, .p-all-258 {padding-right: 258px;}
.p-r-259, .p-lr-259, .p-all-259 {padding-right: 259px;}
.p-r-260, .p-lr-260, .p-all-260 {padding-right: 260px;}
.p-r-261, .p-lr-261, .p-all-261 {padding-right: 261px;}
.p-r-262, .p-lr-262, .p-all-262 {padding-right: 262px;}
.p-r-263, .p-lr-263, .p-all-263 {padding-right: 263px;}
.p-r-264, .p-lr-264, .p-all-264 {padding-right: 264px;}
.p-r-265, .p-lr-265, .p-all-265 {padding-right: 265px;}
.p-r-266, .p-lr-266, .p-all-266 {padding-right: 266px;}
.p-r-267, .p-lr-267, .p-all-267 {padding-right: 267px;}
.p-r-268, .p-lr-268, .p-all-268 {padding-right: 268px;}
.p-r-269, .p-lr-269, .p-all-269 {padding-right: 269px;}
.p-r-270, .p-lr-270, .p-all-270 {padding-right: 270px;}
.p-r-271, .p-lr-271, .p-all-271 {padding-right: 271px;}
.p-r-272, .p-lr-272, .p-all-272 {padding-right: 272px;}
.p-r-273, .p-lr-273, .p-all-273 {padding-right: 273px;}
.p-r-274, .p-lr-274, .p-all-274 {padding-right: 274px;}
.p-r-275, .p-lr-275, .p-all-275 {padding-right: 275px;}
.p-r-276, .p-lr-276, .p-all-276 {padding-right: 276px;}
.p-r-277, .p-lr-277, .p-all-277 {padding-right: 277px;}
.p-r-278, .p-lr-278, .p-all-278 {padding-right: 278px;}
.p-r-279, .p-lr-279, .p-all-279 {padding-right: 279px;}
.p-r-280, .p-lr-280, .p-all-280 {padding-right: 280px;}
.p-r-281, .p-lr-281, .p-all-281 {padding-right: 281px;}
.p-r-282, .p-lr-282, .p-all-282 {padding-right: 282px;}
.p-r-283, .p-lr-283, .p-all-283 {padding-right: 283px;}
.p-r-284, .p-lr-284, .p-all-284 {padding-right: 284px;}
.p-r-285, .p-lr-285, .p-all-285 {padding-right: 285px;}
.p-r-286, .p-lr-286, .p-all-286 {padding-right: 286px;}
.p-r-287, .p-lr-287, .p-all-287 {padding-right: 287px;}
.p-r-288, .p-lr-288, .p-all-288 {padding-right: 288px;}
.p-r-289, .p-lr-289, .p-all-289 {padding-right: 289px;}
.p-r-290, .p-lr-290, .p-all-290 {padding-right: 290px;}
.p-r-291, .p-lr-291, .p-all-291 {padding-right: 291px;}
.p-r-292, .p-lr-292, .p-all-292 {padding-right: 292px;}
.p-r-293, .p-lr-293, .p-all-293 {padding-right: 293px;}
.p-r-294, .p-lr-294, .p-all-294 {padding-right: 294px;}
.p-r-295, .p-lr-295, .p-all-295 {padding-right: 295px;}
.p-r-296, .p-lr-296, .p-all-296 {padding-right: 296px;}
.p-r-297, .p-lr-297, .p-all-297 {padding-right: 297px;}
.p-r-298, .p-lr-298, .p-all-298 {padding-right: 298px;}
.p-r-299, .p-lr-299, .p-all-299 {padding-right: 299px;}
.p-r-300, .p-lr-300, .p-all-300 {padding-right: 300px;}



/*//////////////////////////////////////////////////////////////////
[ MARGIN ]*/
.m-t-0, .m-tb-0, .m-all-0 {margin-top: 0px;}
.m-t-1, .m-tb-1, .m-all-1 {margin-top: 1px;}
.m-t-2, .m-tb-2, .m-all-2 {margin-top: 2px;}
.m-t-3, .m-tb-3, .m-all-3 {margin-top: 3px;}
.m-t-4, .m-tb-4, .m-all-4 {margin-top: 4px;}
.m-t-5, .m-tb-5, .m-all-5 {margin-top: 5px;}
.m-t-6, .m-tb-6, .m-all-6 {margin-top: 6px;}
.m-t-7, .m-tb-7, .m-all-7 {margin-top: 7px;}
.m-t-8, .m-tb-8, .m-all-8 {margin-top: 8px;}
.m-t-9, .m-tb-9, .m-all-9 {margin-top: 9px;}
.m-t-10, .m-tb-10, .m-all-10 {margin-top: 10px;}
.m-t-11, .m-tb-11, .m-all-11 {margin-top: 11px;}
.m-t-12, .m-tb-12, .m-all-12 {margin-top: 12px;}
.m-t-13, .m-tb-13, .m-all-13 {margin-top: 13px;}
.m-t-14, .m-tb-14, .m-all-14 {margin-top: 14px;}
.m-t-15, .m-tb-15, .m-all-15 {margin-top: 15px;}
.m-t-16, .m-tb-16, .m-all-16 {margin-top: 16px;}
.m-t-17, .m-tb-17, .m-all-17 {margin-top: 17px;}
.m-t-18, .m-tb-18, .m-all-18 {margin-top: 18px;}
.m-t-19, .m-tb-19, .m-all-19 {margin-top: 19px;}
.m-t-20, .m-tb-20, .m-all-20 {margin-top: 20px;}
.m-t-21, .m-tb-21, .m-all-21 {margin-top: 21px;}
.m-t-22, .m-tb-22, .m-all-22 {margin-top: 22px;}
.m-t-23, .m-tb-23, .m-all-23 {margin-top: 23px;}
.m-t-24, .m-tb-24, .m-all-24 {margin-top: 24px;}
.m-t-25, .m-tb-25, .m-all-25 {margin-top: 25px;}
.m-t-26, .m-tb-26, .m-all-26 {margin-top: 26px;}
.m-t-27, .m-tb-27, .m-all-27 {margin-top: 27px;}
.m-t-28, .m-tb-28, .m-all-28 {margin-top: 28px;}
.m-t-29, .m-tb-29, .m-all-29 {margin-top: 29px;}
.m-t-30, .m-tb-30, .m-all-30 {margin-top: 30px;}
.m-t-31, .m-tb-31, .m-all-31 {margin-top: 31px;}
.m-t-32, .m-tb-32, .m-all-32 {margin-top: 32px;}
.m-t-33, .m-tb-33, .m-all-33 {margin-top: 33px;}
.m-t-34, .m-tb-34, .m-all-34 {margin-top: 34px;}
.m-t-35, .m-tb-35, .m-all-35 {margin-top: 35px;}
.m-t-36, .m-tb-36, .m-all-36 {margin-top: 36px;}
.m-t-37, .m-tb-37, .m-all-37 {margin-top: 37px;}
.m-t-38, .m-tb-38, .m-all-38 {margin-top: 38px;}
.m-t-39, .m-tb-39, .m-all-39 {margin-top: 39px;}
.m-t-40, .m-tb-40, .m-all-40 {margin-top: 40px;}
.m-t-41, .m-tb-41, .m-all-41 {margin-top: 41px;}
.m-t-42, .m-tb-42, .m-all-42 {margin-top: 42px;}
.m-t-43, .m-tb-43, .m-all-43 {margin-top: 43px;}
.m-t-44, .m-tb-44, .m-all-44 {margin-top: 44px;}
.m-t-45, .m-tb-45, .m-all-45 {margin-top: 45px;}
.m-t-46, .m-tb-46, .m-all-46 {margin-top: 46px;}
.m-t-47, .m-tb-47, .m-all-47 {margin-top: 47px;}
.m-t-48, .m-tb-48, .m-all-48 {margin-top: 48px;}
.m-t-49, .m-tb-49, .m-all-49 {margin-top: 49px;}
.m-t-50, .m-tb-50, .m-all-50 {margin-top: 50px;}
.m-t-51, .m-tb-51, .m-all-51 {margin-top: 51px;}
.m-t-52, .m-tb-52, .m-all-52 {margin-top: 52px;}
.m-t-53, .m-tb-53, .m-all-53 {margin-top: 53px;}
.m-t-54, .m-tb-54, .m-all-54 {margin-top: 54px;}
.m-t-55, .m-tb-55, .m-all-55 {margin-top: 55px;}
.m-t-56, .m-tb-56, .m-all-56 {margin-top: 56px;}
.m-t-57, .m-tb-57, .m-all-57 {margin-top: 57px;}
.m-t-58, .m-tb-58, .m-all-58 {margin-top: 58px;}
.m-t-59, .m-tb-59, .m-all-59 {margin-top: 59px;}
.m-t-60, .m-tb-60, .m-all-60 {margin-top: 60px;}
.m-t-61, .m-tb-61, .m-all-61 {margin-top: 61px;}
.m-t-62, .m-tb-62, .m-all-62 {margin-top: 62px;}
.m-t-63, .m-tb-63, .m-all-63 {margin-top: 63px;}
.m-t-64, .m-tb-64, .m-all-64 {margin-top: 64px;}
.m-t-65, .m-tb-65, .m-all-65 {margin-top: 65px;}
.m-t-66, .m-tb-66, .m-all-66 {margin-top: 66px;}
.m-t-67, .m-tb-67, .m-all-67 {margin-top: 67px;}
.m-t-68, .m-tb-68, .m-all-68 {margin-top: 68px;}
.m-t-69, .m-tb-69, .m-all-69 {margin-top: 69px;}
.m-t-70, .m-tb-70, .m-all-70 {margin-top: 70px;}
.m-t-71, .m-tb-71, .m-all-71 {margin-top: 71px;}
.m-t-72, .m-tb-72, .m-all-72 {margin-top: 72px;}
.m-t-73, .m-tb-73, .m-all-73 {margin-top: 73px;}
.m-t-74, .m-tb-74, .m-all-74 {margin-top: 74px;}
.m-t-75, .m-tb-75, .m-all-75 {margin-top: 75px;}
.m-t-76, .m-tb-76, .m-all-76 {margin-top: 76px;}
.m-t-77, .m-tb-77, .m-all-77 {margin-top: 77px;}
.m-t-78, .m-tb-78, .m-all-78 {margin-top: 78px;}
.m-t-79, .m-tb-79, .m-all-79 {margin-top: 79px;}
.m-t-80, .m-tb-80, .m-all-80 {margin-top: 80px;}
.m-t-81, .m-tb-81, .m-all-81 {margin-top: 81px;}
.m-t-82, .m-tb-82, .m-all-82 {margin-top: 82px;}
.m-t-83, .m-tb-83, .m-all-83 {margin-top: 83px;}
.m-t-84, .m-tb-84, .m-all-84 {margin-top: 84px;}
.m-t-85, .m-tb-85, .m-all-85 {margin-top: 85px;}
.m-t-86, .m-tb-86, .m-all-86 {margin-top: 86px;}
.m-t-87, .m-tb-87, .m-all-87 {margin-top: 87px;}
.m-t-88, .m-tb-88, .m-all-88 {margin-top: 88px;}
.m-t-89, .m-tb-89, .m-all-89 {margin-top: 89px;}
.m-t-90, .m-tb-90, .m-all-90 {margin-top: 90px;}
.m-t-91, .m-tb-91, .m-all-91 {margin-top: 91px;}
.m-t-92, .m-tb-92, .m-all-92 {margin-top: 92px;}
.m-t-93, .m-tb-93, .m-all-93 {margin-top: 93px;}
.m-t-94, .m-tb-94, .m-all-94 {margin-top: 94px;}
.m-t-95, .m-tb-95, .m-all-95 {margin-top: 95px;}
.m-t-96, .m-tb-96, .m-all-96 {margin-top: 96px;}
.m-t-97, .m-tb-97, .m-all-97 {margin-top: 97px;}
.m-t-98, .m-tb-98, .m-all-98 {margin-top: 98px;}
.m-t-99, .m-tb-99, .m-all-99 {margin-top: 99px;}
.m-t-100, .m-tb-100, .m-all-100 {margin-top: 100px;}
.m-t-101, .m-tb-101, .m-all-101 {margin-top: 101px;}
.m-t-102, .m-tb-102, .m-all-102 {margin-top: 102px;}
.m-t-103, .m-tb-103, .m-all-103 {margin-top: 103px;}
.m-t-104, .m-tb-104, .m-all-104 {margin-top: 104px;}
.m-t-105, .m-tb-105, .m-all-105 {margin-top: 105px;}
.m-t-106, .m-tb-106, .m-all-106 {margin-top: 106px;}
.m-t-107, .m-tb-107, .m-all-107 {margin-top: 107px;}
.m-t-108, .m-tb-108, .m-all-108 {margin-top: 108px;}
.m-t-109, .m-tb-109, .m-all-109 {margin-top: 109px;}
.m-t-110, .m-tb-110, .m-all-110 {margin-top: 110px;}
.m-t-111, .m-tb-111, .m-all-111 {margin-top: 111px;}
.m-t-112, .m-tb-112, .m-all-112 {margin-top: 112px;}
.m-t-113, .m-tb-113, .m-all-113 {margin-top: 113px;}
.m-t-114, .m-tb-114, .m-all-114 {margin-top: 114px;}
.m-t-115, .m-tb-115, .m-all-115 {margin-top: 115px;}
.m-t-116, .m-tb-116, .m-all-116 {margin-top: 116px;}
.m-t-117, .m-tb-117, .m-all-117 {margin-top: 117px;}
.m-t-118, .m-tb-118, .m-all-118 {margin-top: 118px;}
.m-t-119, .m-tb-119, .m-all-119 {margin-top: 119px;}
.m-t-120, .m-tb-120, .m-all-120 {margin-top: 120px;}
.m-t-121, .m-tb-121, .m-all-121 {margin-top: 121px;}
.m-t-122, .m-tb-122, .m-all-122 {margin-top: 122px;}
.m-t-123, .m-tb-123, .m-all-123 {margin-top: 123px;}
.m-t-124, .m-tb-124, .m-all-124 {margin-top: 124px;}
.m-t-125, .m-tb-125, .m-all-125 {margin-top: 125px;}
.m-t-126, .m-tb-126, .m-all-126 {margin-top: 126px;}
.m-t-127, .m-tb-127, .m-all-127 {margin-top: 127px;}
.m-t-128, .m-tb-128, .m-all-128 {margin-top: 128px;}
.m-t-129, .m-tb-129, .m-all-129 {margin-top: 129px;}
.m-t-130, .m-tb-130, .m-all-130 {margin-top: 130px;}
.m-t-131, .m-tb-131, .m-all-131 {margin-top: 131px;}
.m-t-132, .m-tb-132, .m-all-132 {margin-top: 132px;}
.m-t-133, .m-tb-133, .m-all-133 {margin-top: 133px;}
.m-t-134, .m-tb-134, .m-all-134 {margin-top: 134px;}
.m-t-135, .m-tb-135, .m-all-135 {margin-top: 135px;}
.m-t-136, .m-tb-136, .m-all-136 {margin-top: 136px;}
.m-t-137, .m-tb-137, .m-all-137 {margin-top: 137px;}
.m-t-138, .m-tb-138, .m-all-138 {margin-top: 138px;}
.m-t-139, .m-tb-139, .m-all-139 {margin-top: 139px;}
.m-t-140, .m-tb-140, .m-all-140 {margin-top: 140px;}
.m-t-141, .m-tb-141, .m-all-141 {margin-top: 141px;}
.m-t-142, .m-tb-142, .m-all-142 {margin-top: 142px;}
.m-t-143, .m-tb-143, .m-all-143 {margin-top: 143px;}
.m-t-144, .m-tb-144, .m-all-144 {margin-top: 144px;}
.m-t-145, .m-tb-145, .m-all-145 {margin-top: 145px;}
.m-t-146, .m-tb-146, .m-all-146 {margin-top: 146px;}
.m-t-147, .m-tb-147, .m-all-147 {margin-top: 147px;}
.m-t-148, .m-tb-148, .m-all-148 {margin-top: 148px;}
.m-t-149, .m-tb-149, .m-all-149 {margin-top: 149px;}
.m-t-150, .m-tb-150, .m-all-150 {margin-top: 150px;}
.m-t-151, .m-tb-151, .m-all-151 {margin-top: 151px;}
.m-t-152, .m-tb-152, .m-all-152 {margin-top: 152px;}
.m-t-153, .m-tb-153, .m-all-153 {margin-top: 153px;}
.m-t-154, .m-tb-154, .m-all-154 {margin-top: 154px;}
.m-t-155, .m-tb-155, .m-all-155 {margin-top: 155px;}
.m-t-156, .m-tb-156, .m-all-156 {margin-top: 156px;}
.m-t-157, .m-tb-157, .m-all-157 {margin-top: 157px;}
.m-t-158, .m-tb-158, .m-all-158 {margin-top: 158px;}
.m-t-159, .m-tb-159, .m-all-159 {margin-top: 159px;}
.m-t-160, .m-tb-160, .m-all-160 {margin-top: 160px;}
.m-t-161, .m-tb-161, .m-all-161 {margin-top: 161px;}
.m-t-162, .m-tb-162, .m-all-162 {margin-top: 162px;}
.m-t-163, .m-tb-163, .m-all-163 {margin-top: 163px;}
.m-t-164, .m-tb-164, .m-all-164 {margin-top: 164px;}
.m-t-165, .m-tb-165, .m-all-165 {margin-top: 165px;}
.m-t-166, .m-tb-166, .m-all-166 {margin-top: 166px;}
.m-t-167, .m-tb-167, .m-all-167 {margin-top: 167px;}
.m-t-168, .m-tb-168, .m-all-168 {margin-top: 168px;}
.m-t-169, .m-tb-169, .m-all-169 {margin-top: 169px;}
.m-t-170, .m-tb-170, .m-all-170 {margin-top: 170px;}
.m-t-171, .m-tb-171, .m-all-171 {margin-top: 171px;}
.m-t-172, .m-tb-172, .m-all-172 {margin-top: 172px;}
.m-t-173, .m-tb-173, .m-all-173 {margin-top: 173px;}
.m-t-174, .m-tb-174, .m-all-174 {margin-top: 174px;}
.m-t-175, .m-tb-175, .m-all-175 {margin-top: 175px;}
.m-t-176, .m-tb-176, .m-all-176 {margin-top: 176px;}
.m-t-177, .m-tb-177, .m-all-177 {margin-top: 177px;}
.m-t-178, .m-tb-178, .m-all-178 {margin-top: 178px;}
.m-t-179, .m-tb-179, .m-all-179 {margin-top: 179px;}
.m-t-180, .m-tb-180, .m-all-180 {margin-top: 180px;}
.m-t-181, .m-tb-181, .m-all-181 {margin-top: 181px;}
.m-t-182, .m-tb-182, .m-all-182 {margin-top: 182px;}
.m-t-183, .m-tb-183, .m-all-183 {margin-top: 183px;}
.m-t-184, .m-tb-184, .m-all-184 {margin-top: 184px;}
.m-t-185, .m-tb-185, .m-all-185 {margin-top: 185px;}
.m-t-186, .m-tb-186, .m-all-186 {margin-top: 186px;}
.m-t-187, .m-tb-187, .m-all-187 {margin-top: 187px;}
.m-t-188, .m-tb-188, .m-all-188 {margin-top: 188px;}
.m-t-189, .m-tb-189, .m-all-189 {margin-top: 189px;}
.m-t-190, .m-tb-190, .m-all-190 {margin-top: 190px;}
.m-t-191, .m-tb-191, .m-all-191 {margin-top: 191px;}
.m-t-192, .m-tb-192, .m-all-192 {margin-top: 192px;}
.m-t-193, .m-tb-193, .m-all-193 {margin-top: 193px;}
.m-t-194, .m-tb-194, .m-all-194 {margin-top: 194px;}
.m-t-195, .m-tb-195, .m-all-195 {margin-top: 195px;}
.m-t-196, .m-tb-196, .m-all-196 {margin-top: 196px;}
.m-t-197, .m-tb-197, .m-all-197 {margin-top: 197px;}
.m-t-198, .m-tb-198, .m-all-198 {margin-top: 198px;}
.m-t-199, .m-tb-199, .m-all-199 {margin-top: 199px;}
.m-t-200, .m-tb-200, .m-all-200 {margin-top: 200px;}
.m-t-201, .m-tb-201, .m-all-201 {margin-top: 201px;}
.m-t-202, .m-tb-202, .m-all-202 {margin-top: 202px;}
.m-t-203, .m-tb-203, .m-all-203 {margin-top: 203px;}
.m-t-204, .m-tb-204, .m-all-204 {margin-top: 204px;}
.m-t-205, .m-tb-205, .m-all-205 {margin-top: 205px;}
.m-t-206, .m-tb-206, .m-all-206 {margin-top: 206px;}
.m-t-207, .m-tb-207, .m-all-207 {margin-top: 207px;}
.m-t-208, .m-tb-208, .m-all-208 {margin-top: 208px;}
.m-t-209, .m-tb-209, .m-all-209 {margin-top: 209px;}
.m-t-210, .m-tb-210, .m-all-210 {margin-top: 210px;}
.m-t-211, .m-tb-211, .m-all-211 {margin-top: 211px;}
.m-t-212, .m-tb-212, .m-all-212 {margin-top: 212px;}
.m-t-213, .m-tb-213, .m-all-213 {margin-top: 213px;}
.m-t-214, .m-tb-214, .m-all-214 {margin-top: 214px;}
.m-t-215, .m-tb-215, .m-all-215 {margin-top: 215px;}
.m-t-216, .m-tb-216, .m-all-216 {margin-top: 216px;}
.m-t-217, .m-tb-217, .m-all-217 {margin-top: 217px;}
.m-t-218, .m-tb-218, .m-all-218 {margin-top: 218px;}
.m-t-219, .m-tb-219, .m-all-219 {margin-top: 219px;}
.m-t-220, .m-tb-220, .m-all-220 {margin-top: 220px;}
.m-t-221, .m-tb-221, .m-all-221 {margin-top: 221px;}
.m-t-222, .m-tb-222, .m-all-222 {margin-top: 222px;}
.m-t-223, .m-tb-223, .m-all-223 {margin-top: 223px;}
.m-t-224, .m-tb-224, .m-all-224 {margin-top: 224px;}
.m-t-225, .m-tb-225, .m-all-225 {margin-top: 225px;}
.m-t-226, .m-tb-226, .m-all-226 {margin-top: 226px;}
.m-t-227, .m-tb-227, .m-all-227 {margin-top: 227px;}
.m-t-228, .m-tb-228, .m-all-228 {margin-top: 228px;}
.m-t-229, .m-tb-229, .m-all-229 {margin-top: 229px;}
.m-t-230, .m-tb-230, .m-all-230 {margin-top: 230px;}
.m-t-231, .m-tb-231, .m-all-231 {margin-top: 231px;}
.m-t-232, .m-tb-232, .m-all-232 {margin-top: 232px;}
.m-t-233, .m-tb-233, .m-all-233 {margin-top: 233px;}
.m-t-234, .m-tb-234, .m-all-234 {margin-top: 234px;}
.m-t-235, .m-tb-235, .m-all-235 {margin-top: 235px;}
.m-t-236, .m-tb-236, .m-all-236 {margin-top: 236px;}
.m-t-237, .m-tb-237, .m-all-237 {margin-top: 237px;}
.m-t-238, .m-tb-238, .m-all-238 {margin-top: 238px;}
.m-t-239, .m-tb-239, .m-all-239 {margin-top: 239px;}
.m-t-240, .m-tb-240, .m-all-240 {margin-top: 240px;}
.m-t-241, .m-tb-241, .m-all-241 {margin-top: 241px;}
.m-t-242, .m-tb-242, .m-all-242 {margin-top: 242px;}
.m-t-243, .m-tb-243, .m-all-243 {margin-top: 243px;}
.m-t-244, .m-tb-244, .m-all-244 {margin-top: 244px;}
.m-t-245, .m-tb-245, .m-all-245 {margin-top: 245px;}
.m-t-246, .m-tb-246, .m-all-246 {margin-top: 246px;}
.m-t-247, .m-tb-247, .m-all-247 {margin-top: 247px;}
.m-t-248, .m-tb-248, .m-all-248 {margin-top: 248px;}
.m-t-249, .m-tb-249, .m-all-249 {margin-top: 249px;}
.m-t-250, .m-tb-250, .m-all-250 {margin-top: 250px;}
.m-t-251, .m-tb-251, .m-all-251 {margin-top: 251px;}
.m-t-252, .m-tb-252, .m-all-252 {margin-top: 252px;}
.m-t-253, .m-tb-253, .m-all-253 {margin-top: 253px;}
.m-t-254, .m-tb-254, .m-all-254 {margin-top: 254px;}
.m-t-255, .m-tb-255, .m-all-255 {margin-top: 255px;}
.m-t-256, .m-tb-256, .m-all-256 {margin-top: 256px;}
.m-t-257, .m-tb-257, .m-all-257 {margin-top: 257px;}
.m-t-258, .m-tb-258, .m-all-258 {margin-top: 258px;}
.m-t-259, .m-tb-259, .m-all-259 {margin-top: 259px;}
.m-t-260, .m-tb-260, .m-all-260 {margin-top: 260px;}
.m-t-261, .m-tb-261, .m-all-261 {margin-top: 261px;}
.m-t-262, .m-tb-262, .m-all-262 {margin-top: 262px;}
.m-t-263, .m-tb-263, .m-all-263 {margin-top: 263px;}
.m-t-264, .m-tb-264, .m-all-264 {margin-top: 264px;}
.m-t-265, .m-tb-265, .m-all-265 {margin-top: 265px;}
.m-t-266, .m-tb-266, .m-all-266 {margin-top: 266px;}
.m-t-267, .m-tb-267, .m-all-267 {margin-top: 267px;}
.m-t-268, .m-tb-268, .m-all-268 {margin-top: 268px;}
.m-t-269, .m-tb-269, .m-all-269 {margin-top: 269px;}
.m-t-270, .m-tb-270, .m-all-270 {margin-top: 270px;}
.m-t-271, .m-tb-271, .m-all-271 {margin-top: 271px;}
.m-t-272, .m-tb-272, .m-all-272 {margin-top: 272px;}
.m-t-273, .m-tb-273, .m-all-273 {margin-top: 273px;}
.m-t-274, .m-tb-274, .m-all-274 {margin-top: 274px;}
.m-t-275, .m-tb-275, .m-all-275 {margin-top: 275px;}
.m-t-276, .m-tb-276, .m-all-276 {margin-top: 276px;}
.m-t-277, .m-tb-277, .m-all-277 {margin-top: 277px;}
.m-t-278, .m-tb-278, .m-all-278 {margin-top: 278px;}
.m-t-279, .m-tb-279, .m-all-279 {margin-top: 279px;}
.m-t-280, .m-tb-280, .m-all-280 {margin-top: 280px;}
.m-t-281, .m-tb-281, .m-all-281 {margin-top: 281px;}
.m-t-282, .m-tb-282, .m-all-282 {margin-top: 282px;}
.m-t-283, .m-tb-283, .m-all-283 {margin-top: 283px;}
.m-t-284, .m-tb-284, .m-all-284 {margin-top: 284px;}
.m-t-285, .m-tb-285, .m-all-285 {margin-top: 285px;}
.m-t-286, .m-tb-286, .m-all-286 {margin-top: 286px;}
.m-t-287, .m-tb-287, .m-all-287 {margin-top: 287px;}
.m-t-288, .m-tb-288, .m-all-288 {margin-top: 288px;}
.m-t-289, .m-tb-289, .m-all-289 {margin-top: 289px;}
.m-t-290, .m-tb-290, .m-all-290 {margin-top: 290px;}
.m-t-291, .m-tb-291, .m-all-291 {margin-top: 291px;}
.m-t-292, .m-tb-292, .m-all-292 {margin-top: 292px;}
.m-t-293, .m-tb-293, .m-all-293 {margin-top: 293px;}
.m-t-294, .m-tb-294, .m-all-294 {margin-top: 294px;}
.m-t-295, .m-tb-295, .m-all-295 {margin-top: 295px;}
.m-t-296, .m-tb-296, .m-all-296 {margin-top: 296px;}
.m-t-297, .m-tb-297, .m-all-297 {margin-top: 297px;}
.m-t-298, .m-tb-298, .m-all-298 {margin-top: 298px;}
.m-t-299, .m-tb-299, .m-all-299 {margin-top: 299px;}
.m-t-300, .m-tb-300, .m-all-300 {margin-top: 300px;}
.m-b-0, .m-tb-0, .m-all-0 {margin-bottom: 0px;}
.m-b-1, .m-tb-1, .m-all-1 {margin-bottom: 1px;}
.m-b-2, .m-tb-2, .m-all-2 {margin-bottom: 2px;}
.m-b-3, .m-tb-3, .m-all-3 {margin-bottom: 3px;}
.m-b-4, .m-tb-4, .m-all-4 {margin-bottom: 4px;}
.m-b-5, .m-tb-5, .m-all-5 {margin-bottom: 5px;}
.m-b-6, .m-tb-6, .m-all-6 {margin-bottom: 6px;}
.m-b-7, .m-tb-7, .m-all-7 {margin-bottom: 7px;}
.m-b-8, .m-tb-8, .m-all-8 {margin-bottom: 8px;}
.m-b-9, .m-tb-9, .m-all-9 {margin-bottom: 9px;}
.m-b-10, .m-tb-10, .m-all-10 {margin-bottom: 10px;}
.m-b-11, .m-tb-11, .m-all-11 {margin-bottom: 11px;}
.m-b-12, .m-tb-12, .m-all-12 {margin-bottom: 12px;}
.m-b-13, .m-tb-13, .m-all-13 {margin-bottom: 13px;}
.m-b-14, .m-tb-14, .m-all-14 {margin-bottom: 14px;}
.m-b-15, .m-tb-15, .m-all-15 {margin-bottom: 15px;}
.m-b-16, .m-tb-16, .m-all-16 {margin-bottom: 16px;}
.m-b-17, .m-tb-17, .m-all-17 {margin-bottom: 17px;}
.m-b-18, .m-tb-18, .m-all-18 {margin-bottom: 18px;}
.m-b-19, .m-tb-19, .m-all-19 {margin-bottom: 19px;}
.m-b-20, .m-tb-20, .m-all-20 {margin-bottom: 20px;}
.m-b-21, .m-tb-21, .m-all-21 {margin-bottom: 21px;}
.m-b-22, .m-tb-22, .m-all-22 {margin-bottom: 22px;}
.m-b-23, .m-tb-23, .m-all-23 {margin-bottom: 23px;}
.m-b-24, .m-tb-24, .m-all-24 {margin-bottom: 24px;}
.m-b-25, .m-tb-25, .m-all-25 {margin-bottom: 25px;}
.m-b-26, .m-tb-26, .m-all-26 {margin-bottom: 26px;}
.m-b-27, .m-tb-27, .m-all-27 {margin-bottom: 27px;}
.m-b-28, .m-tb-28, .m-all-28 {margin-bottom: 28px;}
.m-b-29, .m-tb-29, .m-all-29 {margin-bottom: 29px;}
.m-b-30, .m-tb-30, .m-all-30 {margin-bottom: 30px;}
.m-b-31, .m-tb-31, .m-all-31 {margin-bottom: 31px;}
.m-b-32, .m-tb-32, .m-all-32 {margin-bottom: 32px;}
.m-b-33, .m-tb-33, .m-all-33 {margin-bottom: 33px;}
.m-b-34, .m-tb-34, .m-all-34 {margin-bottom: 34px;}
.m-b-35, .m-tb-35, .m-all-35 {margin-bottom: 35px;}
.m-b-36, .m-tb-36, .m-all-36 {margin-bottom: 36px;}
.m-b-37, .m-tb-37, .m-all-37 {margin-bottom: 37px;}
.m-b-38, .m-tb-38, .m-all-38 {margin-bottom: 38px;}
.m-b-39, .m-tb-39, .m-all-39 {margin-bottom: 39px;}
.m-b-40, .m-tb-40, .m-all-40 {margin-bottom: 40px;}
.m-b-41, .m-tb-41, .m-all-41 {margin-bottom: 41px;}
.m-b-42, .m-tb-42, .m-all-42 {margin-bottom: 42px;}
.m-b-43, .m-tb-43, .m-all-43 {margin-bottom: 43px;}
.m-b-44, .m-tb-44, .m-all-44 {margin-bottom: 44px;}
.m-b-45, .m-tb-45, .m-all-45 {margin-bottom: 45px;}
.m-b-46, .m-tb-46, .m-all-46 {margin-bottom: 46px;}
.m-b-47, .m-tb-47, .m-all-47 {margin-bottom: 47px;}
.m-b-48, .m-tb-48, .m-all-48 {margin-bottom: 48px;}
.m-b-49, .m-tb-49, .m-all-49 {margin-bottom: 49px;}
.m-b-50, .m-tb-50, .m-all-50 {margin-bottom: 50px;}
.m-b-51, .m-tb-51, .m-all-51 {margin-bottom: 51px;}
.m-b-52, .m-tb-52, .m-all-52 {margin-bottom: 52px;}
.m-b-53, .m-tb-53, .m-all-53 {margin-bottom: 53px;}
.m-b-54, .m-tb-54, .m-all-54 {margin-bottom: 54px;}
.m-b-55, .m-tb-55, .m-all-55 {margin-bottom: 55px;}
.m-b-56, .m-tb-56, .m-all-56 {margin-bottom: 56px;}
.m-b-57, .m-tb-57, .m-all-57 {margin-bottom: 57px;}
.m-b-58, .m-tb-58, .m-all-58 {margin-bottom: 58px;}
.m-b-59, .m-tb-59, .m-all-59 {margin-bottom: 59px;}
.m-b-60, .m-tb-60, .m-all-60 {margin-bottom: 60px;}
.m-b-61, .m-tb-61, .m-all-61 {margin-bottom: 61px;}
.m-b-62, .m-tb-62, .m-all-62 {margin-bottom: 62px;}
.m-b-63, .m-tb-63, .m-all-63 {margin-bottom: 63px;}
.m-b-64, .m-tb-64, .m-all-64 {margin-bottom: 64px;}
.m-b-65, .m-tb-65, .m-all-65 {margin-bottom: 65px;}
.m-b-66, .m-tb-66, .m-all-66 {margin-bottom: 66px;}
.m-b-67, .m-tb-67, .m-all-67 {margin-bottom: 67px;}
.m-b-68, .m-tb-68, .m-all-68 {margin-bottom: 68px;}
.m-b-69, .m-tb-69, .m-all-69 {margin-bottom: 69px;}
.m-b-70, .m-tb-70, .m-all-70 {margin-bottom: 70px;}
.m-b-71, .m-tb-71, .m-all-71 {margin-bottom: 71px;}
.m-b-72, .m-tb-72, .m-all-72 {margin-bottom: 72px;}
.m-b-73, .m-tb-73, .m-all-73 {margin-bottom: 73px;}
.m-b-74, .m-tb-74, .m-all-74 {margin-bottom: 74px;}
.m-b-75, .m-tb-75, .m-all-75 {margin-bottom: 75px;}
.m-b-76, .m-tb-76, .m-all-76 {margin-bottom: 76px;}
.m-b-77, .m-tb-77, .m-all-77 {margin-bottom: 77px;}
.m-b-78, .m-tb-78, .m-all-78 {margin-bottom: 78px;}
.m-b-79, .m-tb-79, .m-all-79 {margin-bottom: 79px;}
.m-b-80, .m-tb-80, .m-all-80 {margin-bottom: 80px;}
.m-b-81, .m-tb-81, .m-all-81 {margin-bottom: 81px;}
.m-b-82, .m-tb-82, .m-all-82 {margin-bottom: 82px;}
.m-b-83, .m-tb-83, .m-all-83 {margin-bottom: 83px;}
.m-b-84, .m-tb-84, .m-all-84 {margin-bottom: 84px;}
.m-b-85, .m-tb-85, .m-all-85 {margin-bottom: 85px;}
.m-b-86, .m-tb-86, .m-all-86 {margin-bottom: 86px;}
.m-b-87, .m-tb-87, .m-all-87 {margin-bottom: 87px;}
.m-b-88, .m-tb-88, .m-all-88 {margin-bottom: 88px;}
.m-b-89, .m-tb-89, .m-all-89 {margin-bottom: 89px;}
.m-b-90, .m-tb-90, .m-all-90 {margin-bottom: 90px;}
.m-b-91, .m-tb-91, .m-all-91 {margin-bottom: 91px;}
.m-b-92, .m-tb-92, .m-all-92 {margin-bottom: 92px;}
.m-b-93, .m-tb-93, .m-all-93 {margin-bottom: 93px;}
.m-b-94, .m-tb-94, .m-all-94 {margin-bottom: 94px;}
.m-b-95, .m-tb-95, .m-all-95 {margin-bottom: 95px;}
.m-b-96, .m-tb-96, .m-all-96 {margin-bottom: 96px;}
.m-b-97, .m-tb-97, .m-all-97 {margin-bottom: 97px;}
.m-b-98, .m-tb-98, .m-all-98 {margin-bottom: 98px;}
.m-b-99, .m-tb-99, .m-all-99 {margin-bottom: 99px;}
.m-b-100, .m-tb-100, .m-all-100 {margin-bottom: 100px;}
.m-b-101, .m-tb-101, .m-all-101 {margin-bottom: 101px;}
.m-b-102, .m-tb-102, .m-all-102 {margin-bottom: 102px;}
.m-b-103, .m-tb-103, .m-all-103 {margin-bottom: 103px;}
.m-b-104, .m-tb-104, .m-all-104 {margin-bottom: 104px;}
.m-b-105, .m-tb-105, .m-all-105 {margin-bottom: 105px;}
.m-b-106, .m-tb-106, .m-all-106 {margin-bottom: 106px;}
.m-b-107, .m-tb-107, .m-all-107 {margin-bottom: 107px;}
.m-b-108, .m-tb-108, .m-all-108 {margin-bottom: 108px;}
.m-b-109, .m-tb-109, .m-all-109 {margin-bottom: 109px;}
.m-b-110, .m-tb-110, .m-all-110 {margin-bottom: 110px;}
.m-b-111, .m-tb-111, .m-all-111 {margin-bottom: 111px;}
.m-b-112, .m-tb-112, .m-all-112 {margin-bottom: 112px;}
.m-b-113, .m-tb-113, .m-all-113 {margin-bottom: 113px;}
.m-b-114, .m-tb-114, .m-all-114 {margin-bottom: 114px;}
.m-b-115, .m-tb-115, .m-all-115 {margin-bottom: 115px;}
.m-b-116, .m-tb-116, .m-all-116 {margin-bottom: 116px;}
.m-b-117, .m-tb-117, .m-all-117 {margin-bottom: 117px;}
.m-b-118, .m-tb-118, .m-all-118 {margin-bottom: 118px;}
.m-b-119, .m-tb-119, .m-all-119 {margin-bottom: 119px;}
.m-b-120, .m-tb-120, .m-all-120 {margin-bottom: 120px;}
.m-b-121, .m-tb-121, .m-all-121 {margin-bottom: 121px;}
.m-b-122, .m-tb-122, .m-all-122 {margin-bottom: 122px;}
.m-b-123, .m-tb-123, .m-all-123 {margin-bottom: 123px;}
.m-b-124, .m-tb-124, .m-all-124 {margin-bottom: 124px;}
.m-b-125, .m-tb-125, .m-all-125 {margin-bottom: 125px;}
.m-b-126, .m-tb-126, .m-all-126 {margin-bottom: 126px;}
.m-b-127, .m-tb-127, .m-all-127 {margin-bottom: 127px;}
.m-b-128, .m-tb-128, .m-all-128 {margin-bottom: 128px;}
.m-b-129, .m-tb-129, .m-all-129 {margin-bottom: 129px;}
.m-b-130, .m-tb-130, .m-all-130 {margin-bottom: 130px;}
.m-b-131, .m-tb-131, .m-all-131 {margin-bottom: 131px;}
.m-b-132, .m-tb-132, .m-all-132 {margin-bottom: 132px;}
.m-b-133, .m-tb-133, .m-all-133 {margin-bottom: 133px;}
.m-b-134, .m-tb-134, .m-all-134 {margin-bottom: 134px;}
.m-b-135, .m-tb-135, .m-all-135 {margin-bottom: 135px;}
.m-b-136, .m-tb-136, .m-all-136 {margin-bottom: 136px;}
.m-b-137, .m-tb-137, .m-all-137 {margin-bottom: 137px;}
.m-b-138, .m-tb-138, .m-all-138 {margin-bottom: 138px;}
.m-b-139, .m-tb-139, .m-all-139 {margin-bottom: 139px;}
.m-b-140, .m-tb-140, .m-all-140 {margin-bottom: 140px;}
.m-b-141, .m-tb-141, .m-all-141 {margin-bottom: 141px;}
.m-b-142, .m-tb-142, .m-all-142 {margin-bottom: 142px;}
.m-b-143, .m-tb-143, .m-all-143 {margin-bottom: 143px;}
.m-b-144, .m-tb-144, .m-all-144 {margin-bottom: 144px;}
.m-b-145, .m-tb-145, .m-all-145 {margin-bottom: 145px;}
.m-b-146, .m-tb-146, .m-all-146 {margin-bottom: 146px;}
.m-b-147, .m-tb-147, .m-all-147 {margin-bottom: 147px;}
.m-b-148, .m-tb-148, .m-all-148 {margin-bottom: 148px;}
.m-b-149, .m-tb-149, .m-all-149 {margin-bottom: 149px;}
.m-b-150, .m-tb-150, .m-all-150 {margin-bottom: 150px;}
.m-b-151, .m-tb-151, .m-all-151 {margin-bottom: 151px;}
.m-b-152, .m-tb-152, .m-all-152 {margin-bottom: 152px;}
.m-b-153, .m-tb-153, .m-all-153 {margin-bottom: 153px;}
.m-b-154, .m-tb-154, .m-all-154 {margin-bottom: 154px;}
.m-b-155, .m-tb-155, .m-all-155 {margin-bottom: 155px;}
.m-b-156, .m-tb-156, .m-all-156 {margin-bottom: 156px;}
.m-b-157, .m-tb-157, .m-all-157 {margin-bottom: 157px;}
.m-b-158, .m-tb-158, .m-all-158 {margin-bottom: 158px;}
.m-b-159, .m-tb-159, .m-all-159 {margin-bottom: 159px;}
.m-b-160, .m-tb-160, .m-all-160 {margin-bottom: 160px;}
.m-b-161, .m-tb-161, .m-all-161 {margin-bottom: 161px;}
.m-b-162, .m-tb-162, .m-all-162 {margin-bottom: 162px;}
.m-b-163, .m-tb-163, .m-all-163 {margin-bottom: 163px;}
.m-b-164, .m-tb-164, .m-all-164 {margin-bottom: 164px;}
.m-b-165, .m-tb-165, .m-all-165 {margin-bottom: 165px;}
.m-b-166, .m-tb-166, .m-all-166 {margin-bottom: 166px;}
.m-b-167, .m-tb-167, .m-all-167 {margin-bottom: 167px;}
.m-b-168, .m-tb-168, .m-all-168 {margin-bottom: 168px;}
.m-b-169, .m-tb-169, .m-all-169 {margin-bottom: 169px;}
.m-b-170, .m-tb-170, .m-all-170 {margin-bottom: 170px;}
.m-b-171, .m-tb-171, .m-all-171 {margin-bottom: 171px;}
.m-b-172, .m-tb-172, .m-all-172 {margin-bottom: 172px;}
.m-b-173, .m-tb-173, .m-all-173 {margin-bottom: 173px;}
.m-b-174, .m-tb-174, .m-all-174 {margin-bottom: 174px;}
.m-b-175, .m-tb-175, .m-all-175 {margin-bottom: 175px;}
.m-b-176, .m-tb-176, .m-all-176 {margin-bottom: 176px;}
.m-b-177, .m-tb-177, .m-all-177 {margin-bottom: 177px;}
.m-b-178, .m-tb-178, .m-all-178 {margin-bottom: 178px;}
.m-b-179, .m-tb-179, .m-all-179 {margin-bottom: 179px;}
.m-b-180, .m-tb-180, .m-all-180 {margin-bottom: 180px;}
.m-b-181, .m-tb-181, .m-all-181 {margin-bottom: 181px;}
.m-b-182, .m-tb-182, .m-all-182 {margin-bottom: 182px;}
.m-b-183, .m-tb-183, .m-all-183 {margin-bottom: 183px;}
.m-b-184, .m-tb-184, .m-all-184 {margin-bottom: 184px;}
.m-b-185, .m-tb-185, .m-all-185 {margin-bottom: 185px;}
.m-b-186, .m-tb-186, .m-all-186 {margin-bottom: 186px;}
.m-b-187, .m-tb-187, .m-all-187 {margin-bottom: 187px;}
.m-b-188, .m-tb-188, .m-all-188 {margin-bottom: 188px;}
.m-b-189, .m-tb-189, .m-all-189 {margin-bottom: 189px;}
.m-b-190, .m-tb-190, .m-all-190 {margin-bottom: 190px;}
.m-b-191, .m-tb-191, .m-all-191 {margin-bottom: 191px;}
.m-b-192, .m-tb-192, .m-all-192 {margin-bottom: 192px;}
.m-b-193, .m-tb-193, .m-all-193 {margin-bottom: 193px;}
.m-b-194, .m-tb-194, .m-all-194 {margin-bottom: 194px;}
.m-b-195, .m-tb-195, .m-all-195 {margin-bottom: 195px;}
.m-b-196, .m-tb-196, .m-all-196 {margin-bottom: 196px;}
.m-b-197, .m-tb-197, .m-all-197 {margin-bottom: 197px;}
.m-b-198, .m-tb-198, .m-all-198 {margin-bottom: 198px;}
.m-b-199, .m-tb-199, .m-all-199 {margin-bottom: 199px;}
.m-b-200, .m-tb-200, .m-all-200 {margin-bottom: 200px;}
.m-b-201, .m-tb-201, .m-all-201 {margin-bottom: 201px;}
.m-b-202, .m-tb-202, .m-all-202 {margin-bottom: 202px;}
.m-b-203, .m-tb-203, .m-all-203 {margin-bottom: 203px;}
.m-b-204, .m-tb-204, .m-all-204 {margin-bottom: 204px;}
.m-b-205, .m-tb-205, .m-all-205 {margin-bottom: 205px;}
.m-b-206, .m-tb-206, .m-all-206 {margin-bottom: 206px;}
.m-b-207, .m-tb-207, .m-all-207 {margin-bottom: 207px;}
.m-b-208, .m-tb-208, .m-all-208 {margin-bottom: 208px;}
.m-b-209, .m-tb-209, .m-all-209 {margin-bottom: 209px;}
.m-b-210, .m-tb-210, .m-all-210 {margin-bottom: 210px;}
.m-b-211, .m-tb-211, .m-all-211 {margin-bottom: 211px;}
.m-b-212, .m-tb-212, .m-all-212 {margin-bottom: 212px;}
.m-b-213, .m-tb-213, .m-all-213 {margin-bottom: 213px;}
.m-b-214, .m-tb-214, .m-all-214 {margin-bottom: 214px;}
.m-b-215, .m-tb-215, .m-all-215 {margin-bottom: 215px;}
.m-b-216, .m-tb-216, .m-all-216 {margin-bottom: 216px;}
.m-b-217, .m-tb-217, .m-all-217 {margin-bottom: 217px;}
.m-b-218, .m-tb-218, .m-all-218 {margin-bottom: 218px;}
.m-b-219, .m-tb-219, .m-all-219 {margin-bottom: 219px;}
.m-b-220, .m-tb-220, .m-all-220 {margin-bottom: 220px;}
.m-b-221, .m-tb-221, .m-all-221 {margin-bottom: 221px;}
.m-b-222, .m-tb-222, .m-all-222 {margin-bottom: 222px;}
.m-b-223, .m-tb-223, .m-all-223 {margin-bottom: 223px;}
.m-b-224, .m-tb-224, .m-all-224 {margin-bottom: 224px;}
.m-b-225, .m-tb-225, .m-all-225 {margin-bottom: 225px;}
.m-b-226, .m-tb-226, .m-all-226 {margin-bottom: 226px;}
.m-b-227, .m-tb-227, .m-all-227 {margin-bottom: 227px;}
.m-b-228, .m-tb-228, .m-all-228 {margin-bottom: 228px;}
.m-b-229, .m-tb-229, .m-all-229 {margin-bottom: 229px;}
.m-b-230, .m-tb-230, .m-all-230 {margin-bottom: 230px;}
.m-b-231, .m-tb-231, .m-all-231 {margin-bottom: 231px;}
.m-b-232, .m-tb-232, .m-all-232 {margin-bottom: 232px;}
.m-b-233, .m-tb-233, .m-all-233 {margin-bottom: 233px;}
.m-b-234, .m-tb-234, .m-all-234 {margin-bottom: 234px;}
.m-b-235, .m-tb-235, .m-all-235 {margin-bottom: 235px;}
.m-b-236, .m-tb-236, .m-all-236 {margin-bottom: 236px;}
.m-b-237, .m-tb-237, .m-all-237 {margin-bottom: 237px;}
.m-b-238, .m-tb-238, .m-all-238 {margin-bottom: 238px;}
.m-b-239, .m-tb-239, .m-all-239 {margin-bottom: 239px;}
.m-b-240, .m-tb-240, .m-all-240 {margin-bottom: 240px;}
.m-b-241, .m-tb-241, .m-all-241 {margin-bottom: 241px;}
.m-b-242, .m-tb-242, .m-all-242 {margin-bottom: 242px;}
.m-b-243, .m-tb-243, .m-all-243 {margin-bottom: 243px;}
.m-b-244, .m-tb-244, .m-all-244 {margin-bottom: 244px;}
.m-b-245, .m-tb-245, .m-all-245 {margin-bottom: 245px;}
.m-b-246, .m-tb-246, .m-all-246 {margin-bottom: 246px;}
.m-b-247, .m-tb-247, .m-all-247 {margin-bottom: 247px;}
.m-b-248, .m-tb-248, .m-all-248 {margin-bottom: 248px;}
.m-b-249, .m-tb-249, .m-all-249 {margin-bottom: 249px;}
.m-b-250, .m-tb-250, .m-all-250 {margin-bottom: 250px;}
.m-b-251, .m-tb-251, .m-all-251 {margin-bottom: 251px;}
.m-b-252, .m-tb-252, .m-all-252 {margin-bottom: 252px;}
.m-b-253, .m-tb-253, .m-all-253 {margin-bottom: 253px;}
.m-b-254, .m-tb-254, .m-all-254 {margin-bottom: 254px;}
.m-b-255, .m-tb-255, .m-all-255 {margin-bottom: 255px;}
.m-b-256, .m-tb-256, .m-all-256 {margin-bottom: 256px;}
.m-b-257, .m-tb-257, .m-all-257 {margin-bottom: 257px;}
.m-b-258, .m-tb-258, .m-all-258 {margin-bottom: 258px;}
.m-b-259, .m-tb-259, .m-all-259 {margin-bottom: 259px;}
.m-b-260, .m-tb-260, .m-all-260 {margin-bottom: 260px;}
.m-b-261, .m-tb-261, .m-all-261 {margin-bottom: 261px;}
.m-b-262, .m-tb-262, .m-all-262 {margin-bottom: 262px;}
.m-b-263, .m-tb-263, .m-all-263 {margin-bottom: 263px;}
.m-b-264, .m-tb-264, .m-all-264 {margin-bottom: 264px;}
.m-b-265, .m-tb-265, .m-all-265 {margin-bottom: 265px;}
.m-b-266, .m-tb-266, .m-all-266 {margin-bottom: 266px;}
.m-b-267, .m-tb-267, .m-all-267 {margin-bottom: 267px;}
.m-b-268, .m-tb-268, .m-all-268 {margin-bottom: 268px;}
.m-b-269, .m-tb-269, .m-all-269 {margin-bottom: 269px;}
.m-b-270, .m-tb-270, .m-all-270 {margin-bottom: 270px;}
.m-b-271, .m-tb-271, .m-all-271 {margin-bottom: 271px;}
.m-b-272, .m-tb-272, .m-all-272 {margin-bottom: 272px;}
.m-b-273, .m-tb-273, .m-all-273 {margin-bottom: 273px;}
.m-b-274, .m-tb-274, .m-all-274 {margin-bottom: 274px;}
.m-b-275, .m-tb-275, .m-all-275 {margin-bottom: 275px;}
.m-b-276, .m-tb-276, .m-all-276 {margin-bottom: 276px;}
.m-b-277, .m-tb-277, .m-all-277 {margin-bottom: 277px;}
.m-b-278, .m-tb-278, .m-all-278 {margin-bottom: 278px;}
.m-b-279, .m-tb-279, .m-all-279 {margin-bottom: 279px;}
.m-b-280, .m-tb-280, .m-all-280 {margin-bottom: 280px;}
.m-b-281, .m-tb-281, .m-all-281 {margin-bottom: 281px;}
.m-b-282, .m-tb-282, .m-all-282 {margin-bottom: 282px;}
.m-b-283, .m-tb-283, .m-all-283 {margin-bottom: 283px;}
.m-b-284, .m-tb-284, .m-all-284 {margin-bottom: 284px;}
.m-b-285, .m-tb-285, .m-all-285 {margin-bottom: 285px;}
.m-b-286, .m-tb-286, .m-all-286 {margin-bottom: 286px;}
.m-b-287, .m-tb-287, .m-all-287 {margin-bottom: 287px;}
.m-b-288, .m-tb-288, .m-all-288 {margin-bottom: 288px;}
.m-b-289, .m-tb-289, .m-all-289 {margin-bottom: 289px;}
.m-b-290, .m-tb-290, .m-all-290 {margin-bottom: 290px;}
.m-b-291, .m-tb-291, .m-all-291 {margin-bottom: 291px;}
.m-b-292, .m-tb-292, .m-all-292 {margin-bottom: 292px;}
.m-b-293, .m-tb-293, .m-all-293 {margin-bottom: 293px;}
.m-b-294, .m-tb-294, .m-all-294 {margin-bottom: 294px;}
.m-b-295, .m-tb-295, .m-all-295 {margin-bottom: 295px;}
.m-b-296, .m-tb-296, .m-all-296 {margin-bottom: 296px;}
.m-b-297, .m-tb-297, .m-all-297 {margin-bottom: 297px;}
.m-b-298, .m-tb-298, .m-all-298 {margin-bottom: 298px;}
.m-b-299, .m-tb-299, .m-all-299 {margin-bottom: 299px;}
.m-b-300, .m-tb-300, .m-all-300 {margin-bottom: 300px;}
.m-l-0, .m-lr-0, .m-all-0 {margin-left: 0px;}
.m-l-1, .m-lr-1, .m-all-1 {margin-left: 1px;}
.m-l-2, .m-lr-2, .m-all-2 {margin-left: 2px;}
.m-l-3, .m-lr-3, .m-all-3 {margin-left: 3px;}
.m-l-4, .m-lr-4, .m-all-4 {margin-left: 4px;}
.m-l-5, .m-lr-5, .m-all-5 {margin-left: 5px;}
.m-l-6, .m-lr-6, .m-all-6 {margin-left: 6px;}
.m-l-7, .m-lr-7, .m-all-7 {margin-left: 7px;}
.m-l-8, .m-lr-8, .m-all-8 {margin-left: 8px;}
.m-l-9, .m-lr-9, .m-all-9 {margin-left: 9px;}
.m-l-10, .m-lr-10, .m-all-10 {margin-left: 10px;}
.m-l-11, .m-lr-11, .m-all-11 {margin-left: 11px;}
.m-l-12, .m-lr-12, .m-all-12 {margin-left: 12px;}
.m-l-13, .m-lr-13, .m-all-13 {margin-left: 13px;}
.m-l-14, .m-lr-14, .m-all-14 {margin-left: 14px;}
.m-l-15, .m-lr-15, .m-all-15 {margin-left: 15px;}
.m-l-16, .m-lr-16, .m-all-16 {margin-left: 16px;}
.m-l-17, .m-lr-17, .m-all-17 {margin-left: 17px;}
.m-l-18, .m-lr-18, .m-all-18 {margin-left: 18px;}
.m-l-19, .m-lr-19, .m-all-19 {margin-left: 19px;}
.m-l-20, .m-lr-20, .m-all-20 {margin-left: 20px;}
.m-l-21, .m-lr-21, .m-all-21 {margin-left: 21px;}
.m-l-22, .m-lr-22, .m-all-22 {margin-left: 22px;}
.m-l-23, .m-lr-23, .m-all-23 {margin-left: 23px;}
.m-l-24, .m-lr-24, .m-all-24 {margin-left: 24px;}
.m-l-25, .m-lr-25, .m-all-25 {margin-left: 25px;}
.m-l-26, .m-lr-26, .m-all-26 {margin-left: 26px;}
.m-l-27, .m-lr-27, .m-all-27 {margin-left: 27px;}
.m-l-28, .m-lr-28, .m-all-28 {margin-left: 28px;}
.m-l-29, .m-lr-29, .m-all-29 {margin-left: 29px;}
.m-l-30, .m-lr-30, .m-all-30 {margin-left: 30px;}
.m-l-31, .m-lr-31, .m-all-31 {margin-left: 31px;}
.m-l-32, .m-lr-32, .m-all-32 {margin-left: 32px;}
.m-l-33, .m-lr-33, .m-all-33 {margin-left: 33px;}
.m-l-34, .m-lr-34, .m-all-34 {margin-left: 34px;}
.m-l-35, .m-lr-35, .m-all-35 {margin-left: 35px;}
.m-l-36, .m-lr-36, .m-all-36 {margin-left: 36px;}
.m-l-37, .m-lr-37, .m-all-37 {margin-left: 37px;}
.m-l-38, .m-lr-38, .m-all-38 {margin-left: 38px;}
.m-l-39, .m-lr-39, .m-all-39 {margin-left: 39px;}
.m-l-40, .m-lr-40, .m-all-40 {margin-left: 40px;}
.m-l-41, .m-lr-41, .m-all-41 {margin-left: 41px;}
.m-l-42, .m-lr-42, .m-all-42 {margin-left: 42px;}
.m-l-43, .m-lr-43, .m-all-43 {margin-left: 43px;}
.m-l-44, .m-lr-44, .m-all-44 {margin-left: 44px;}
.m-l-45, .m-lr-45, .m-all-45 {margin-left: 45px;}
.m-l-46, .m-lr-46, .m-all-46 {margin-left: 46px;}
.m-l-47, .m-lr-47, .m-all-47 {margin-left: 47px;}
.m-l-48, .m-lr-48, .m-all-48 {margin-left: 48px;}
.m-l-49, .m-lr-49, .m-all-49 {margin-left: 49px;}
.m-l-50, .m-lr-50, .m-all-50 {margin-left: 50px;}
.m-l-51, .m-lr-51, .m-all-51 {margin-left: 51px;}
.m-l-52, .m-lr-52, .m-all-52 {margin-left: 52px;}
.m-l-53, .m-lr-53, .m-all-53 {margin-left: 53px;}
.m-l-54, .m-lr-54, .m-all-54 {margin-left: 54px;}
.m-l-55, .m-lr-55, .m-all-55 {margin-left: 55px;}
.m-l-56, .m-lr-56, .m-all-56 {margin-left: 56px;}
.m-l-57, .m-lr-57, .m-all-57 {margin-left: 57px;}
.m-l-58, .m-lr-58, .m-all-58 {margin-left: 58px;}
.m-l-59, .m-lr-59, .m-all-59 {margin-left: 59px;}
.m-l-60, .m-lr-60, .m-all-60 {margin-left: 60px;}
.m-l-61, .m-lr-61, .m-all-61 {margin-left: 61px;}
.m-l-62, .m-lr-62, .m-all-62 {margin-left: 62px;}
.m-l-63, .m-lr-63, .m-all-63 {margin-left: 63px;}
.m-l-64, .m-lr-64, .m-all-64 {margin-left: 64px;}
.m-l-65, .m-lr-65, .m-all-65 {margin-left: 65px;}
.m-l-66, .m-lr-66, .m-all-66 {margin-left: 66px;}
.m-l-67, .m-lr-67, .m-all-67 {margin-left: 67px;}
.m-l-68, .m-lr-68, .m-all-68 {margin-left: 68px;}
.m-l-69, .m-lr-69, .m-all-69 {margin-left: 69px;}
.m-l-70, .m-lr-70, .m-all-70 {margin-left: 70px;}
.m-l-71, .m-lr-71, .m-all-71 {margin-left: 71px;}
.m-l-72, .m-lr-72, .m-all-72 {margin-left: 72px;}
.m-l-73, .m-lr-73, .m-all-73 {margin-left: 73px;}
.m-l-74, .m-lr-74, .m-all-74 {margin-left: 74px;}
.m-l-75, .m-lr-75, .m-all-75 {margin-left: 75px;}
.m-l-76, .m-lr-76, .m-all-76 {margin-left: 76px;}
.m-l-77, .m-lr-77, .m-all-77 {margin-left: 77px;}
.m-l-78, .m-lr-78, .m-all-78 {margin-left: 78px;}
.m-l-79, .m-lr-79, .m-all-79 {margin-left: 79px;}
.m-l-80, .m-lr-80, .m-all-80 {margin-left: 80px;}
.m-l-81, .m-lr-81, .m-all-81 {margin-left: 81px;}
.m-l-82, .m-lr-82, .m-all-82 {margin-left: 82px;}
.m-l-83, .m-lr-83, .m-all-83 {margin-left: 83px;}
.m-l-84, .m-lr-84, .m-all-84 {margin-left: 84px;}
.m-l-85, .m-lr-85, .m-all-85 {margin-left: 85px;}
.m-l-86, .m-lr-86, .m-all-86 {margin-left: 86px;}
.m-l-87, .m-lr-87, .m-all-87 {margin-left: 87px;}
.m-l-88, .m-lr-88, .m-all-88 {margin-left: 88px;}
.m-l-89, .m-lr-89, .m-all-89 {margin-left: 89px;}
.m-l-90, .m-lr-90, .m-all-90 {margin-left: 90px;}
.m-l-91, .m-lr-91, .m-all-91 {margin-left: 91px;}
.m-l-92, .m-lr-92, .m-all-92 {margin-left: 92px;}
.m-l-93, .m-lr-93, .m-all-93 {margin-left: 93px;}
.m-l-94, .m-lr-94, .m-all-94 {margin-left: 94px;}
.m-l-95, .m-lr-95, .m-all-95 {margin-left: 95px;}
.m-l-96, .m-lr-96, .m-all-96 {margin-left: 96px;}
.m-l-97, .m-lr-97, .m-all-97 {margin-left: 97px;}
.m-l-98, .m-lr-98, .m-all-98 {margin-left: 98px;}
.m-l-99, .m-lr-99, .m-all-99 {margin-left: 99px;}
.m-l-100, .m-lr-100, .m-all-100 {margin-left: 100px;}
.m-l-101, .m-lr-101, .m-all-101 {margin-left: 101px;}
.m-l-102, .m-lr-102, .m-all-102 {margin-left: 102px;}
.m-l-103, .m-lr-103, .m-all-103 {margin-left: 103px;}
.m-l-104, .m-lr-104, .m-all-104 {margin-left: 104px;}
.m-l-105, .m-lr-105, .m-all-105 {margin-left: 105px;}
.m-l-106, .m-lr-106, .m-all-106 {margin-left: 106px;}
.m-l-107, .m-lr-107, .m-all-107 {margin-left: 107px;}
.m-l-108, .m-lr-108, .m-all-108 {margin-left: 108px;}
.m-l-109, .m-lr-109, .m-all-109 {margin-left: 109px;}
.m-l-110, .m-lr-110, .m-all-110 {margin-left: 110px;}
.m-l-111, .m-lr-111, .m-all-111 {margin-left: 111px;}
.m-l-112, .m-lr-112, .m-all-112 {margin-left: 112px;}
.m-l-113, .m-lr-113, .m-all-113 {margin-left: 113px;}
.m-l-114, .m-lr-114, .m-all-114 {margin-left: 114px;}
.m-l-115, .m-lr-115, .m-all-115 {margin-left: 115px;}
.m-l-116, .m-lr-116, .m-all-116 {margin-left: 116px;}
.m-l-117, .m-lr-117, .m-all-117 {margin-left: 117px;}
.m-l-118, .m-lr-118, .m-all-118 {margin-left: 118px;}
.m-l-119, .m-lr-119, .m-all-119 {margin-left: 119px;}
.m-l-120, .m-lr-120, .m-all-120 {margin-left: 120px;}
.m-l-121, .m-lr-121, .m-all-121 {margin-left: 121px;}
.m-l-122, .m-lr-122, .m-all-122 {margin-left: 122px;}
.m-l-123, .m-lr-123, .m-all-123 {margin-left: 123px;}
.m-l-124, .m-lr-124, .m-all-124 {margin-left: 124px;}
.m-l-125, .m-lr-125, .m-all-125 {margin-left: 125px;}
.m-l-126, .m-lr-126, .m-all-126 {margin-left: 126px;}
.m-l-127, .m-lr-127, .m-all-127 {margin-left: 127px;}
.m-l-128, .m-lr-128, .m-all-128 {margin-left: 128px;}
.m-l-129, .m-lr-129, .m-all-129 {margin-left: 129px;}
.m-l-130, .m-lr-130, .m-all-130 {margin-left: 130px;}
.m-l-131, .m-lr-131, .m-all-131 {margin-left: 131px;}
.m-l-132, .m-lr-132, .m-all-132 {margin-left: 132px;}
.m-l-133, .m-lr-133, .m-all-133 {margin-left: 133px;}
.m-l-134, .m-lr-134, .m-all-134 {margin-left: 134px;}
.m-l-135, .m-lr-135, .m-all-135 {margin-left: 135px;}
.m-l-136, .m-lr-136, .m-all-136 {margin-left: 136px;}
.m-l-137, .m-lr-137, .m-all-137 {margin-left: 137px;}
.m-l-138, .m-lr-138, .m-all-138 {margin-left: 138px;}
.m-l-139, .m-lr-139, .m-all-139 {margin-left: 139px;}
.m-l-140, .m-lr-140, .m-all-140 {margin-left: 140px;}
.m-l-141, .m-lr-141, .m-all-141 {margin-left: 141px;}
.m-l-142, .m-lr-142, .m-all-142 {margin-left: 142px;}
.m-l-143, .m-lr-143, .m-all-143 {margin-left: 143px;}
.m-l-144, .m-lr-144, .m-all-144 {margin-left: 144px;}
.m-l-145, .m-lr-145, .m-all-145 {margin-left: 145px;}
.m-l-146, .m-lr-146, .m-all-146 {margin-left: 146px;}
.m-l-147, .m-lr-147, .m-all-147 {margin-left: 147px;}
.m-l-148, .m-lr-148, .m-all-148 {margin-left: 148px;}
.m-l-149, .m-lr-149, .m-all-149 {margin-left: 149px;}
.m-l-150, .m-lr-150, .m-all-150 {margin-left: 150px;}
.m-l-151, .m-lr-151, .m-all-151 {margin-left: 151px;}
.m-l-152, .m-lr-152, .m-all-152 {margin-left: 152px;}
.m-l-153, .m-lr-153, .m-all-153 {margin-left: 153px;}
.m-l-154, .m-lr-154, .m-all-154 {margin-left: 154px;}
.m-l-155, .m-lr-155, .m-all-155 {margin-left: 155px;}
.m-l-156, .m-lr-156, .m-all-156 {margin-left: 156px;}
.m-l-157, .m-lr-157, .m-all-157 {margin-left: 157px;}
.m-l-158, .m-lr-158, .m-all-158 {margin-left: 158px;}
.m-l-159, .m-lr-159, .m-all-159 {margin-left: 159px;}
.m-l-160, .m-lr-160, .m-all-160 {margin-left: 160px;}
.m-l-161, .m-lr-161, .m-all-161 {margin-left: 161px;}
.m-l-162, .m-lr-162, .m-all-162 {margin-left: 162px;}
.m-l-163, .m-lr-163, .m-all-163 {margin-left: 163px;}
.m-l-164, .m-lr-164, .m-all-164 {margin-left: 164px;}
.m-l-165, .m-lr-165, .m-all-165 {margin-left: 165px;}
.m-l-166, .m-lr-166, .m-all-166 {margin-left: 166px;}
.m-l-167, .m-lr-167, .m-all-167 {margin-left: 167px;}
.m-l-168, .m-lr-168, .m-all-168 {margin-left: 168px;}
.m-l-169, .m-lr-169, .m-all-169 {margin-left: 169px;}
.m-l-170, .m-lr-170, .m-all-170 {margin-left: 170px;}
.m-l-171, .m-lr-171, .m-all-171 {margin-left: 171px;}
.m-l-172, .m-lr-172, .m-all-172 {margin-left: 172px;}
.m-l-173, .m-lr-173, .m-all-173 {margin-left: 173px;}
.m-l-174, .m-lr-174, .m-all-174 {margin-left: 174px;}
.m-l-175, .m-lr-175, .m-all-175 {margin-left: 175px;}
.m-l-176, .m-lr-176, .m-all-176 {margin-left: 176px;}
.m-l-177, .m-lr-177, .m-all-177 {margin-left: 177px;}
.m-l-178, .m-lr-178, .m-all-178 {margin-left: 178px;}
.m-l-179, .m-lr-179, .m-all-179 {margin-left: 179px;}
.m-l-180, .m-lr-180, .m-all-180 {margin-left: 180px;}
.m-l-181, .m-lr-181, .m-all-181 {margin-left: 181px;}
.m-l-182, .m-lr-182, .m-all-182 {margin-left: 182px;}
.m-l-183, .m-lr-183, .m-all-183 {margin-left: 183px;}
.m-l-184, .m-lr-184, .m-all-184 {margin-left: 184px;}
.m-l-185, .m-lr-185, .m-all-185 {margin-left: 185px;}
.m-l-186, .m-lr-186, .m-all-186 {margin-left: 186px;}
.m-l-187, .m-lr-187, .m-all-187 {margin-left: 187px;}
.m-l-188, .m-lr-188, .m-all-188 {margin-left: 188px;}
.m-l-189, .m-lr-189, .m-all-189 {margin-left: 189px;}
.m-l-190, .m-lr-190, .m-all-190 {margin-left: 190px;}
.m-l-191, .m-lr-191, .m-all-191 {margin-left: 191px;}
.m-l-192, .m-lr-192, .m-all-192 {margin-left: 192px;}
.m-l-193, .m-lr-193, .m-all-193 {margin-left: 193px;}
.m-l-194, .m-lr-194, .m-all-194 {margin-left: 194px;}
.m-l-195, .m-lr-195, .m-all-195 {margin-left: 195px;}
.m-l-196, .m-lr-196, .m-all-196 {margin-left: 196px;}
.m-l-197, .m-lr-197, .m-all-197 {margin-left: 197px;}
.m-l-198, .m-lr-198, .m-all-198 {margin-left: 198px;}
.m-l-199, .m-lr-199, .m-all-199 {margin-left: 199px;}
.m-l-200, .m-lr-200, .m-all-200 {margin-left: 200px;}
.m-l-201, .m-lr-201, .m-all-201 {margin-left: 201px;}
.m-l-202, .m-lr-202, .m-all-202 {margin-left: 202px;}
.m-l-203, .m-lr-203, .m-all-203 {margin-left: 203px;}
.m-l-204, .m-lr-204, .m-all-204 {margin-left: 204px;}
.m-l-205, .m-lr-205, .m-all-205 {margin-left: 205px;}
.m-l-206, .m-lr-206, .m-all-206 {margin-left: 206px;}
.m-l-207, .m-lr-207, .m-all-207 {margin-left: 207px;}
.m-l-208, .m-lr-208, .m-all-208 {margin-left: 208px;}
.m-l-209, .m-lr-209, .m-all-209 {margin-left: 209px;}
.m-l-210, .m-lr-210, .m-all-210 {margin-left: 210px;}
.m-l-211, .m-lr-211, .m-all-211 {margin-left: 211px;}
.m-l-212, .m-lr-212, .m-all-212 {margin-left: 212px;}
.m-l-213, .m-lr-213, .m-all-213 {margin-left: 213px;}
.m-l-214, .m-lr-214, .m-all-214 {margin-left: 214px;}
.m-l-215, .m-lr-215, .m-all-215 {margin-left: 215px;}
.m-l-216, .m-lr-216, .m-all-216 {margin-left: 216px;}
.m-l-217, .m-lr-217, .m-all-217 {margin-left: 217px;}
.m-l-218, .m-lr-218, .m-all-218 {margin-left: 218px;}
.m-l-219, .m-lr-219, .m-all-219 {margin-left: 219px;}
.m-l-220, .m-lr-220, .m-all-220 {margin-left: 220px;}
.m-l-221, .m-lr-221, .m-all-221 {margin-left: 221px;}
.m-l-222, .m-lr-222, .m-all-222 {margin-left: 222px;}
.m-l-223, .m-lr-223, .m-all-223 {margin-left: 223px;}
.m-l-224, .m-lr-224, .m-all-224 {margin-left: 224px;}
.m-l-225, .m-lr-225, .m-all-225 {margin-left: 225px;}
.m-l-226, .m-lr-226, .m-all-226 {margin-left: 226px;}
.m-l-227, .m-lr-227, .m-all-227 {margin-left: 227px;}
.m-l-228, .m-lr-228, .m-all-228 {margin-left: 228px;}
.m-l-229, .m-lr-229, .m-all-229 {margin-left: 229px;}
.m-l-230, .m-lr-230, .m-all-230 {margin-left: 230px;}
.m-l-231, .m-lr-231, .m-all-231 {margin-left: 231px;}
.m-l-232, .m-lr-232, .m-all-232 {margin-left: 232px;}
.m-l-233, .m-lr-233, .m-all-233 {margin-left: 233px;}
.m-l-234, .m-lr-234, .m-all-234 {margin-left: 234px;}
.m-l-235, .m-lr-235, .m-all-235 {margin-left: 235px;}
.m-l-236, .m-lr-236, .m-all-236 {margin-left: 236px;}
.m-l-237, .m-lr-237, .m-all-237 {margin-left: 237px;}
.m-l-238, .m-lr-238, .m-all-238 {margin-left: 238px;}
.m-l-239, .m-lr-239, .m-all-239 {margin-left: 239px;}
.m-l-240, .m-lr-240, .m-all-240 {margin-left: 240px;}
.m-l-241, .m-lr-241, .m-all-241 {margin-left: 241px;}
.m-l-242, .m-lr-242, .m-all-242 {margin-left: 242px;}
.m-l-243, .m-lr-243, .m-all-243 {margin-left: 243px;}
.m-l-244, .m-lr-244, .m-all-244 {margin-left: 244px;}
.m-l-245, .m-lr-245, .m-all-245 {margin-left: 245px;}
.m-l-246, .m-lr-246, .m-all-246 {margin-left: 246px;}
.m-l-247, .m-lr-247, .m-all-247 {margin-left: 247px;}
.m-l-248, .m-lr-248, .m-all-248 {margin-left: 248px;}
.m-l-249, .m-lr-249, .m-all-249 {margin-left: 249px;}
.m-l-250, .m-lr-250, .m-all-250 {margin-left: 250px;}
.m-l-251, .m-lr-251, .m-all-251 {margin-left: 251px;}
.m-l-252, .m-lr-252, .m-all-252 {margin-left: 252px;}
.m-l-253, .m-lr-253, .m-all-253 {margin-left: 253px;}
.m-l-254, .m-lr-254, .m-all-254 {margin-left: 254px;}
.m-l-255, .m-lr-255, .m-all-255 {margin-left: 255px;}
.m-l-256, .m-lr-256, .m-all-256 {margin-left: 256px;}
.m-l-257, .m-lr-257, .m-all-257 {margin-left: 257px;}
.m-l-258, .m-lr-258, .m-all-258 {margin-left: 258px;}
.m-l-259, .m-lr-259, .m-all-259 {margin-left: 259px;}
.m-l-260, .m-lr-260, .m-all-260 {margin-left: 260px;}
.m-l-261, .m-lr-261, .m-all-261 {margin-left: 261px;}
.m-l-262, .m-lr-262, .m-all-262 {margin-left: 262px;}
.m-l-263, .m-lr-263, .m-all-263 {margin-left: 263px;}
.m-l-264, .m-lr-264, .m-all-264 {margin-left: 264px;}
.m-l-265, .m-lr-265, .m-all-265 {margin-left: 265px;}
.m-l-266, .m-lr-266, .m-all-266 {margin-left: 266px;}
.m-l-267, .m-lr-267, .m-all-267 {margin-left: 267px;}
.m-l-268, .m-lr-268, .m-all-268 {margin-left: 268px;}
.m-l-269, .m-lr-269, .m-all-269 {margin-left: 269px;}
.m-l-270, .m-lr-270, .m-all-270 {margin-left: 270px;}
.m-l-271, .m-lr-271, .m-all-271 {margin-left: 271px;}
.m-l-272, .m-lr-272, .m-all-272 {margin-left: 272px;}
.m-l-273, .m-lr-273, .m-all-273 {margin-left: 273px;}
.m-l-274, .m-lr-274, .m-all-274 {margin-left: 274px;}
.m-l-275, .m-lr-275, .m-all-275 {margin-left: 275px;}
.m-l-276, .m-lr-276, .m-all-276 {margin-left: 276px;}
.m-l-277, .m-lr-277, .m-all-277 {margin-left: 277px;}
.m-l-278, .m-lr-278, .m-all-278 {margin-left: 278px;}
.m-l-279, .m-lr-279, .m-all-279 {margin-left: 279px;}
.m-l-280, .m-lr-280, .m-all-280 {margin-left: 280px;}
.m-l-281, .m-lr-281, .m-all-281 {margin-left: 281px;}
.m-l-282, .m-lr-282, .m-all-282 {margin-left: 282px;}
.m-l-283, .m-lr-283, .m-all-283 {margin-left: 283px;}
.m-l-284, .m-lr-284, .m-all-284 {margin-left: 284px;}
.m-l-285, .m-lr-285, .m-all-285 {margin-left: 285px;}
.m-l-286, .m-lr-286, .m-all-286 {margin-left: 286px;}
.m-l-287, .m-lr-287, .m-all-287 {margin-left: 287px;}
.m-l-288, .m-lr-288, .m-all-288 {margin-left: 288px;}
.m-l-289, .m-lr-289, .m-all-289 {margin-left: 289px;}
.m-l-290, .m-lr-290, .m-all-290 {margin-left: 290px;}
.m-l-291, .m-lr-291, .m-all-291 {margin-left: 291px;}
.m-l-292, .m-lr-292, .m-all-292 {margin-left: 292px;}
.m-l-293, .m-lr-293, .m-all-293 {margin-left: 293px;}
.m-l-294, .m-lr-294, .m-all-294 {margin-left: 294px;}
.m-l-295, .m-lr-295, .m-all-295 {margin-left: 295px;}
.m-l-296, .m-lr-296, .m-all-296 {margin-left: 296px;}
.m-l-297, .m-lr-297, .m-all-297 {margin-left: 297px;}
.m-l-298, .m-lr-298, .m-all-298 {margin-left: 298px;}
.m-l-299, .m-lr-299, .m-all-299 {margin-left: 299px;}
.m-l-300, .m-lr-300, .m-all-300 {margin-left: 300px;}
.m-r-0, .m-lr-0, .m-all-0 {margin-right: 0px;}
.m-r-1, .m-lr-1, .m-all-1 {margin-right: 1px;}
.m-r-2, .m-lr-2, .m-all-2 {margin-right: 2px;}
.m-r-3, .m-lr-3, .m-all-3 {margin-right: 3px;}
.m-r-4, .m-lr-4, .m-all-4 {margin-right: 4px;}
.m-r-5, .m-lr-5, .m-all-5 {margin-right: 5px;}
.m-r-6, .m-lr-6, .m-all-6 {margin-right: 6px;}
.m-r-7, .m-lr-7, .m-all-7 {margin-right: 7px;}
.m-r-8, .m-lr-8, .m-all-8 {margin-right: 8px;}
.m-r-9, .m-lr-9, .m-all-9 {margin-right: 9px;}
.m-r-10, .m-lr-10, .m-all-10 {margin-right: 10px;}
.m-r-11, .m-lr-11, .m-all-11 {margin-right: 11px;}
.m-r-12, .m-lr-12, .m-all-12 {margin-right: 12px;}
.m-r-13, .m-lr-13, .m-all-13 {margin-right: 13px;}
.m-r-14, .m-lr-14, .m-all-14 {margin-right: 14px;}
.m-r-15, .m-lr-15, .m-all-15 {margin-right: 15px;}
.m-r-16, .m-lr-16, .m-all-16 {margin-right: 16px;}
.m-r-17, .m-lr-17, .m-all-17 {margin-right: 17px;}
.m-r-18, .m-lr-18, .m-all-18 {margin-right: 18px;}
.m-r-19, .m-lr-19, .m-all-19 {margin-right: 19px;}
.m-r-20, .m-lr-20, .m-all-20 {margin-right: 20px;}
.m-r-21, .m-lr-21, .m-all-21 {margin-right: 21px;}
.m-r-22, .m-lr-22, .m-all-22 {margin-right: 22px;}
.m-r-23, .m-lr-23, .m-all-23 {margin-right: 23px;}
.m-r-24, .m-lr-24, .m-all-24 {margin-right: 24px;}
.m-r-25, .m-lr-25, .m-all-25 {margin-right: 25px;}
.m-r-26, .m-lr-26, .m-all-26 {margin-right: 26px;}
.m-r-27, .m-lr-27, .m-all-27 {margin-right: 27px;}
.m-r-28, .m-lr-28, .m-all-28 {margin-right: 28px;}
.m-r-29, .m-lr-29, .m-all-29 {margin-right: 29px;}
.m-r-30, .m-lr-30, .m-all-30 {margin-right: 30px;}
.m-r-31, .m-lr-31, .m-all-31 {margin-right: 31px;}
.m-r-32, .m-lr-32, .m-all-32 {margin-right: 32px;}
.m-r-33, .m-lr-33, .m-all-33 {margin-right: 33px;}
.m-r-34, .m-lr-34, .m-all-34 {margin-right: 34px;}
.m-r-35, .m-lr-35, .m-all-35 {margin-right: 35px;}
.m-r-36, .m-lr-36, .m-all-36 {margin-right: 36px;}
.m-r-37, .m-lr-37, .m-all-37 {margin-right: 37px;}
.m-r-38, .m-lr-38, .m-all-38 {margin-right: 38px;}
.m-r-39, .m-lr-39, .m-all-39 {margin-right: 39px;}
.m-r-40, .m-lr-40, .m-all-40 {margin-right: 40px;}
.m-r-41, .m-lr-41, .m-all-41 {margin-right: 41px;}
.m-r-42, .m-lr-42, .m-all-42 {margin-right: 42px;}
.m-r-43, .m-lr-43, .m-all-43 {margin-right: 43px;}
.m-r-44, .m-lr-44, .m-all-44 {margin-right: 44px;}
.m-r-45, .m-lr-45, .m-all-45 {margin-right: 45px;}
.m-r-46, .m-lr-46, .m-all-46 {margin-right: 46px;}
.m-r-47, .m-lr-47, .m-all-47 {margin-right: 47px;}
.m-r-48, .m-lr-48, .m-all-48 {margin-right: 48px;}
.m-r-49, .m-lr-49, .m-all-49 {margin-right: 49px;}
.m-r-50, .m-lr-50, .m-all-50 {margin-right: 50px;}
.m-r-51, .m-lr-51, .m-all-51 {margin-right: 51px;}
.m-r-52, .m-lr-52, .m-all-52 {margin-right: 52px;}
.m-r-53, .m-lr-53, .m-all-53 {margin-right: 53px;}
.m-r-54, .m-lr-54, .m-all-54 {margin-right: 54px;}
.m-r-55, .m-lr-55, .m-all-55 {margin-right: 55px;}
.m-r-56, .m-lr-56, .m-all-56 {margin-right: 56px;}
.m-r-57, .m-lr-57, .m-all-57 {margin-right: 57px;}
.m-r-58, .m-lr-58, .m-all-58 {margin-right: 58px;}
.m-r-59, .m-lr-59, .m-all-59 {margin-right: 59px;}
.m-r-60, .m-lr-60, .m-all-60 {margin-right: 60px;}
.m-r-61, .m-lr-61, .m-all-61 {margin-right: 61px;}
.m-r-62, .m-lr-62, .m-all-62 {margin-right: 62px;}
.m-r-63, .m-lr-63, .m-all-63 {margin-right: 63px;}
.m-r-64, .m-lr-64, .m-all-64 {margin-right: 64px;}
.m-r-65, .m-lr-65, .m-all-65 {margin-right: 65px;}
.m-r-66, .m-lr-66, .m-all-66 {margin-right: 66px;}
.m-r-67, .m-lr-67, .m-all-67 {margin-right: 67px;}
.m-r-68, .m-lr-68, .m-all-68 {margin-right: 68px;}
.m-r-69, .m-lr-69, .m-all-69 {margin-right: 69px;}
.m-r-70, .m-lr-70, .m-all-70 {margin-right: 70px;}
.m-r-71, .m-lr-71, .m-all-71 {margin-right: 71px;}
.m-r-72, .m-lr-72, .m-all-72 {margin-right: 72px;}
.m-r-73, .m-lr-73, .m-all-73 {margin-right: 73px;}
.m-r-74, .m-lr-74, .m-all-74 {margin-right: 74px;}
.m-r-75, .m-lr-75, .m-all-75 {margin-right: 75px;}
.m-r-76, .m-lr-76, .m-all-76 {margin-right: 76px;}
.m-r-77, .m-lr-77, .m-all-77 {margin-right: 77px;}
.m-r-78, .m-lr-78, .m-all-78 {margin-right: 78px;}
.m-r-79, .m-lr-79, .m-all-79 {margin-right: 79px;}
.m-r-80, .m-lr-80, .m-all-80 {margin-right: 80px;}
.m-r-81, .m-lr-81, .m-all-81 {margin-right: 81px;}
.m-r-82, .m-lr-82, .m-all-82 {margin-right: 82px;}
.m-r-83, .m-lr-83, .m-all-83 {margin-right: 83px;}
.m-r-84, .m-lr-84, .m-all-84 {margin-right: 84px;}
.m-r-85, .m-lr-85, .m-all-85 {margin-right: 85px;}
.m-r-86, .m-lr-86, .m-all-86 {margin-right: 86px;}
.m-r-87, .m-lr-87, .m-all-87 {margin-right: 87px;}
.m-r-88, .m-lr-88, .m-all-88 {margin-right: 88px;}
.m-r-89, .m-lr-89, .m-all-89 {margin-right: 89px;}
.m-r-90, .m-lr-90, .m-all-90 {margin-right: 90px;}
.m-r-91, .m-lr-91, .m-all-91 {margin-right: 91px;}
.m-r-92, .m-lr-92, .m-all-92 {margin-right: 92px;}
.m-r-93, .m-lr-93, .m-all-93 {margin-right: 93px;}
.m-r-94, .m-lr-94, .m-all-94 {margin-right: 94px;}
.m-r-95, .m-lr-95, .m-all-95 {margin-right: 95px;}
.m-r-96, .m-lr-96, .m-all-96 {margin-right: 96px;}
.m-r-97, .m-lr-97, .m-all-97 {margin-right: 97px;}
.m-r-98, .m-lr-98, .m-all-98 {margin-right: 98px;}
.m-r-99, .m-lr-99, .m-all-99 {margin-right: 99px;}
.m-r-100, .m-lr-100, .m-all-100 {margin-right: 100px;}
.m-r-101, .m-lr-101, .m-all-101 {margin-right: 101px;}
.m-r-102, .m-lr-102, .m-all-102 {margin-right: 102px;}
.m-r-103, .m-lr-103, .m-all-103 {margin-right: 103px;}
.m-r-104, .m-lr-104, .m-all-104 {margin-right: 104px;}
.m-r-105, .m-lr-105, .m-all-105 {margin-right: 105px;}
.m-r-106, .m-lr-106, .m-all-106 {margin-right: 106px;}
.m-r-107, .m-lr-107, .m-all-107 {margin-right: 107px;}
.m-r-108, .m-lr-108, .m-all-108 {margin-right: 108px;}
.m-r-109, .m-lr-109, .m-all-109 {margin-right: 109px;}
.m-r-110, .m-lr-110, .m-all-110 {margin-right: 110px;}
.m-r-111, .m-lr-111, .m-all-111 {margin-right: 111px;}
.m-r-112, .m-lr-112, .m-all-112 {margin-right: 112px;}
.m-r-113, .m-lr-113, .m-all-113 {margin-right: 113px;}
.m-r-114, .m-lr-114, .m-all-114 {margin-right: 114px;}
.m-r-115, .m-lr-115, .m-all-115 {margin-right: 115px;}
.m-r-116, .m-lr-116, .m-all-116 {margin-right: 116px;}
.m-r-117, .m-lr-117, .m-all-117 {margin-right: 117px;}
.m-r-118, .m-lr-118, .m-all-118 {margin-right: 118px;}
.m-r-119, .m-lr-119, .m-all-119 {margin-right: 119px;}
.m-r-120, .m-lr-120, .m-all-120 {margin-right: 120px;}
.m-r-121, .m-lr-121, .m-all-121 {margin-right: 121px;}
.m-r-122, .m-lr-122, .m-all-122 {margin-right: 122px;}
.m-r-123, .m-lr-123, .m-all-123 {margin-right: 123px;}
.m-r-124, .m-lr-124, .m-all-124 {margin-right: 124px;}
.m-r-125, .m-lr-125, .m-all-125 {margin-right: 125px;}
.m-r-126, .m-lr-126, .m-all-126 {margin-right: 126px;}
.m-r-127, .m-lr-127, .m-all-127 {margin-right: 127px;}
.m-r-128, .m-lr-128, .m-all-128 {margin-right: 128px;}
.m-r-129, .m-lr-129, .m-all-129 {margin-right: 129px;}
.m-r-130, .m-lr-130, .m-all-130 {margin-right: 130px;}
.m-r-131, .m-lr-131, .m-all-131 {margin-right: 131px;}
.m-r-132, .m-lr-132, .m-all-132 {margin-right: 132px;}
.m-r-133, .m-lr-133, .m-all-133 {margin-right: 133px;}
.m-r-134, .m-lr-134, .m-all-134 {margin-right: 134px;}
.m-r-135, .m-lr-135, .m-all-135 {margin-right: 135px;}
.m-r-136, .m-lr-136, .m-all-136 {margin-right: 136px;}
.m-r-137, .m-lr-137, .m-all-137 {margin-right: 137px;}
.m-r-138, .m-lr-138, .m-all-138 {margin-right: 138px;}
.m-r-139, .m-lr-139, .m-all-139 {margin-right: 139px;}
.m-r-140, .m-lr-140, .m-all-140 {margin-right: 140px;}
.m-r-141, .m-lr-141, .m-all-141 {margin-right: 141px;}
.m-r-142, .m-lr-142, .m-all-142 {margin-right: 142px;}
.m-r-143, .m-lr-143, .m-all-143 {margin-right: 143px;}
.m-r-144, .m-lr-144, .m-all-144 {margin-right: 144px;}
.m-r-145, .m-lr-145, .m-all-145 {margin-right: 145px;}
.m-r-146, .m-lr-146, .m-all-146 {margin-right: 146px;}
.m-r-147, .m-lr-147, .m-all-147 {margin-right: 147px;}
.m-r-148, .m-lr-148, .m-all-148 {margin-right: 148px;}
.m-r-149, .m-lr-149, .m-all-149 {margin-right: 149px;}
.m-r-150, .m-lr-150, .m-all-150 {margin-right: 150px;}
.m-r-151, .m-lr-151, .m-all-151 {margin-right: 151px;}
.m-r-152, .m-lr-152, .m-all-152 {margin-right: 152px;}
.m-r-153, .m-lr-153, .m-all-153 {margin-right: 153px;}
.m-r-154, .m-lr-154, .m-all-154 {margin-right: 154px;}
.m-r-155, .m-lr-155, .m-all-155 {margin-right: 155px;}
.m-r-156, .m-lr-156, .m-all-156 {margin-right: 156px;}
.m-r-157, .m-lr-157, .m-all-157 {margin-right: 157px;}
.m-r-158, .m-lr-158, .m-all-158 {margin-right: 158px;}
.m-r-159, .m-lr-159, .m-all-159 {margin-right: 159px;}
.m-r-160, .m-lr-160, .m-all-160 {margin-right: 160px;}
.m-r-161, .m-lr-161, .m-all-161 {margin-right: 161px;}
.m-r-162, .m-lr-162, .m-all-162 {margin-right: 162px;}
.m-r-163, .m-lr-163, .m-all-163 {margin-right: 163px;}
.m-r-164, .m-lr-164, .m-all-164 {margin-right: 164px;}
.m-r-165, .m-lr-165, .m-all-165 {margin-right: 165px;}
.m-r-166, .m-lr-166, .m-all-166 {margin-right: 166px;}
.m-r-167, .m-lr-167, .m-all-167 {margin-right: 167px;}
.m-r-168, .m-lr-168, .m-all-168 {margin-right: 168px;}
.m-r-169, .m-lr-169, .m-all-169 {margin-right: 169px;}
.m-r-170, .m-lr-170, .m-all-170 {margin-right: 170px;}
.m-r-171, .m-lr-171, .m-all-171 {margin-right: 171px;}
.m-r-172, .m-lr-172, .m-all-172 {margin-right: 172px;}
.m-r-173, .m-lr-173, .m-all-173 {margin-right: 173px;}
.m-r-174, .m-lr-174, .m-all-174 {margin-right: 174px;}
.m-r-175, .m-lr-175, .m-all-175 {margin-right: 175px;}
.m-r-176, .m-lr-176, .m-all-176 {margin-right: 176px;}
.m-r-177, .m-lr-177, .m-all-177 {margin-right: 177px;}
.m-r-178, .m-lr-178, .m-all-178 {margin-right: 178px;}
.m-r-179, .m-lr-179, .m-all-179 {margin-right: 179px;}
.m-r-180, .m-lr-180, .m-all-180 {margin-right: 180px;}
.m-r-181, .m-lr-181, .m-all-181 {margin-right: 181px;}
.m-r-182, .m-lr-182, .m-all-182 {margin-right: 182px;}
.m-r-183, .m-lr-183, .m-all-183 {margin-right: 183px;}
.m-r-184, .m-lr-184, .m-all-184 {margin-right: 184px;}
.m-r-185, .m-lr-185, .m-all-185 {margin-right: 185px;}
.m-r-186, .m-lr-186, .m-all-186 {margin-right: 186px;}
.m-r-187, .m-lr-187, .m-all-187 {margin-right: 187px;}
.m-r-188, .m-lr-188, .m-all-188 {margin-right: 188px;}
.m-r-189, .m-lr-189, .m-all-189 {margin-right: 189px;}
.m-r-190, .m-lr-190, .m-all-190 {margin-right: 190px;}
.m-r-191, .m-lr-191, .m-all-191 {margin-right: 191px;}
.m-r-192, .m-lr-192, .m-all-192 {margin-right: 192px;}
.m-r-193, .m-lr-193, .m-all-193 {margin-right: 193px;}
.m-r-194, .m-lr-194, .m-all-194 {margin-right: 194px;}
.m-r-195, .m-lr-195, .m-all-195 {margin-right: 195px;}
.m-r-196, .m-lr-196, .m-all-196 {margin-right: 196px;}
.m-r-197, .m-lr-197, .m-all-197 {margin-right: 197px;}
.m-r-198, .m-lr-198, .m-all-198 {margin-right: 198px;}
.m-r-199, .m-lr-199, .m-all-199 {margin-right: 199px;}
.m-r-200, .m-lr-200, .m-all-200 {margin-right: 200px;}
.m-r-201, .m-lr-201, .m-all-201 {margin-right: 201px;}
.m-r-202, .m-lr-202, .m-all-202 {margin-right: 202px;}
.m-r-203, .m-lr-203, .m-all-203 {margin-right: 203px;}
.m-r-204, .m-lr-204, .m-all-204 {margin-right: 204px;}
.m-r-205, .m-lr-205, .m-all-205 {margin-right: 205px;}
.m-r-206, .m-lr-206, .m-all-206 {margin-right: 206px;}
.m-r-207, .m-lr-207, .m-all-207 {margin-right: 207px;}
.m-r-208, .m-lr-208, .m-all-208 {margin-right: 208px;}
.m-r-209, .m-lr-209, .m-all-209 {margin-right: 209px;}
.m-r-210, .m-lr-210, .m-all-210 {margin-right: 210px;}
.m-r-211, .m-lr-211, .m-all-211 {margin-right: 211px;}
.m-r-212, .m-lr-212, .m-all-212 {margin-right: 212px;}
.m-r-213, .m-lr-213, .m-all-213 {margin-right: 213px;}
.m-r-214, .m-lr-214, .m-all-214 {margin-right: 214px;}
.m-r-215, .m-lr-215, .m-all-215 {margin-right: 215px;}
.m-r-216, .m-lr-216, .m-all-216 {margin-right: 216px;}
.m-r-217, .m-lr-217, .m-all-217 {margin-right: 217px;}
.m-r-218, .m-lr-218, .m-all-218 {margin-right: 218px;}
.m-r-219, .m-lr-219, .m-all-219 {margin-right: 219px;}
.m-r-220, .m-lr-220, .m-all-220 {margin-right: 220px;}
.m-r-221, .m-lr-221, .m-all-221 {margin-right: 221px;}
.m-r-222, .m-lr-222, .m-all-222 {margin-right: 222px;}
.m-r-223, .m-lr-223, .m-all-223 {margin-right: 223px;}
.m-r-224, .m-lr-224, .m-all-224 {margin-right: 224px;}
.m-r-225, .m-lr-225, .m-all-225 {margin-right: 225px;}
.m-r-226, .m-lr-226, .m-all-226 {margin-right: 226px;}
.m-r-227, .m-lr-227, .m-all-227 {margin-right: 227px;}
.m-r-228, .m-lr-228, .m-all-228 {margin-right: 228px;}
.m-r-229, .m-lr-229, .m-all-229 {margin-right: 229px;}
.m-r-230, .m-lr-230, .m-all-230 {margin-right: 230px;}
.m-r-231, .m-lr-231, .m-all-231 {margin-right: 231px;}
.m-r-232, .m-lr-232, .m-all-232 {margin-right: 232px;}
.m-r-233, .m-lr-233, .m-all-233 {margin-right: 233px;}
.m-r-234, .m-lr-234, .m-all-234 {margin-right: 234px;}
.m-r-235, .m-lr-235, .m-all-235 {margin-right: 235px;}
.m-r-236, .m-lr-236, .m-all-236 {margin-right: 236px;}
.m-r-237, .m-lr-237, .m-all-237 {margin-right: 237px;}
.m-r-238, .m-lr-238, .m-all-238 {margin-right: 238px;}
.m-r-239, .m-lr-239, .m-all-239 {margin-right: 239px;}
.m-r-240, .m-lr-240, .m-all-240 {margin-right: 240px;}
.m-r-241, .m-lr-241, .m-all-241 {margin-right: 241px;}
.m-r-242, .m-lr-242, .m-all-242 {margin-right: 242px;}
.m-r-243, .m-lr-243, .m-all-243 {margin-right: 243px;}
.m-r-244, .m-lr-244, .m-all-244 {margin-right: 244px;}
.m-r-245, .m-lr-245, .m-all-245 {margin-right: 245px;}
.m-r-246, .m-lr-246, .m-all-246 {margin-right: 246px;}
.m-r-247, .m-lr-247, .m-all-247 {margin-right: 247px;}
.m-r-248, .m-lr-248, .m-all-248 {margin-right: 248px;}
.m-r-249, .m-lr-249, .m-all-249 {margin-right: 249px;}
.m-r-250, .m-lr-250, .m-all-250 {margin-right: 250px;}
.m-r-251, .m-lr-251, .m-all-251 {margin-right: 251px;}
.m-r-252, .m-lr-252, .m-all-252 {margin-right: 252px;}
.m-r-253, .m-lr-253, .m-all-253 {margin-right: 253px;}
.m-r-254, .m-lr-254, .m-all-254 {margin-right: 254px;}
.m-r-255, .m-lr-255, .m-all-255 {margin-right: 255px;}
.m-r-256, .m-lr-256, .m-all-256 {margin-right: 256px;}
.m-r-257, .m-lr-257, .m-all-257 {margin-right: 257px;}
.m-r-258, .m-lr-258, .m-all-258 {margin-right: 258px;}
.m-r-259, .m-lr-259, .m-all-259 {margin-right: 259px;}
.m-r-260, .m-lr-260, .m-all-260 {margin-right: 260px;}
.m-r-261, .m-lr-261, .m-all-261 {margin-right: 261px;}
.m-r-262, .m-lr-262, .m-all-262 {margin-right: 262px;}
.m-r-263, .m-lr-263, .m-all-263 {margin-right: 263px;}
.m-r-264, .m-lr-264, .m-all-264 {margin-right: 264px;}
.m-r-265, .m-lr-265, .m-all-265 {margin-right: 265px;}
.m-r-266, .m-lr-266, .m-all-266 {margin-right: 266px;}
.m-r-267, .m-lr-267, .m-all-267 {margin-right: 267px;}
.m-r-268, .m-lr-268, .m-all-268 {margin-right: 268px;}
.m-r-269, .m-lr-269, .m-all-269 {margin-right: 269px;}
.m-r-270, .m-lr-270, .m-all-270 {margin-right: 270px;}
.m-r-271, .m-lr-271, .m-all-271 {margin-right: 271px;}
.m-r-272, .m-lr-272, .m-all-272 {margin-right: 272px;}
.m-r-273, .m-lr-273, .m-all-273 {margin-right: 273px;}
.m-r-274, .m-lr-274, .m-all-274 {margin-right: 274px;}
.m-r-275, .m-lr-275, .m-all-275 {margin-right: 275px;}
.m-r-276, .m-lr-276, .m-all-276 {margin-right: 276px;}
.m-r-277, .m-lr-277, .m-all-277 {margin-right: 277px;}
.m-r-278, .m-lr-278, .m-all-278 {margin-right: 278px;}
.m-r-279, .m-lr-279, .m-all-279 {margin-right: 279px;}
.m-r-280, .m-lr-280, .m-all-280 {margin-right: 280px;}
.m-r-281, .m-lr-281, .m-all-281 {margin-right: 281px;}
.m-r-282, .m-lr-282, .m-all-282 {margin-right: 282px;}
.m-r-283, .m-lr-283, .m-all-283 {margin-right: 283px;}
.m-r-284, .m-lr-284, .m-all-284 {margin-right: 284px;}
.m-r-285, .m-lr-285, .m-all-285 {margin-right: 285px;}
.m-r-286, .m-lr-286, .m-all-286 {margin-right: 286px;}
.m-r-287, .m-lr-287, .m-all-287 {margin-right: 287px;}
.m-r-288, .m-lr-288, .m-all-288 {margin-right: 288px;}
.m-r-289, .m-lr-289, .m-all-289 {margin-right: 289px;}
.m-r-290, .m-lr-290, .m-all-290 {margin-right: 290px;}
.m-r-291, .m-lr-291, .m-all-291 {margin-right: 291px;}
.m-r-292, .m-lr-292, .m-all-292 {margin-right: 292px;}
.m-r-293, .m-lr-293, .m-all-293 {margin-right: 293px;}
.m-r-294, .m-lr-294, .m-all-294 {margin-right: 294px;}
.m-r-295, .m-lr-295, .m-all-295 {margin-right: 295px;}
.m-r-296, .m-lr-296, .m-all-296 {margin-right: 296px;}
.m-r-297, .m-lr-297, .m-all-297 {margin-right: 297px;}
.m-r-298, .m-lr-298, .m-all-298 {margin-right: 298px;}
.m-r-299, .m-lr-299, .m-all-299 {margin-right: 299px;}
.m-r-300, .m-lr-300, .m-all-300 {margin-right: 300px;}

.m-t--1, .m-tb--1, .m-all--1 {margin-top: -1px;}
.m-t--2, .m-tb--2, .m-all--2 {margin-top: -2px;}
.m-t--3, .m-tb--3, .m-all--3 {margin-top: -3px;}
.m-t--4, .m-tb--4, .m-all--4 {margin-top: -4px;}
.m-t--5, .m-tb--5, .m-all--5 {margin-top: -5px;}
.m-t--6, .m-tb--6, .m-all--6 {margin-top: -6px;}
.m-t--7, .m-tb--7, .m-all--7 {margin-top: -7px;}
.m-t--8, .m-tb--8, .m-all--8 {margin-top: -8px;}
.m-t--9, .m-tb--9, .m-all--9 {margin-top: -9px;}
.m-t--10, .m-tb--10, .m-all--10 {margin-top: -10px;}
.m-t--11, .m-tb--11, .m-all--11 {margin-top: -11px;}
.m-t--12, .m-tb--12, .m-all--12 {margin-top: -12px;}
.m-t--13, .m-tb--13, .m-all--13 {margin-top: -13px;}
.m-t--14, .m-tb--14, .m-all--14 {margin-top: -14px;}
.m-t--15, .m-tb--15, .m-all--15 {margin-top: -15px;}
.m-t--16, .m-tb--16, .m-all--16 {margin-top: -16px;}
.m-t--17, .m-tb--17, .m-all--17 {margin-top: -17px;}
.m-t--18, .m-tb--18, .m-all--18 {margin-top: -18px;}
.m-t--19, .m-tb--19, .m-all--19 {margin-top: -19px;}
.m-t--20, .m-tb--20, .m-all--20 {margin-top: -20px;}
.m-t--21, .m-tb--21, .m-all--21 {margin-top: -21px;}
.m-t--22, .m-tb--22, .m-all--22 {margin-top: -22px;}
.m-t--23, .m-tb--23, .m-all--23 {margin-top: -23px;}
.m-t--24, .m-tb--24, .m-all--24 {margin-top: -24px;}
.m-t--25, .m-tb--25, .m-all--25 {margin-top: -25px;}
.m-t--26, .m-tb--26, .m-all--26 {margin-top: -26px;}
.m-t--27, .m-tb--27, .m-all--27 {margin-top: -27px;}
.m-t--28, .m-tb--28, .m-all--28 {margin-top: -28px;}
.m-t--29, .m-tb--29, .m-all--29 {margin-top: -29px;}
.m-t--30, .m-tb--30, .m-all--30 {margin-top: -30px;}
.m-t--31, .m-tb--31, .m-all--31 {margin-top: -31px;}
.m-t--32, .m-tb--32, .m-all--32 {margin-top: -32px;}
.m-t--33, .m-tb--33, .m-all--33 {margin-top: -33px;}
.m-t--34, .m-tb--34, .m-all--34 {margin-top: -34px;}
.m-t--35, .m-tb--35, .m-all--35 {margin-top: -35px;}
.m-t--36, .m-tb--36, .m-all--36 {margin-top: -36px;}
.m-t--37, .m-tb--37, .m-all--37 {margin-top: -37px;}
.m-t--38, .m-tb--38, .m-all--38 {margin-top: -38px;}
.m-t--39, .m-tb--39, .m-all--39 {margin-top: -39px;}
.m-t--40, .m-tb--40, .m-all--40 {margin-top: -40px;}
.m-t--41, .m-tb--41, .m-all--41 {margin-top: -41px;}
.m-t--42, .m-tb--42, .m-all--42 {margin-top: -42px;}
.m-t--43, .m-tb--43, .m-all--43 {margin-top: -43px;}
.m-t--44, .m-tb--44, .m-all--44 {margin-top: -44px;}
.m-t--45, .m-tb--45, .m-all--45 {margin-top: -45px;}
.m-t--46, .m-tb--46, .m-all--46 {margin-top: -46px;}
.m-t--47, .m-tb--47, .m-all--47 {margin-top: -47px;}
.m-t--48, .m-tb--48, .m-all--48 {margin-top: -48px;}
.m-t--49, .m-tb--49, .m-all--49 {margin-top: -49px;}
.m-t--50, .m-tb--50, .m-all--50 {margin-top: -50px;}
.m-t--51, .m-tb--51, .m-all--51 {margin-top: -51px;}
.m-t--52, .m-tb--52, .m-all--52 {margin-top: -52px;}
.m-t--53, .m-tb--53, .m-all--53 {margin-top: -53px;}
.m-t--54, .m-tb--54, .m-all--54 {margin-top: -54px;}
.m-t--55, .m-tb--55, .m-all--55 {margin-top: -55px;}
.m-t--56, .m-tb--56, .m-all--56 {margin-top: -56px;}
.m-t--57, .m-tb--57, .m-all--57 {margin-top: -57px;}
.m-t--58, .m-tb--58, .m-all--58 {margin-top: -58px;}
.m-t--59, .m-tb--59, .m-all--59 {margin-top: -59px;}
.m-t--60, .m-tb--60, .m-all--60 {margin-top: -60px;}
.m-t--61, .m-tb--61, .m-all--61 {margin-top: -61px;}
.m-t--62, .m-tb--62, .m-all--62 {margin-top: -62px;}
.m-t--63, .m-tb--63, .m-all--63 {margin-top: -63px;}
.m-t--64, .m-tb--64, .m-all--64 {margin-top: -64px;}
.m-t--65, .m-tb--65, .m-all--65 {margin-top: -65px;}
.m-t--66, .m-tb--66, .m-all--66 {margin-top: -66px;}
.m-t--67, .m-tb--67, .m-all--67 {margin-top: -67px;}
.m-t--68, .m-tb--68, .m-all--68 {margin-top: -68px;}
.m-t--69, .m-tb--69, .m-all--69 {margin-top: -69px;}
.m-t--70, .m-tb--70, .m-all--70 {margin-top: -70px;}
.m-t--71, .m-tb--71, .m-all--71 {margin-top: -71px;}
.m-t--72, .m-tb--72, .m-all--72 {margin-top: -72px;}
.m-t--73, .m-tb--73, .m-all--73 {margin-top: -73px;}
.m-t--74, .m-tb--74, .m-all--74 {margin-top: -74px;}
.m-t--75, .m-tb--75, .m-all--75 {margin-top: -75px;}
.m-t--76, .m-tb--76, .m-all--76 {margin-top: -76px;}
.m-t--77, .m-tb--77, .m-all--77 {margin-top: -77px;}
.m-t--78, .m-tb--78, .m-all--78 {margin-top: -78px;}
.m-t--79, .m-tb--79, .m-all--79 {margin-top: -79px;}
.m-t--80, .m-tb--80, .m-all--80 {margin-top: -80px;}
.m-t--81, .m-tb--81, .m-all--81 {margin-top: -81px;}
.m-t--82, .m-tb--82, .m-all--82 {margin-top: -82px;}
.m-t--83, .m-tb--83, .m-all--83 {margin-top: -83px;}
.m-t--84, .m-tb--84, .m-all--84 {margin-top: -84px;}
.m-t--85, .m-tb--85, .m-all--85 {margin-top: -85px;}
.m-t--86, .m-tb--86, .m-all--86 {margin-top: -86px;}
.m-t--87, .m-tb--87, .m-all--87 {margin-top: -87px;}
.m-t--88, .m-tb--88, .m-all--88 {margin-top: -88px;}
.m-t--89, .m-tb--89, .m-all--89 {margin-top: -89px;}
.m-t--90, .m-tb--90, .m-all--90 {margin-top: -90px;}
.m-t--91, .m-tb--91, .m-all--91 {margin-top: -91px;}
.m-t--92, .m-tb--92, .m-all--92 {margin-top: -92px;}
.m-t--93, .m-tb--93, .m-all--93 {margin-top: -93px;}
.m-t--94, .m-tb--94, .m-all--94 {margin-top: -94px;}
.m-t--95, .m-tb--95, .m-all--95 {margin-top: -95px;}
.m-t--96, .m-tb--96, .m-all--96 {margin-top: -96px;}
.m-t--97, .m-tb--97, .m-all--97 {margin-top: -97px;}
.m-t--98, .m-tb--98, .m-all--98 {margin-top: -98px;}
.m-t--99, .m-tb--99, .m-all--99 {margin-top: -99px;}
.m-t--100, .m-tb--100, .m-all--100 {margin-top: -100px;}
.m-b--0, .m-tb--0, .m-all--0 {margin-bottom: -0px;}
.m-b--1, .m-tb--1, .m-all--1 {margin-bottom: -1px;}
.m-b--2, .m-tb--2, .m-all--2 {margin-bottom: -2px;}
.m-b--3, .m-tb--3, .m-all--3 {margin-bottom: -3px;}
.m-b--4, .m-tb--4, .m-all--4 {margin-bottom: -4px;}
.m-b--5, .m-tb--5, .m-all--5 {margin-bottom: -5px;}
.m-b--6, .m-tb--6, .m-all--6 {margin-bottom: -6px;}
.m-b--7, .m-tb--7, .m-all--7 {margin-bottom: -7px;}
.m-b--8, .m-tb--8, .m-all--8 {margin-bottom: -8px;}
.m-b--9, .m-tb--9, .m-all--9 {margin-bottom: -9px;}
.m-b--10, .m-tb--10, .m-all--10 {margin-bottom: -10px;}
.m-b--11, .m-tb--11, .m-all--11 {margin-bottom: -11px;}
.m-b--12, .m-tb--12, .m-all--12 {margin-bottom: -12px;}
.m-b--13, .m-tb--13, .m-all--13 {margin-bottom: -13px;}
.m-b--14, .m-tb--14, .m-all--14 {margin-bottom: -14px;}
.m-b--15, .m-tb--15, .m-all--15 {margin-bottom: -15px;}
.m-b--16, .m-tb--16, .m-all--16 {margin-bottom: -16px;}
.m-b--17, .m-tb--17, .m-all--17 {margin-bottom: -17px;}
.m-b--18, .m-tb--18, .m-all--18 {margin-bottom: -18px;}
.m-b--19, .m-tb--19, .m-all--19 {margin-bottom: -19px;}
.m-b--20, .m-tb--20, .m-all--20 {margin-bottom: -20px;}
.m-b--21, .m-tb--21, .m-all--21 {margin-bottom: -21px;}
.m-b--22, .m-tb--22, .m-all--22 {margin-bottom: -22px;}
.m-b--23, .m-tb--23, .m-all--23 {margin-bottom: -23px;}
.m-b--24, .m-tb--24, .m-all--24 {margin-bottom: -24px;}
.m-b--25, .m-tb--25, .m-all--25 {margin-bottom: -25px;}
.m-b--26, .m-tb--26, .m-all--26 {margin-bottom: -26px;}
.m-b--27, .m-tb--27, .m-all--27 {margin-bottom: -27px;}
.m-b--28, .m-tb--28, .m-all--28 {margin-bottom: -28px;}
.m-b--29, .m-tb--29, .m-all--29 {margin-bottom: -29px;}
.m-b--30, .m-tb--30, .m-all--30 {margin-bottom: -30px;}
.m-b--31, .m-tb--31, .m-all--31 {margin-bottom: -31px;}
.m-b--32, .m-tb--32, .m-all--32 {margin-bottom: -32px;}
.m-b--33, .m-tb--33, .m-all--33 {margin-bottom: -33px;}
.m-b--34, .m-tb--34, .m-all--34 {margin-bottom: -34px;}
.m-b--35, .m-tb--35, .m-all--35 {margin-bottom: -35px;}
.m-b--36, .m-tb--36, .m-all--36 {margin-bottom: -36px;}
.m-b--37, .m-tb--37, .m-all--37 {margin-bottom: -37px;}
.m-b--38, .m-tb--38, .m-all--38 {margin-bottom: -38px;}
.m-b--39, .m-tb--39, .m-all--39 {margin-bottom: -39px;}
.m-b--40, .m-tb--40, .m-all--40 {margin-bottom: -40px;}
.m-b--41, .m-tb--41, .m-all--41 {margin-bottom: -41px;}
.m-b--42, .m-tb--42, .m-all--42 {margin-bottom: -42px;}
.m-b--43, .m-tb--43, .m-all--43 {margin-bottom: -43px;}
.m-b--44, .m-tb--44, .m-all--44 {margin-bottom: -44px;}
.m-b--45, .m-tb--45, .m-all--45 {margin-bottom: -45px;}
.m-b--46, .m-tb--46, .m-all--46 {margin-bottom: -46px;}
.m-b--47, .m-tb--47, .m-all--47 {margin-bottom: -47px;}
.m-b--48, .m-tb--48, .m-all--48 {margin-bottom: -48px;}
.m-b--49, .m-tb--49, .m-all--49 {margin-bottom: -49px;}
.m-b--50, .m-tb--50, .m-all--50 {margin-bottom: -50px;}
.m-b--51, .m-tb--51, .m-all--51 {margin-bottom: -51px;}
.m-b--52, .m-tb--52, .m-all--52 {margin-bottom: -52px;}
.m-b--53, .m-tb--53, .m-all--53 {margin-bottom: -53px;}
.m-b--54, .m-tb--54, .m-all--54 {margin-bottom: -54px;}
.m-b--55, .m-tb--55, .m-all--55 {margin-bottom: -55px;}
.m-b--56, .m-tb--56, .m-all--56 {margin-bottom: -56px;}
.m-b--57, .m-tb--57, .m-all--57 {margin-bottom: -57px;}
.m-b--58, .m-tb--58, .m-all--58 {margin-bottom: -58px;}
.m-b--59, .m-tb--59, .m-all--59 {margin-bottom: -59px;}
.m-b--60, .m-tb--60, .m-all--60 {margin-bottom: -60px;}
.m-b--61, .m-tb--61, .m-all--61 {margin-bottom: -61px;}
.m-b--62, .m-tb--62, .m-all--62 {margin-bottom: -62px;}
.m-b--63, .m-tb--63, .m-all--63 {margin-bottom: -63px;}
.m-b--64, .m-tb--64, .m-all--64 {margin-bottom: -64px;}
.m-b--65, .m-tb--65, .m-all--65 {margin-bottom: -65px;}
.m-b--66, .m-tb--66, .m-all--66 {margin-bottom: -66px;}
.m-b--67, .m-tb--67, .m-all--67 {margin-bottom: -67px;}
.m-b--68, .m-tb--68, .m-all--68 {margin-bottom: -68px;}
.m-b--69, .m-tb--69, .m-all--69 {margin-bottom: -69px;}
.m-b--70, .m-tb--70, .m-all--70 {margin-bottom: -70px;}
.m-b--71, .m-tb--71, .m-all--71 {margin-bottom: -71px;}
.m-b--72, .m-tb--72, .m-all--72 {margin-bottom: -72px;}
.m-b--73, .m-tb--73, .m-all--73 {margin-bottom: -73px;}
.m-b--74, .m-tb--74, .m-all--74 {margin-bottom: -74px;}
.m-b--75, .m-tb--75, .m-all--75 {margin-bottom: -75px;}
.m-b--76, .m-tb--76, .m-all--76 {margin-bottom: -76px;}
.m-b--77, .m-tb--77, .m-all--77 {margin-bottom: -77px;}
.m-b--78, .m-tb--78, .m-all--78 {margin-bottom: -78px;}
.m-b--79, .m-tb--79, .m-all--79 {margin-bottom: -79px;}
.m-b--80, .m-tb--80, .m-all--80 {margin-bottom: -80px;}
.m-b--81, .m-tb--81, .m-all--81 {margin-bottom: -81px;}
.m-b--82, .m-tb--82, .m-all--82 {margin-bottom: -82px;}
.m-b--83, .m-tb--83, .m-all--83 {margin-bottom: -83px;}
.m-b--84, .m-tb--84, .m-all--84 {margin-bottom: -84px;}
.m-b--85, .m-tb--85, .m-all--85 {margin-bottom: -85px;}
.m-b--86, .m-tb--86, .m-all--86 {margin-bottom: -86px;}
.m-b--87, .m-tb--87, .m-all--87 {margin-bottom: -87px;}
.m-b--88, .m-tb--88, .m-all--88 {margin-bottom: -88px;}
.m-b--89, .m-tb--89, .m-all--89 {margin-bottom: -89px;}
.m-b--90, .m-tb--90, .m-all--90 {margin-bottom: -90px;}
.m-b--91, .m-tb--91, .m-all--91 {margin-bottom: -91px;}
.m-b--92, .m-tb--92, .m-all--92 {margin-bottom: -92px;}
.m-b--93, .m-tb--93, .m-all--93 {margin-bottom: -93px;}
.m-b--94, .m-tb--94, .m-all--94 {margin-bottom: -94px;}
.m-b--95, .m-tb--95, .m-all--95 {margin-bottom: -95px;}
.m-b--96, .m-tb--96, .m-all--96 {margin-bottom: -96px;}
.m-b--97, .m-tb--97, .m-all--97 {margin-bottom: -97px;}
.m-b--98, .m-tb--98, .m-all--98 {margin-bottom: -98px;}
.m-b--99, .m-tb--99, .m-all--99 {margin-bottom: -99px;}
.m-b--100, .m-tb--100, .m-all--100 {margin-bottom: -100px;}
.m-l--0, .m-lr--0, .m-all--0 {margin-left: -0px;}
.m-l--1, .m-lr--1, .m-all--1 {margin-left: -1px;}
.m-l--2, .m-lr--2, .m-all--2 {margin-left: -2px;}
.m-l--3, .m-lr--3, .m-all--3 {margin-left: -3px;}
.m-l--4, .m-lr--4, .m-all--4 {margin-left: -4px;}
.m-l--5, .m-lr--5, .m-all--5 {margin-left: -5px;}
.m-l--6, .m-lr--6, .m-all--6 {margin-left: -6px;}
.m-l--7, .m-lr--7, .m-all--7 {margin-left: -7px;}
.m-l--8, .m-lr--8, .m-all--8 {margin-left: -8px;}
.m-l--9, .m-lr--9, .m-all--9 {margin-left: -9px;}
.m-l--10, .m-lr--10, .m-all--10 {margin-left: -10px;}
.m-l--11, .m-lr--11, .m-all--11 {margin-left: -11px;}
.m-l--12, .m-lr--12, .m-all--12 {margin-left: -12px;}
.m-l--13, .m-lr--13, .m-all--13 {margin-left: -13px;}
.m-l--14, .m-lr--14, .m-all--14 {margin-left: -14px;}
.m-l--15, .m-lr--15, .m-all--15 {margin-left: -15px;}
.m-l--16, .m-lr--16, .m-all--16 {margin-left: -16px;}
.m-l--17, .m-lr--17, .m-all--17 {margin-left: -17px;}
.m-l--18, .m-lr--18, .m-all--18 {margin-left: -18px;}
.m-l--19, .m-lr--19, .m-all--19 {margin-left: -19px;}
.m-l--20, .m-lr--20, .m-all--20 {margin-left: -20px;}
.m-l--21, .m-lr--21, .m-all--21 {margin-left: -21px;}
.m-l--22, .m-lr--22, .m-all--22 {margin-left: -22px;}
.m-l--23, .m-lr--23, .m-all--23 {margin-left: -23px;}
.m-l--24, .m-lr--24, .m-all--24 {margin-left: -24px;}
.m-l--25, .m-lr--25, .m-all--25 {margin-left: -25px;}
.m-l--26, .m-lr--26, .m-all--26 {margin-left: -26px;}
.m-l--27, .m-lr--27, .m-all--27 {margin-left: -27px;}
.m-l--28, .m-lr--28, .m-all--28 {margin-left: -28px;}
.m-l--29, .m-lr--29, .m-all--29 {margin-left: -29px;}
.m-l--30, .m-lr--30, .m-all--30 {margin-left: -30px;}
.m-l--31, .m-lr--31, .m-all--31 {margin-left: -31px;}
.m-l--32, .m-lr--32, .m-all--32 {margin-left: -32px;}
.m-l--33, .m-lr--33, .m-all--33 {margin-left: -33px;}
.m-l--34, .m-lr--34, .m-all--34 {margin-left: -34px;}
.m-l--35, .m-lr--35, .m-all--35 {margin-left: -35px;}
.m-l--36, .m-lr--36, .m-all--36 {margin-left: -36px;}
.m-l--37, .m-lr--37, .m-all--37 {margin-left: -37px;}
.m-l--38, .m-lr--38, .m-all--38 {margin-left: -38px;}
.m-l--39, .m-lr--39, .m-all--39 {margin-left: -39px;}
.m-l--40, .m-lr--40, .m-all--40 {margin-left: -40px;}
.m-l--41, .m-lr--41, .m-all--41 {margin-left: -41px;}
.m-l--42, .m-lr--42, .m-all--42 {margin-left: -42px;}
.m-l--43, .m-lr--43, .m-all--43 {margin-left: -43px;}
.m-l--44, .m-lr--44, .m-all--44 {margin-left: -44px;}
.m-l--45, .m-lr--45, .m-all--45 {margin-left: -45px;}
.m-l--46, .m-lr--46, .m-all--46 {margin-left: -46px;}
.m-l--47, .m-lr--47, .m-all--47 {margin-left: -47px;}
.m-l--48, .m-lr--48, .m-all--48 {margin-left: -48px;}
.m-l--49, .m-lr--49, .m-all--49 {margin-left: -49px;}
.m-l--50, .m-lr--50, .m-all--50 {margin-left: -50px;}
.m-l--51, .m-lr--51, .m-all--51 {margin-left: -51px;}
.m-l--52, .m-lr--52, .m-all--52 {margin-left: -52px;}
.m-l--53, .m-lr--53, .m-all--53 {margin-left: -53px;}
.m-l--54, .m-lr--54, .m-all--54 {margin-left: -54px;}
.m-l--55, .m-lr--55, .m-all--55 {margin-left: -55px;}
.m-l--56, .m-lr--56, .m-all--56 {margin-left: -56px;}
.m-l--57, .m-lr--57, .m-all--57 {margin-left: -57px;}
.m-l--58, .m-lr--58, .m-all--58 {margin-left: -58px;}
.m-l--59, .m-lr--59, .m-all--59 {margin-left: -59px;}
.m-l--60, .m-lr--60, .m-all--60 {margin-left: -60px;}
.m-l--61, .m-lr--61, .m-all--61 {margin-left: -61px;}
.m-l--62, .m-lr--62, .m-all--62 {margin-left: -62px;}
.m-l--63, .m-lr--63, .m-all--63 {margin-left: -63px;}
.m-l--64, .m-lr--64, .m-all--64 {margin-left: -64px;}
.m-l--65, .m-lr--65, .m-all--65 {margin-left: -65px;}
.m-l--66, .m-lr--66, .m-all--66 {margin-left: -66px;}
.m-l--67, .m-lr--67, .m-all--67 {margin-left: -67px;}
.m-l--68, .m-lr--68, .m-all--68 {margin-left: -68px;}
.m-l--69, .m-lr--69, .m-all--69 {margin-left: -69px;}
.m-l--70, .m-lr--70, .m-all--70 {margin-left: -70px;}
.m-l--71, .m-lr--71, .m-all--71 {margin-left: -71px;}
.m-l--72, .m-lr--72, .m-all--72 {margin-left: -72px;}
.m-l--73, .m-lr--73, .m-all--73 {margin-left: -73px;}
.m-l--74, .m-lr--74, .m-all--74 {margin-left: -74px;}
.m-l--75, .m-lr--75, .m-all--75 {margin-left: -75px;}
.m-l--76, .m-lr--76, .m-all--76 {margin-left: -76px;}
.m-l--77, .m-lr--77, .m-all--77 {margin-left: -77px;}
.m-l--78, .m-lr--78, .m-all--78 {margin-left: -78px;}
.m-l--79, .m-lr--79, .m-all--79 {margin-left: -79px;}
.m-l--80, .m-lr--80, .m-all--80 {margin-left: -80px;}
.m-l--81, .m-lr--81, .m-all--81 {margin-left: -81px;}
.m-l--82, .m-lr--82, .m-all--82 {margin-left: -82px;}
.m-l--83, .m-lr--83, .m-all--83 {margin-left: -83px;}
.m-l--84, .m-lr--84, .m-all--84 {margin-left: -84px;}
.m-l--85, .m-lr--85, .m-all--85 {margin-left: -85px;}
.m-l--86, .m-lr--86, .m-all--86 {margin-left: -86px;}
.m-l--87, .m-lr--87, .m-all--87 {margin-left: -87px;}
.m-l--88, .m-lr--88, .m-all--88 {margin-left: -88px;}
.m-l--89, .m-lr--89, .m-all--89 {margin-left: -89px;}
.m-l--90, .m-lr--90, .m-all--90 {margin-left: -90px;}
.m-l--91, .m-lr--91, .m-all--91 {margin-left: -91px;}
.m-l--92, .m-lr--92, .m-all--92 {margin-left: -92px;}
.m-l--93, .m-lr--93, .m-all--93 {margin-left: -93px;}
.m-l--94, .m-lr--94, .m-all--94 {margin-left: -94px;}
.m-l--95, .m-lr--95, .m-all--95 {margin-left: -95px;}
.m-l--96, .m-lr--96, .m-all--96 {margin-left: -96px;}
.m-l--97, .m-lr--97, .m-all--97 {margin-left: -97px;}
.m-l--98, .m-lr--98, .m-all--98 {margin-left: -98px;}
.m-l--99, .m-lr--99, .m-all--99 {margin-left: -99px;}
.m-l--100, .m-lr--100, .m-all--100 {margin-left: -100px;}
.m-r--0, .m-lr--0, .m-all--0 {margin-right: -0px;}
.m-r--1, .m-lr--1, .m-all--1 {margin-right: -1px;}
.m-r--2, .m-lr--2, .m-all--2 {margin-right: -2px;}
.m-r--3, .m-lr--3, .m-all--3 {margin-right: -3px;}
.m-r--4, .m-lr--4, .m-all--4 {margin-right: -4px;}
.m-r--5, .m-lr--5, .m-all--5 {margin-right: -5px;}
.m-r--6, .m-lr--6, .m-all--6 {margin-right: -6px;}
.m-r--7, .m-lr--7, .m-all--7 {margin-right: -7px;}
.m-r--8, .m-lr--8, .m-all--8 {margin-right: -8px;}
.m-r--9, .m-lr--9, .m-all--9 {margin-right: -9px;}
.m-r--10, .m-lr--10, .m-all--10 {margin-right: -10px;}
.m-r--11, .m-lr--11, .m-all--11 {margin-right: -11px;}
.m-r--12, .m-lr--12, .m-all--12 {margin-right: -12px;}
.m-r--13, .m-lr--13, .m-all--13 {margin-right: -13px;}
.m-r--14, .m-lr--14, .m-all--14 {margin-right: -14px;}
.m-r--15, .m-lr--15, .m-all--15 {margin-right: -15px;}
.m-r--16, .m-lr--16, .m-all--16 {margin-right: -16px;}
.m-r--17, .m-lr--17, .m-all--17 {margin-right: -17px;}
.m-r--18, .m-lr--18, .m-all--18 {margin-right: -18px;}
.m-r--19, .m-lr--19, .m-all--19 {margin-right: -19px;}
.m-r--20, .m-lr--20, .m-all--20 {margin-right: -20px;}
.m-r--21, .m-lr--21, .m-all--21 {margin-right: -21px;}
.m-r--22, .m-lr--22, .m-all--22 {margin-right: -22px;}
.m-r--23, .m-lr--23, .m-all--23 {margin-right: -23px;}
.m-r--24, .m-lr--24, .m-all--24 {margin-right: -24px;}
.m-r--25, .m-lr--25, .m-all--25 {margin-right: -25px;}
.m-r--26, .m-lr--26, .m-all--26 {margin-right: -26px;}
.m-r--27, .m-lr--27, .m-all--27 {margin-right: -27px;}
.m-r--28, .m-lr--28, .m-all--28 {margin-right: -28px;}
.m-r--29, .m-lr--29, .m-all--29 {margin-right: -29px;}
.m-r--30, .m-lr--30, .m-all--30 {margin-right: -30px;}
.m-r--31, .m-lr--31, .m-all--31 {margin-right: -31px;}
.m-r--32, .m-lr--32, .m-all--32 {margin-right: -32px;}
.m-r--33, .m-lr--33, .m-all--33 {margin-right: -33px;}
.m-r--34, .m-lr--34, .m-all--34 {margin-right: -34px;}
.m-r--35, .m-lr--35, .m-all--35 {margin-right: -35px;}
.m-r--36, .m-lr--36, .m-all--36 {margin-right: -36px;}
.m-r--37, .m-lr--37, .m-all--37 {margin-right: -37px;}
.m-r--38, .m-lr--38, .m-all--38 {margin-right: -38px;}
.m-r--39, .m-lr--39, .m-all--39 {margin-right: -39px;}
.m-r--40, .m-lr--40, .m-all--40 {margin-right: -40px;}
.m-r--41, .m-lr--41, .m-all--41 {margin-right: -41px;}
.m-r--42, .m-lr--42, .m-all--42 {margin-right: -42px;}
.m-r--43, .m-lr--43, .m-all--43 {margin-right: -43px;}
.m-r--44, .m-lr--44, .m-all--44 {margin-right: -44px;}
.m-r--45, .m-lr--45, .m-all--45 {margin-right: -45px;}
.m-r--46, .m-lr--46, .m-all--46 {margin-right: -46px;}
.m-r--47, .m-lr--47, .m-all--47 {margin-right: -47px;}
.m-r--48, .m-lr--48, .m-all--48 {margin-right: -48px;}
.m-r--49, .m-lr--49, .m-all--49 {margin-right: -49px;}
.m-r--50, .m-lr--50, .m-all--50 {margin-right: -50px;}
.m-r--51, .m-lr--51, .m-all--51 {margin-right: -51px;}
.m-r--52, .m-lr--52, .m-all--52 {margin-right: -52px;}
.m-r--53, .m-lr--53, .m-all--53 {margin-right: -53px;}
.m-r--54, .m-lr--54, .m-all--54 {margin-right: -54px;}
.m-r--55, .m-lr--55, .m-all--55 {margin-right: -55px;}
.m-r--56, .m-lr--56, .m-all--56 {margin-right: -56px;}
.m-r--57, .m-lr--57, .m-all--57 {margin-right: -57px;}
.m-r--58, .m-lr--58, .m-all--58 {margin-right: -58px;}
.m-r--59, .m-lr--59, .m-all--59 {margin-right: -59px;}
.m-r--60, .m-lr--60, .m-all--60 {margin-right: -60px;}
.m-r--61, .m-lr--61, .m-all--61 {margin-right: -61px;}
.m-r--62, .m-lr--62, .m-all--62 {margin-right: -62px;}
.m-r--63, .m-lr--63, .m-all--63 {margin-right: -63px;}
.m-r--64, .m-lr--64, .m-all--64 {margin-right: -64px;}
.m-r--65, .m-lr--65, .m-all--65 {margin-right: -65px;}
.m-r--66, .m-lr--66, .m-all--66 {margin-right: -66px;}
.m-r--67, .m-lr--67, .m-all--67 {margin-right: -67px;}
.m-r--68, .m-lr--68, .m-all--68 {margin-right: -68px;}
.m-r--69, .m-lr--69, .m-all--69 {margin-right: -69px;}
.m-r--70, .m-lr--70, .m-all--70 {margin-right: -70px;}
.m-r--71, .m-lr--71, .m-all--71 {margin-right: -71px;}
.m-r--72, .m-lr--72, .m-all--72 {margin-right: -72px;}
.m-r--73, .m-lr--73, .m-all--73 {margin-right: -73px;}
.m-r--74, .m-lr--74, .m-all--74 {margin-right: -74px;}
.m-r--75, .m-lr--75, .m-all--75 {margin-right: -75px;}
.m-r--76, .m-lr--76, .m-all--76 {margin-right: -76px;}
.m-r--77, .m-lr--77, .m-all--77 {margin-right: -77px;}
.m-r--78, .m-lr--78, .m-all--78 {margin-right: -78px;}
.m-r--79, .m-lr--79, .m-all--79 {margin-right: -79px;}
.m-r--80, .m-lr--80, .m-all--80 {margin-right: -80px;}
.m-r--81, .m-lr--81, .m-all--81 {margin-right: -81px;}
.m-r--82, .m-lr--82, .m-all--82 {margin-right: -82px;}
.m-r--83, .m-lr--83, .m-all--83 {margin-right: -83px;}
.m-r--84, .m-lr--84, .m-all--84 {margin-right: -84px;}
.m-r--85, .m-lr--85, .m-all--85 {margin-right: -85px;}
.m-r--86, .m-lr--86, .m-all--86 {margin-right: -86px;}
.m-r--87, .m-lr--87, .m-all--87 {margin-right: -87px;}
.m-r--88, .m-lr--88, .m-all--88 {margin-right: -88px;}
.m-r--89, .m-lr--89, .m-all--89 {margin-right: -89px;}
.m-r--90, .m-lr--90, .m-all--90 {margin-right: -90px;}
.m-r--91, .m-lr--91, .m-all--91 {margin-right: -91px;}
.m-r--92, .m-lr--92, .m-all--92 {margin-right: -92px;}
.m-r--93, .m-lr--93, .m-all--93 {margin-right: -93px;}
.m-r--94, .m-lr--94, .m-all--94 {margin-right: -94px;}
.m-r--95, .m-lr--95, .m-all--95 {margin-right: -95px;}
.m-r--96, .m-lr--96, .m-all--96 {margin-right: -96px;}
.m-r--97, .m-lr--97, .m-all--97 {margin-right: -97px;}
.m-r--98, .m-lr--98, .m-all--98 {margin-right: -98px;}
.m-r--99, .m-lr--99, .m-all--99 {margin-right: -99px;}
.m-r--100, .m-lr--100, .m-all--100 {margin-right: -100px;}

.m-l-auto {margin-left: auto;}
.m-r-auto {margin-right: auto;}
.m-lr-auto {margin-left: auto; margin-right: auto;}



/*//////////////////////////////////////////////////////////////////
[ TEXT ]*/
.clwhite {color: white;}
.clblack {color: black;}

/*------------------------------------------------------------------
[ Line height ]*/
.lh-10 {line-height: 1.0;}
.lh-11 {line-height: 1.1;}
.lh-12 {line-height: 1.2;}
.lh-13 {line-height: 1.3;}
.lh-14 {line-height: 1.4;}
.lh-15 {line-height: 1.5;}
.lh-16 {line-height: 1.6;}
.lh-17 {line-height: 1.7;}
.lh-18 {line-height: 1.8;}
.lh-19 {line-height: 1.9;}
.lh-20 {line-height: 2.0;}
.lh-21 {line-height: 2.1;}
.lh-22 {line-height: 2.2;}
.lh-23 {line-height: 2.3;}
.lh-24 {line-height: 2.4;}
.lh-25 {line-height: 2.5;}
.lh-26 {line-height: 2.6;}
.lh-27 {line-height: 2.7;}
.lh-28 {line-height: 2.8;}
.lh-29 {line-height: 2.9;}
.lh-30 {line-height: 3.0;}

/* ------------------------------------ */
.txt-center {text-align: center;}
.txt-left {text-align: left;}
.txt-right {text-align: right;}
.txt-middle {vertical-align: middle;}



/*//////////////////////////////////////////////////////////////////
[ SIZE ]*/

.s-full {width: 100%; height: 100%;}
.w-full {width: 100%;}
.h-full {height: 100%;}
.max-s-full {max-width: 100%; max-height: 100%;}
.max-w-full {max-width: 100%;}
.max-h-full {max-height: 100%;}
.min-w-full {min-width: 100%;}
.min-h-full {min-height: 100%;}



/*//////////////////////////////////////////////////////////////////
[ BACKGROUND ]*/
.bgwhite {background-color: white;}
.bgblack {background-color: black;}
.bglight {background-color: rgb(233, 233, 233);}


/*//////////////////////////////////////////////////////////////////
[ EFFECT ]*/

/*------------------------------------------------------------------
[ Opacity ]*/
.op-00 {opacity: 0;}
.op-01 {opacity: 0.1;}
.op-02 {opacity: 0.2;}
.op-03 {opacity: 0.3;}
.op-04 {opacity: 0.4;}
.op-05 {opacity: 0.5;}
.op-06 {opacity: 0.6;}
.op-07 {opacity: 0.7;}
.op-08 {opacity: 0.8;}
.op-09 {opacity: 0.9;}
.op-10 {opacity: 1;}


/*------------------------------------------------------------------
[ Wrap Picture ]*/

.wrap-pic-s,
.wrap-pic-max-s,
.wrap-pic-w,
.wrap-pic-max-w,
.wrap-pic-h,
.wrap-pic-max-h {
	display: block;
}

.wrap-pic-w img {width: 100%;}
.wrap-pic-max-w img {max-width: 100%;}

.wrap-pic-h img {height: 100%;}
.wrap-pic-max-h img {max-height: 100%;}

.wrap-pic-s img {width: 100%; height: 100%;}
.wrap-pic-max-s img {max-width: 100%; max-height: 100%;}


/*---------------------------------------------*/
.pointer {cursor: pointer;}
.of-hidden {overflow: hidden;}
.visible-false {visibility: hidden;}
.visible-true {visibility: visible;}


/*------------------------------------------------------------------
[ Transition ]*/
.trans-01 {
	-webkit-transition: all 0.1s;
    -o-transition: all 0.1s;
    -moz-transition: all 0.1s;
    transition: all 0.1s;
}
.trans-02 {
	-webkit-transition: all 0.2s;
    -o-transition: all 0.2s;
    -moz-transition: all 0.2s;
    transition: all 0.2s;
}
.trans-03 {
	-webkit-transition: all 0.3s;
    -o-transition: all 0.3s;
    -moz-transition: all 0.3s;
    transition: all 0.3s;
}
.trans-04 {
	-webkit-transition: all 0.4s;
    -o-transition: all 0.4s;
    -moz-transition: all 0.4s;
    transition: all 0.4s;
}
.trans-05 {
	-webkit-transition: all 0.5s;
    -o-transition: all 0.5s;
    -moz-transition: all 0.5s;
    transition: all 0.5s;
}
.trans-06 {
	-webkit-transition: all 0.6s;
    -o-transition: all 0.6s;
    -moz-transition: all 0.6s;
    transition: all 0.6s;
}
.trans-07 {
	-webkit-transition: all 0.7s;
    -o-transition: all 0.7s;
    -moz-transition: all 0.7s;
    transition: all 0.7s;
}
.trans-08 {
	-webkit-transition: all 0.8s;
    -o-transition: all 0.8s;
    -moz-transition: all 0.8s;
    transition: all 0.8s;
}
.trans-09 {
	-webkit-transition: all 0.9s;
    -o-transition: all 0.9s;
    -moz-transition: all 0.9s;
    transition: all 0.9s;
}
.trans-10 {
	-webkit-transition: all 1s;
    -o-transition: all 1s;
    -moz-transition: all 1s;
    transition: all 1s;
}



/*//////////////////////////////////////////////////////////////////
[ POSITION ]*/

/*------------------------------------------------------------------
[ Display ]*/
.dis-none {display: none;}
.dis-block {display: block;}
.dis-inline {display: inline;}
.dis-inline-block {display: inline-block;}

.flex-w,
.flex-l,
.flex-r,
.flex-c,
.flex-sa,
.flex-sb,
.flex-t,
.flex-b,
.flex-m,
.flex-str,
.flex-c-m,
.flex-c-t,
.flex-c-b,
.flex-c-str,
.flex-l-m,
.flex-r-m,
.flex-sa-m,
.flex-sb-m,
.flex-col-l,
.flex-col-r,
.flex-col-c,
.flex-col-str,
.flex-col-t,
.flex-col-b,
.flex-col-m,
.flex-col-sb,
.flex-col-sa,
.flex-col-c-m,
.flex-col-l-m,
.flex-col-r-m,
.flex-col-str-m,
.flex-col-c-t,
.flex-col-c-b,
.flex-col-c-sb,
.flex-col-c-sa,
.flex-col-l-sb,
.flex-col-r-sb,
.flex-row,
.flex-row-rev,
.flex-col,
.flex-col-rev,
.dis-flex {
	display: -webkit-box;
	display: -webkit-flex;
	display: -moz-box;
	display: -ms-flexbox;
	display: flex;
}

/*------------------------------------------------------------------
[ Position ]*/
.pos-relative {position: relative;}
.pos-absolute {position: absolute;}
.pos-fixed {position: fixed;}

/*------------------------------------------------------------------
[ Float ]*/
.float-l {float: left;}
.float-r {float: right;}


/*------------------------------------------------------------------
[ Top Bottom Left Right ]*/
.top-0 {top: 0;}
.bottom-0 {bottom: 0;}
.left-0 {left: 0;}
.right-0 {right: 0;}

.top-auto {top: auto;}
.bottom-auto {bottom: auto;}
.left-auto {left: auto;}
.right-auto {right: auto;}


/*------------------------------------------------------------------
[ Flex ]*/
.flex-w {
	-webkit-flex-wrap: wrap;
	-moz-flex-wrap: wrap;
	-ms-flex-wrap: wrap;
	-o-flex-wrap: wrap;
	flex-wrap: wrap;
}

/* ------------------------------------ */
.flex-l {
	justify-content: flex-start;
}

.flex-r {
	justify-content: flex-end;
}

.flex-c {
	justify-content: center;
}

.flex-sa {
	justify-content: space-around;
}

.flex-sb {
	justify-content: space-between;
}

/* ------------------------------------ */
.flex-t {
	-ms-align-items: flex-start;
	align-items: flex-start;
}

.flex-b {
	-ms-align-items: flex-end;
	align-items: flex-end;
}

.flex-m {
	-ms-align-items: center;
	align-items: center;
}

.flex-str {
	-ms-align-items: stretch;
	align-items: stretch;
}


/* ------------------------------------ */
.flex-c-m {
	justify-content: center;
	-ms-align-items: center;
	align-items: center;
}

.flex-c-t {
	justify-content: center;
	-ms-align-items: flex-start;
	align-items: flex-start;
}

.flex-c-b {
	justify-content: center;
	-ms-align-items: flex-end;
	align-items: flex-end;
}

.flex-c-str {
	justify-content: center;
	-ms-align-items: stretch;
	align-items: stretch;
}

.flex-l-m {
	justify-content: flex-start;
	-ms-align-items: center;
	align-items: center;
}

.flex-r-m {
	justify-content: flex-end;
	-ms-align-items: center;
	align-items: center;
}

.flex-sa-m {
	justify-content: space-around;
	-ms-align-items: center;
	align-items: center;
}

.flex-sb-m {
	justify-content: space-between;
	-ms-align-items: center;
	align-items: center;
}

/* ------------------------------------ */
.flex-col-l {
	-ms-align-items: flex-start;
	align-items: flex-start;
}

.flex-col-r {
	-ms-align-items: flex-end;
	align-items: flex-end;
}

.flex-col-c {
	-ms-align-items: center;
	align-items: center;
}

.flex-col-str {
	-ms-align-items: stretch;
	align-items: stretch;
}

/*---------------------------------------------*/
.flex-col-t {
	justify-content: flex-start;
}

.flex-col-b {
	justify-content: flex-end;
}

.flex-col-m {
	justify-content: center;
}

.flex-col-sb {
	justify-content: space-between;
}

.flex-col-sa {
	justify-content: space-around;
}

/*---------------------------------------------*/
.flex-col-c-m {
	-ms-align-items: center;
	align-items: center;
	justify-content: center;
}

.flex-col-l-m {
	-ms-align-items: flex-start;
	align-items: flex-start;
	justify-content: center;
}

.flex-col-r-m {
	-ms-align-items: flex-end;
	align-items: flex-end;
	justify-content: center;
}

.flex-col-str-m {
	-ms-align-items: stretch;
	align-items: stretch;
	justify-content: center;
}


.flex-col-c-t {
	justify-content: flex-start;
	-ms-align-items: center;
	align-items: center;
}

.flex-col-c-b {
	justify-content: flex-end;
	-ms-align-items: center;
	align-items: center;
}

.flex-col-c-sb {
	justify-content: space-between;
	-ms-align-items: center;
	align-items: center;
}

.flex-col-c-sa {
	justify-content: space-around;
	-ms-align-items: center;
	align-items: center;
}


.flex-col-l-sb {
	justify-content: space-between;
	-ms-align-items: center;
	align-items: flex-start;
}

.flex-col-r-sb {
	justify-content: space-between;
	-ms-align-items: center;
	align-items: flex-end;
}


/* ------------------------------------ */
.flex-row {
	-webkit-flex-direction: row;
	-moz-flex-direction: row;
	-ms-flex-direction: row;
	-o-flex-direction: row;
	flex-direction: row;
}

.flex-row-rev {
	-webkit-flex-direction: row-reverse;
	-moz-flex-direction: row-reverse;
	-ms-flex-direction: row-reverse;
	-o-flex-direction: row-reverse;
	flex-direction: row-reverse;
}

.flex-col-l,
.flex-col-r,
.flex-col-c,
.flex-col-str,
.flex-col-t,
.flex-col-b,
.flex-col-m,
.flex-col-sb,
.flex-col-sa,
.flex-col-c-m,
.flex-col-l-m,
.flex-col-r-m,
.flex-col-str-m,
.flex-col-c-t,
.flex-col-c-b,
.flex-col-c-sb,
.flex-col-c-sa,
.flex-col-l-sb,
.flex-col-r-sb,
.flex-col {
	-webkit-flex-direction: column;
	-moz-flex-direction: column;
	-ms-flex-direction: column;
	-o-flex-direction: column;
	flex-direction: column;
}

.flex-col-rev {
	-webkit-flex-direction: column-reverse;
	-moz-flex-direction: column-reverse;
	-ms-flex-direction: column-reverse;
	-o-flex-direction: column-reverse;
	flex-direction: column-reverse;
}


/*------------------------------------------------------------------
[ Absolute ]*/
.ab-c-m {
	position: absolute;
	top: 50%;
	left: 50%;
	-webkit-transform: translate(-50%, -50%);
  	-moz-transform: translate(-50%, -50%);
  	-ms-transform: translate(-50%, -50%);
  	-o-transform: translate(-50%, -50%);
	transform: translate(-50%, -50%);
}

.ab-c-t {
	position: absolute;
	top: 0px;
	left: 50%;
	-webkit-transform: translateX(-50%);
  	-moz-transform: translateX(-50%);
  	-ms-transform: translateX(-50%);
  	-o-transform: translateX(-50%);
	transform: translateX(-50%);
}

.ab-c-b {
	position: absolute;
	bottom: 0px;
	left: 50%;
	-webkit-transform: translateX(-50%);
  	-moz-transform: translateX(-50%);
  	-ms-transform: translateX(-50%);
  	-o-transform: translateX(-50%);
	transform: translateX(-50%);
}

.ab-l-m {
	position: absolute;
	left: 0px;
	top: 50%;
	-webkit-transform: translateY(-50%);
  	-moz-transform: translateY(-50%);
  	-ms-transform: translateY(-50%);
  	-o-transform: translateY(-50%);
	transform: translateY(-50%);
}

.ab-r-m {
	position: absolute;
	right: 0px;
	top: 50%;
	-webkit-transform: translateY(-50%);
  	-moz-transform: translateY(-50%);
  	-ms-transform: translateY(-50%);
  	-o-transform: translateY(-50%);
	transform: translateY(-50%);
}

.ab-t-l {
	position: absolute;
	left: 0px;
	top: 0px;
}

.ab-t-r {
	position: absolute;
	right: 0px;
	top: 0px;
}

.ab-b-l {
	position: absolute;
	left: 0px;
	bottom: 0px;
}

.ab-b-r {
	position: absolute;
	right: 0px;
	bottom: 0px;
}



/*//////////////////////////////////////////////////////////////////
[ Other ]*/

.parallax100 {
  background-attachment: fixed;
  background-position: center 0;
  background-repeat: no-repeat;
  background-size: cover;
}

@media (max-width: 992px) {
  .parallax100 {
    background-attachment: inherit;
  }
}


/*---------------------------------------------*/
.hidden-scroll {
	-ms-overflow-style: none;
	overflow: -moz-scrollbars-none;
}

.hidden-scroll::-webkit-scrollbar {
	display: none;
}

/*---------------------------------------------*/
.pointer-none {
	pointer-events: none;
}
    </style>

</head>

<body class="animsition m-t-20 m-b-20">

    <div class="container">
    
        <div class="row invoice">
            <!-- title row -->
            <div class="invoice-header col-12">
                <p class="ltext-103 text-center cl5">Hóa đơn</p>
                <p class='stext-103 text-center cl5'>Ngày lập: {{ $created_order }}</p>
            </div>
    
            <div class="col-sm-12 col-lg-4 m-t-20">
                <div class="invoice-col w-100 bor10 p-lr-40 p-t-30 p-b-40 m-r-20 m-lr-0-xl p-lr-15-sm">
                    <p class="mtext-103 cl5 m-b-10">Khách hàng: </p>
                    <address>
                        <strong class="stext-103 cl5">Tên: </strong> {{ $order->user->fullname }}<br>
                        <strong class="stext-103 cl5">Địa chỉ:</strong> {{ $order->user->address }}
                        <br><strong class='stext-103 cl5'>Số điện thoại:</strong> {{ $order->user->phone }}
                        <br><strong class="stext-103 cl5">Email:</strong> {{ $order->user->email }}
                    </address>
                </div>
            </div>
    
    
            <div class="col-sm-12 col-lg-4 m-t-20">
                <div class="invoice-col w-100 bor10 p-lr-40 p-t-30 p-b-40 m-r-40 m-lr-0-xl p-lr-15-sm">
                    <p class="mtext-103 cl5 m-b-10">Hóa đơn: </p>
                    <b class="stext-103 cl5">Đơn hàng: #{{ $order->id }}</b>
                    <br/>
                    @if($order->status != 'Hủy đơn hàng')
                    <b class="stext-103 cl5">Ngày thanh toán:</b>
                        @if ($order->status_payment == 0)
                            Chưa thanh toán  
                        @else
                            Đã thanh toán
                        @endif
                    <br/>
                    @endif
                    <b class="stext-103 cl5">Tình trạng:</b> {{ $order->status }}
                    {{-- <a href={{url("home/track_order/".$order->id)}}>Kiểm tra đơn hàng</a> --}}
                </div>
            </div>
    
            <!-- info row -->
            <div class="invoice-info m-b-20 col-12 m-t-20">
    
                <div class="wrap-table-shopping-cart m-t-20">
                        <table class="table-shopping-cart">
                            <tr class="table_head">
                                <th class="column-1">Mã sản phẩm</th>
                                <th class="column-2">Tên sản phẩm</th>
                                <th class="column-3">Số lượng</th>
                                <th class="column-4">Giá</th>
                                <th class="column-4">Bảo hành</th>
                                <th class="column-5">Thành tiền</th>
                            </tr>
                            @foreach ($order_details as $order_detail)
                            <tr class="text-left">
                                    <td class="column-1 p-t-10 p-b-10">{{ $order_detail->product->id }}</td>
                                    <td class="column-2">{{ $order_detail->product->name }}</td>
                                    <td class="column-3">{{ $order_detail->quantity }}</td>
                                    <td class="column-4">{{ number_format($order_detail->product->price) }} VNĐ</td>
                                    <td class="column-4">{{ $warranty_order }}</td>
                                    <td class="column-5">{{ number_format($order_detail->amount * $order_detail->quantity, 0, ',', '.') }} VNĐ</td>
                                </tr>
                            @endforeach
    
                        </table>
                    </div>
                    <!-- /.col -->
                </div>
                <div class="col-md-6">
                    <p class="lead mtext-103 cl5 m-b-10 m-t-20">Phương thức thanh toán: <b>{{ $order->payment_method }}</b></p>
    
                    <p class="text-muted well well-sm no-shadow stext-103 cl5" style="margin-top: 10px;">
                        @if ($order->payment_method == 'MoMo')
                            Đơn hàng đã được thanh toán qua momo.
                        @elseif ($order->payment_method == 'VNPay')
                            Đơn hàng đã được thanh toán qua momo.
                        @else
                            Đơn hàng được thanh toán bằng tiền mặt khi nhận hàng.
                        @endif
                        <br><br>
                        Trong thời gian bảo hành nếu có bất cứ vấn đề gì
                        xin hãy liên hệ qua email hoặc số điện thoại của cửa hàng.
                        <br><br>
                        Số điện thoại: 099 978 9889<br>
                        Email: ntnsotre@gmail.com
                    </p>
                </div>
                <div class="col-md-6">
                    <p class="lead mtext-103 cl5 m-b-10 m-t-20">Tổng thành tiền</p>
                    <br>
                    <div class="table-responsive stext-103 cl5">
                        <table class="table">
                            <tbody>
                                @if(!is_null($order->promotion))
                                <tr>
                                    <th>Khuyến mãi ({{ $order->promotion->percent }}%)</th>
                                    <td>
                                        {{ number_format($order->promotion->percent * $order->total / 100, 0, ',', '.') }} VNĐ
                                    </td>
                                </tr>
                                @endif
                                <tr>
                                    <th>VAT:</th>
                                    <td>Sản phẩm đã bao gồm VAT</td>
                                </tr>
                                <tr>
                                    <th>Tổng:</th>
                                    <td>{{ number_format($order->total, 0, ',', '.') }} VNĐ</td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

</body>

</html>
